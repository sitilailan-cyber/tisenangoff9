import { SensorReading, ExperimentRow } from '../../types';

export type { SensorReading, ExperimentRow };

export type SensorDataSourceMode = 'simulated' | 'spreadsheet';

export interface ISensorProvider {
  readSensors?(): Promise<SensorReading>;
  fetchSpreadsheetData?(customUrl?: string): Promise<any>;
}

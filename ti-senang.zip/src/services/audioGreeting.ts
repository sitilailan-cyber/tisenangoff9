/**
 * TI SENANG - Audio Sapaan Personal & Welcome Greeting Engine
 * Memutar sapaan audio personal menggunakan Web Speech API (id-ID)
 * hanya satu kali per sesi login berhasil tanpa mengganggu jalannya aplikasi.
 */

import { User } from '../types';

const AUDIO_ENABLED_STORAGE_KEY = 'ti_senang_audio_greeting_enabled';

/**
 * Cek apakah audio greeting diaktifkan oleh pengguna
 */
export function isAudioGreetingEnabled(): boolean {
  if (typeof window === 'undefined') return true;
  try {
    const val = localStorage.getItem(AUDIO_ENABLED_STORAGE_KEY);
    return val !== 'false';
  } catch {
    return true;
  }
}

/**
 * Simpan preferensi audio greeting
 */
export function setAudioGreetingEnabled(enabled: boolean): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(AUDIO_ENABLED_STORAGE_KEY, enabled ? 'true' : 'false');
  } catch (e) {
    console.warn('Gagal menyimpan preferensi audio:', e);
  }
}

/**
 * Ekstrak sapaan ramah dan nama dinamis dari profil pengguna
 */
export function getGreetingText(user: User): { speechText: string; toastTitle: string; subtitle: string } {
  // Murid
  if (user.role === 'murid') {
    const rawName = (user.fullName || user.name || user.username || 'Murid').replace(/\s*\([^)]*\)/g, '').trim();
    // Ambil nama panggilan pertama yang ramah
    const shortName = rawName.split(' ')[0] || 'Murid';
    return {
      speechText: `Selamat belajar, ${shortName}!`,
      toastTitle: `Selamat belajar, ${shortName}! 👋`,
      subtitle: 'Misi dan petualangan belajarmu sudah siap!',
    };
  }

  // Guru
  if (user.role === 'guru') {
    const rawName = user.fullName || user.name || user.username || 'Guru';
    // Bersihkan gelar akademik untuk sapaan hangat yang akrab
    const clean = rawName
      .replace(/^(Dr\.|Dra\.|Drs\.|Prof\.)\s*/i, '')
      .replace(/,\s*(M\.Pd|M\.Si|S\.Pd|S\.Si|Ph\.D|M\.T|S\.T|M\.Sc|S\.Kom|M\.Kom).*$/i, '')
      .trim();
    const shortName = clean.split(' ')[0] || 'Guru';

    // Sesuaikan panggilan Bapak atau Ibu berdasarkan jenis kelamin yang dimasukkan admin
    let salutation = 'Bapak/Ibu';
    if (user.gender === 'L') {
      salutation = 'Bapak';
    } else if (user.gender === 'P') {
      salutation = 'Ibu';
    } else if (/siti|lailan|rahma|wati|dewi|putri|anisa|indah|nur|retno|tiara|dra/i.test(rawName)) {
      salutation = 'Ibu';
    } else if (/budi|hendra|joko|agus|fauzan|ahmad|rizky|eko|danang|wahyu|drs/i.test(rawName)) {
      salutation = 'Bapak';
    }

    const teacherDisplayName = `${salutation} ${shortName}`;

    return {
      speechText: `Selamat datang, ${teacherDisplayName}!`,
      toastTitle: `Selamat datang, ${teacherDisplayName}! 👋`,
      subtitle: 'Ruang kendali pembelajaran dan rombel siap dikelola',
    };
  }

  // Admin
  return {
    speechText: 'Selamat datang di Ti-Senang, Administrator!',
    toastTitle: 'Selamat datang, Administrator! 👋',
    subtitle: 'Sistem dan manajemen data terhubung aktif',
  };
}

let lastPlayedUserId: string | null = null;
let lastPlayedTimestamp = 0;

/**
 * Reset status greeting saat pengguna logout agar saat login kembali
 * audio sapaan dapat berbunyi lagi secara konsisten.
 */
export function clearGreetingSession(): void {
  lastPlayedUserId = null;
  lastPlayedTimestamp = 0;
  if (typeof window !== 'undefined') {
    try {
      for (let i = sessionStorage.length - 1; i >= 0; i--) {
        const k = sessionStorage.key(i);
        if (k && k.startsWith('ti_senang_greeting_played_')) {
          sessionStorage.removeItem(k);
        }
      }
    } catch {
      // ignore
    }
  }
}

/**
 * Putar suara sapaan personal menggunakan Web Speech API (id-ID)
 * Selalu aktif dan berfungsi saat siswa/guru masuk, termasuk jika keluar lalu masuk lagi.
 */
export function playPersonalAudioGreeting(user: User, force = false): void {
  if (typeof window === 'undefined') return;

  // Cek preferensi audio (selalu aktif secara default)
  if (!force && !isAudioGreetingEnabled()) return;

  // Debounce guard: Hindari pemanggilan ganda dalam rentang 3 detik untuk login yang sama
  const now = Date.now();
  if (!force && lastPlayedUserId === user.id && (now - lastPlayedTimestamp < 3000)) {
    return;
  }
  lastPlayedUserId = user.id;
  lastPlayedTimestamp = now;

  // Eksekusi Web Speech Synthesis
  try {
    if (!('speechSynthesis' in window)) {
      return;
    }

    const { speechText } = getGreetingText(user);

    // Cancel antrean suara sebelumnya dan pastikan status resume
    window.speechSynthesis.cancel();
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }

    const utterance = new SpeechSynthesisUtterance(speechText);
    utterance.lang = 'id-ID';
    utterance.rate = 0.95; // Kecepatan bersahabat
    utterance.pitch = 1.05; // Nada hangat
    utterance.volume = 1.0;

    // Cari voice berbahasa Indonesia jika tersedia
    const voices = window.speechSynthesis.getVoices();
    const indonesianVoice = voices.find(
      (v) => v.lang.startsWith('id') || v.lang.includes('IND') || v.lang.includes('Indonesia')
    );

    if (indonesianVoice) {
      utterance.voice = indonesianVoice;
    }

    utterance.onerror = (e) => {
      console.info('Audio greeting feedback:', e.error);
    };

    // Jalankan speak setelah jeda mikro agar browser speech engine siap setelah cancel()
    setTimeout(() => {
      try {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
        }
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        console.warn('Speech synthesis speak error:', e);
      }
    }, 120);
  } catch (err) {
    console.info('Speech synthesis bypassed safely:', err);
  }
}

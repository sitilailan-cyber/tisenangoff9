/**
 * Web Bluetooth service untuk Kit TI SENANG (Versi Offline)
 * Menggunakan Web Bluetooth API untuk menghubungkan alat langsung ke browser.
 */

export const SERVICE_UUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
export const CHARACTERISTIC_UUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8";

export type SensorBluetoothData = {
  suhu?: number | string;
  kelembapan?: number | string;
  kelembaban?: number | string;
  cahaya?: number | string;
  arus?: number | string;
  gerak?: number | string;
  disconnected?: boolean;
  [key: string]: any;
};

export type BluetoothDataListener = (data: SensorBluetoothData) => void;

let activeBluetoothDevice: any = null;
const listeners = new Set<BluetoothDataListener>();

export function subscribeBluetoothData(listener: BluetoothDataListener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function getActiveBluetoothDevice() {
  return activeBluetoothDevice;
}

export function isBluetoothAllowedByPolicy(): boolean {
  if (typeof navigator === 'undefined' || !(navigator as any).bluetooth) {
    return false;
  }
  if (typeof document !== 'undefined') {
    const doc = document as any;
    if (doc.permissionsPolicy && typeof doc.permissionsPolicy.allowsFeature === 'function') {
      try {
        if (!doc.permissionsPolicy.allowsFeature('bluetooth')) {
          return false;
        }
      } catch {
        // fallback
      }
    }
    if (doc.featurePolicy && typeof doc.featurePolicy.allowsFeature === 'function') {
      try {
        if (!doc.featurePolicy.allowsFeature('bluetooth')) {
          return false;
        }
      } catch {
        // fallback
      }
    }
  }
  if (typeof window !== 'undefined' && window.self !== window.top) {
    const doc = document as any;
    if (!doc.permissionsPolicy && !doc.featurePolicy) {
      return false;
    }
  }
  return true;
}

// Simulasi dimatikan sepenuhnya: Hanya data sensor murni dari alat fisik Kit Ti Senang yang ditampilkan
export function hentikanSimulasiKitTiSenang() {
  // no-op
}

export function mulaiSimulasiDataKitTiSenang() {
  // no-op: Dilarang menggunakan data simulasi/sembarang
}

export function updateStatus(isConnected: boolean, text: string) {
  if (typeof document === 'undefined') return;
  const dot = document.getElementById("dotStatus");
  const txt = document.getElementById("txtStatus");
  const btn = document.getElementById("btnConnect");

  if (txt) txt.innerText = text;
  if (btn) {
    if (isConnected) {
      if (dot) dot.classList.add("connected");
      btn.innerText = "Terhubung ke Kit Ti Senang";
      btn.style.backgroundColor = "#16a34a";
    } else {
      if (dot) dot.classList.remove("connected");
      btn.innerText = "Hubungkan Kit Ti Senang";
      btn.style.backgroundColor = "#2563eb";
    }
  }
}

export function onDisconnected() {
  console.log("Koneksi BLE terputus.");
  updateStatus(false, "Terputus");
  if (typeof document !== 'undefined') {
    const txtDev = document.getElementById("txtDevice");
    if (txtDev) txtDev.innerText = "-";

    document.querySelectorAll('#valSuhu').forEach((el) => {
      (el as HTMLElement).innerText = "--";
    });
    document.querySelectorAll('#valLembap').forEach((el) => {
      (el as HTMLElement).innerText = "--";
    });
    document.querySelectorAll('#valCahaya').forEach((el) => {
      (el as HTMLElement).innerText = "--";
    });
  }
  activeBluetoothDevice = null;
  listeners.forEach((listener) => {
    try {
      listener({ disconnected: true });
    } catch (e) {
      console.warn(e);
    }
  });
}

export async function putuskanKitTiSenang() {
  onDisconnected();
  try {
    if (activeBluetoothDevice && activeBluetoothDevice.gatt && activeBluetoothDevice.gatt.connected) {
      activeBluetoothDevice.gatt.disconnect();
    }
  } catch (err) {
    console.warn("Gagal memutuskan Bluetooth:", err);
  }
  activeBluetoothDevice = null;
}

export async function hubungkanBluetooth() {
  // Jika sedang terhubung, toggle untuk memutuskan koneksi
  const btn = typeof document !== 'undefined' ? document.getElementById("btnConnect") : null;
  if (activeBluetoothDevice && btn && btn.innerText.includes("Terhubung")) {
    onDisconnected();
    return null;
  }

  // Cek apakah Web Bluetooth diizinkan oleh Permissions Policy browser / iframe
  if (!isBluetoothAllowedByPolicy()) {
    console.warn("Akses Web Bluetooth diblokir di dalam pratinjau (iframe) oleh Permissions Policy.");
    updateStatus(false, "Buka di Tab Baru");
    listeners.forEach((listener) => {
      try {
        listener({
          disconnected: true,
          errorNotice:
            'Akses Web Bluetooth dibatasi di dalam pratinjau (iframe). Buka aplikasi di tab baru browser Chrome untuk menghubungkan Bluetooth langsung ke Kit Ti Senang.',
        });
      } catch (e) {
        console.warn(e);
      }
    });
    return null;
  }

  updateStatus(false, "Menghubungkan...");

  try {
    console.log("Mencari perangkat BLE Kit Ti Senang...");

    if (typeof navigator === 'undefined' || !(navigator as any).bluetooth) {
      throw new Error("Web Bluetooth API tidak didukung pada browser ini.");
    }

    // 1. Minta akses Bluetooth browser ke Kit Ti Senang
    const device = await (navigator as any).bluetooth.requestDevice({
      filters: [{ name: 'Kit Ti Senang' }],
      optionalServices: [SERVICE_UUID]
    });

    activeBluetoothDevice = device;

    // Deteksi jika koneksi terputus
    device.addEventListener('gattserverdisconnected', onDisconnected);

    console.log("Menghubungkan ke GATT Server...");
    const server = await device.gatt.connect();

    console.log("Mengambil Service BLE...");
    const service = await server.getPrimaryService(SERVICE_UUID);

    console.log("Mengambil Characteristic BLE...");
    const characteristic = await service.getCharacteristic(CHARACTERISTIC_UUID);

    // 2. Aktifkan Notifikasi Aliran Data
    await characteristic.startNotifications();
    console.log("Notifikasi BLE Aktif! Menunggu data murni dari ESP32...");

    updateStatus(true, "Terhubung");
    if (typeof document !== 'undefined') {
      const txtDev = document.getElementById("txtDevice");
      if (txtDev) txtDev.innerText = device.name || "Kit Ti Senang";
    }

    // 3. Listener Pembaca Data JSON dari ESP32
    let bleBuffer = '';
    characteristic.addEventListener('characteristicvaluechanged', (event: any) => {
      const decoder = new TextDecoder('utf-8');
      const rawChunk = decoder.decode(event.target.value);
      console.log("Data BLE Masuk dari ESP32:", rawChunk);

      bleBuffer += rawChunk;
      let data: any = null;

      try {
        data = JSON.parse(bleBuffer.trim());
        bleBuffer = '';
      } catch {
        const s = bleBuffer.indexOf('{');
        const e = bleBuffer.lastIndexOf('}');
        if (s !== -1 && e !== -1 && e > s) {
          try {
            data = JSON.parse(bleBuffer.substring(s, e + 1));
            bleBuffer = bleBuffer.substring(e + 1);
          } catch {}
        }
      }

      if (bleBuffer.length > 512) bleBuffer = '';

      if (data) {
        console.log("Data Sensor Murni Diterima:", data);

        // Ekstraksi suhu murni dari sensor (DS18B20 / suhu_air / temp)
        // Jangan timpa jika sensor suhu tidak terpasang
        let suhuVal: number | undefined = undefined;
        if (data.suhu_air !== undefined && data.suhu_air !== null && Number(data.suhu_air) !== 0 && Number(data.suhu_air) !== -127) {
          suhuVal = Number(data.suhu_air);
        } else if (data.suhu !== undefined && data.suhu !== null && Number(data.suhu) !== 0 && Number(data.suhu) !== -127) {
          suhuVal = Number(data.suhu);
        } else if (data.temp !== undefined && data.temp !== null && Number(data.temp) !== 0 && Number(data.temp) !== -127) {
          suhuVal = Number(data.temp);
        } else if (data.temperature !== undefined && data.temperature !== null && Number(data.temperature) !== 0 && Number(data.temperature) !== -127) {
          suhuVal = Number(data.temperature);
        } else if (data.suhu !== undefined && data.suhu !== null && !isNaN(Number(data.suhu))) {
          suhuVal = Number(data.suhu);
        } else if (data.suhu_air !== undefined && data.suhu_air !== null && !isNaN(Number(data.suhu_air))) {
          suhuVal = Number(data.suhu_air);
        } else if (data.tempDS !== undefined && data.tempDS !== null && !isNaN(Number(data.tempDS))) {
          suhuVal = Number(data.tempDS);
        }

        // Ekstraksi kelembapan HANYA jika sensor terhubung secara fisik dan menghasilkan nilai nyata (> 0)
        let lembapVal: number | undefined = undefined;
        const rawHum = data.kelembapan ?? data.kelembaban ?? data.humidity ?? data.hum ?? data.humDHT ?? data.hum_dht;
        if (rawHum !== undefined && rawHum !== null && !isNaN(Number(rawHum)) && Number(rawHum) > 0) {
          lembapVal = Number(rawHum);
        }

        // Ekstraksi cahaya HANYA jika sensor terhubung secara fisik dan menghasilkan nilai nyata (> 0)
        let cahayaVal: number | undefined = undefined;
        const rawLux = data.cahaya ?? data.lux ?? data.light ?? data.ldr ?? data.luxBH ?? data.lux_bh;
        if (rawLux !== undefined && rawLux !== null && !isNaN(Number(rawLux)) && Number(rawLux) > 0) {
          cahayaVal = Number(rawLux);
        }

        // Ekstraksi arus HANYA jika terhubung (> 0)
        let arusVal: number | undefined = undefined;
        const rawArus = data.arus ?? data.current ?? data.ampere;
        if (rawArus !== undefined && rawArus !== null && !isNaN(Number(rawArus)) && Number(rawArus) > 0) {
          arusVal = Number(rawArus);
        }

        // Ekstraksi gerak
        let gerakVal: any = undefined;
        const rawGerak = data.gerak ?? data.motion ?? data.pir ?? data.distance;
        if (rawGerak !== undefined && rawGerak !== null && rawGerak !== 0 && rawGerak !== false && rawGerak !== '0') {
          gerakVal = rawGerak;
        }

        // Update langsung ke elemen HTML - JIKA SENSOR TIDAK TERHUBUNG TAMPILKAN "--"
        if (typeof document !== 'undefined') {
          document.querySelectorAll('#valSuhu').forEach((el) => {
            (el as HTMLElement).innerText = suhuVal !== undefined ? String(suhuVal) : "--";
          });
          document.querySelectorAll('#valLembap').forEach((el) => {
            (el as HTMLElement).innerText = lembapVal !== undefined ? String(lembapVal) : "--";
          });
          document.querySelectorAll('#valCahaya').forEach((el) => {
            (el as HTMLElement).innerText = cahayaVal !== undefined ? String(cahayaVal) : "--";
          });
        }

        // Teruskan data murni ke listener komponen (hanya port yang benar-benar terhubung)
        const packet: SensorBluetoothData = {
          suhu: suhuVal,
          kelembapan: lembapVal,
          cahaya: cahayaVal,
          arus: arusVal,
          gerak: gerakVal,
          connectedPorts: {
            port1: suhuVal !== undefined,
            port2: cahayaVal !== undefined,
            port3: lembapVal !== undefined,
            port4: arusVal !== undefined,
            port5: gerakVal !== undefined,
          },
        };

        listeners.forEach((listener) => {
          try {
            listener(packet);
          } catch (e) {
            console.warn(e);
          }
        });
      }
    });

    return device;
  } catch (error: any) {
    const isPolicyError =
      error?.name === 'SecurityError' ||
      String(error?.message || '').toLowerCase().includes('permissions policy') ||
      String(error?.message || '').toLowerCase().includes('disallowed');

    const isCancelError =
      error?.name === 'NotFoundError' ||
      String(error?.message || '').toLowerCase().includes('cancelled') ||
      String(error?.message || '').toLowerCase().includes('canceled');

    if (isPolicyError) {
      console.warn("Akses Web Bluetooth dibatasi oleh kebijakan browser:", error?.message || error);
    } else if (isCancelError) {
      console.log("Pencarian perangkat BLE dibatalkan oleh pengguna.");
    } else {
      console.warn("Koneksi Bluetooth tidak berhasil:", error?.message || error);
    }

    updateStatus(false, isPolicyError ? "Buka di Tab Baru" : "Gagal Terhubung");

    // Jangan pernah memasukkan data simulasi / dummy!
    // Deteksi jika diblokir oleh browser / iframe permissions policy
    listeners.forEach((listener) => {
      try {
        listener({
          disconnected: true,
          errorNotice: isPolicyError
            ? 'Akses Web Bluetooth diblokir di dalam pratinjau (iframe). Buka aplikasi di tab baru browser Chrome untuk menghubungkan Bluetooth langsung ke Kit Ti Senang.'
            : isCancelError
            ? 'Pemilihan perangkat dibatalkan.'
            : `Koneksi Bluetooth gagal: ${error?.message || 'Perangkat tidak ditemukan atau koneksi dibatalkan.'}`,
        });
      } catch (e) {
        console.warn(e);
      }
    });

    return null;
  }
}

// Alias untuk kompatibilitas
export const hubungkanKitTiSenang = hubungkanBluetooth;

// Pastikan fungsi ini juga tersedia di window global
if (typeof window !== 'undefined') {
  (window as any).hubungkanBluetooth = hubungkanBluetooth;
  (window as any).hubungkanKitTiSenang = hubungkanBluetooth;
  (window as any).onDisconnected = onDisconnected;
  (window as any).updateStatus = updateStatus;
  (window as any).SERVICE_UUID = SERVICE_UUID;
  (window as any).CHARACTERISTIC_UUID = CHARACTERISTIC_UUID;
}

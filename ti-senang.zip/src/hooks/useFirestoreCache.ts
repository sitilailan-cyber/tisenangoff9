/**
 * React Hooks for Firestore Cache-First Data Fetching & Real-time Synchronization
 *
 * Menggunakan onSnapshot dengan { includeMetadataChanges: true }
 * Menyediakan status loading instan dari IndexedDB cache tanpa jeda jaringan.
 */

import { useState, useEffect, useRef } from 'react';
import { QueryConstraint } from 'firebase/firestore';
import {
  firestoreCache,
  firestoreCacheMetrics,
  LearningModule,
  CacheMetadata,
  DEFAULT_STATIC_MODULES,
} from '../services/firestoreCacheService';
import { Mission } from '../types';

export interface UseFirestoreCacheState<T> {
  data: T;
  loading: boolean;
  fromCache: boolean;
  hasPendingWrites: boolean;
  lastUpdated: number | null;
  error: Error | null;
  cacheHitRate: string;
}

/**
 * Hook umum untuk subscribe ke koleksi dengan Cache-First
 */
export function useFirestoreCollectionCacheFirst<T = any>(
  collectionName: string,
  constraints: QueryConstraint[] = [],
  initialData: T[] = []
): UseFirestoreCacheState<T[]> {
  const [data, setData] = useState<T[]>(initialData);
  const [loading, setLoading] = useState<boolean>(true);
  const [metadata, setMetadata] = useState<CacheMetadata>({
    fromCache: false,
    hasPendingWrites: false,
    lastUpdated: 0,
    readCountSaved: 0,
  });
  const [error, setError] = useState<Error | null>(null);

  // Mencegah re-subscription yang tidak perlu jika dependensi sama
  const constraintsRef = useRef(constraints);
  constraintsRef.current = constraints;

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    const unsub = firestoreCache.subscribeCollectionCacheFirst<T>(
      collectionName,
      {
        onData: (items, meta) => {
          if (!isMounted) return;
          setData(items);
          setMetadata(meta);
          setLoading(false);
        },
        onError: (err) => {
          if (!isMounted) return;
          setError(err);
          setLoading(false);
        },
        skipUnchangedServerUpdates: true,
      },
      constraintsRef.current
    );

    return () => {
      isMounted = false;
      unsub();
    };
  }, [collectionName]);

  return {
    data,
    loading,
    fromCache: metadata.fromCache,
    hasPendingWrites: metadata.hasPendingWrites,
    lastUpdated: metadata.lastUpdated || null,
    error,
    cacheHitRate: firestoreCacheMetrics.getStats().hitRate,
  };
}

/**
 * Hook khusus untuk Modul Pembelajaran Statis (Cache-First)
 */
export function useLearningModulesCacheFirst(
  subjectId?: string
): UseFirestoreCacheState<LearningModule[]> {
  const [data, setData] = useState<LearningModule[]>(DEFAULT_STATIC_MODULES);
  const [loading, setLoading] = useState<boolean>(true);
  const [metadata, setMetadata] = useState<CacheMetadata>({
    fromCache: true,
    hasPendingWrites: false,
    lastUpdated: Date.now(),
    readCountSaved: DEFAULT_STATIC_MODULES.length,
  });
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let isMounted = true;

    const unsub = firestoreCache.subscribeLearningModules(
      {
        onData: (modules, meta) => {
          if (!isMounted) return;
          setData(modules);
          setMetadata(meta);
          setLoading(false);
        },
        onError: (err) => {
          if (!isMounted) return;
          setError(err);
          setLoading(false);
        },
        skipUnchangedServerUpdates: true,
      },
      subjectId
    );

    return () => {
      isMounted = false;
      unsub();
    };
  }, [subjectId]);

  return {
    data,
    loading,
    fromCache: metadata.fromCache,
    hasPendingWrites: metadata.hasPendingWrites,
    lastUpdated: metadata.lastUpdated || null,
    error,
    cacheHitRate: firestoreCacheMetrics.getStats().hitRate,
  };
}

/**
 * Hook khusus untuk Data Misi Statis (Misi 1-6 per kelas)
 */
export function useMissionsCacheFirst(
  classId?: string,
  initialMissions: Mission[] = []
): UseFirestoreCacheState<Mission[]> {
  const [data, setData] = useState<Mission[]>(initialMissions);
  const [loading, setLoading] = useState<boolean>(initialMissions.length === 0);
  const [metadata, setMetadata] = useState<CacheMetadata>({
    fromCache: false,
    hasPendingWrites: false,
    lastUpdated: 0,
    readCountSaved: 0,
  });
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let isMounted = true;

    const unsub = firestoreCache.subscribeMissions(
      {
        onData: (missions, meta) => {
          if (!isMounted) return;
          setData(missions);
          setMetadata(meta);
          setLoading(false);
        },
        onError: (err) => {
          if (!isMounted) return;
          setError(err);
          setLoading(false);
        },
        skipUnchangedServerUpdates: true,
      },
      classId
    );

    return () => {
      isMounted = false;
      unsub();
    };
  }, [classId]);

  return {
    data,
    loading,
    fromCache: metadata.fromCache,
    hasPendingWrites: metadata.hasPendingWrites,
    lastUpdated: metadata.lastUpdated || null,
    error,
    cacheHitRate: firestoreCacheMetrics.getStats().hitRate,
  };
}

import React from 'react';
import { Home, Compass, User } from 'lucide-react';

export type MuridTabType = 'beranda' | 'misi' | 'profil' | 'ai' | 'lab' | 'portofolio';

interface MuridBottomNavProps {
  activeTab: MuridTabType;
  onTabChange: (tab: MuridTabType) => void;
}

export const MuridBottomNav: React.FC<MuridBottomNavProps> = ({
  activeTab,
  onTabChange,
}) => {
  // 3 Menu Utama yang Ceria dan Hidup: Beranda, Misi, Profil
  const tabs = [
    {
      id: 'beranda' as MuridTabType,
      label: 'Beranda',
      icon: Home,
      accentColor: 'from-blue-500 via-sky-500 to-indigo-500',
      activeLabelColor: 'text-blue-700',
      activeIconBg: 'bg-gradient-to-tr from-blue-600 via-sky-500 to-indigo-500 text-white shadow-md shadow-blue-500/35 border border-sky-300/70',
      inactiveIconColor: 'text-sky-600 group-hover:text-blue-700',
      inactiveHoverBg: 'group-hover:bg-sky-50/80',
      activeCapsuleBg: 'bg-gradient-to-b from-blue-50/90 to-sky-50/70 border-blue-200/90 shadow-xs shadow-blue-500/15',
      glowColor: 'from-blue-500/40 via-sky-400/30 to-indigo-500/35',
      iconGlow: 'drop-shadow-[0_0_8px_rgba(14,165,233,0.6)]',
    },
    {
      id: 'misi' as MuridTabType,
      label: 'Misi',
      icon: Compass,
      accentColor: 'from-amber-500 via-orange-500 to-rose-500',
      activeLabelColor: 'text-orange-700',
      activeIconBg: 'bg-gradient-to-tr from-amber-500 via-orange-500 to-rose-500 text-white shadow-md shadow-orange-500/35 border border-amber-200/70',
      inactiveIconColor: 'text-amber-600 group-hover:text-orange-700',
      inactiveHoverBg: 'group-hover:bg-amber-50/80',
      activeCapsuleBg: 'bg-gradient-to-b from-amber-50/90 to-orange-50/70 border-amber-200/90 shadow-xs shadow-amber-500/15',
      glowColor: 'from-amber-500/45 via-orange-500/35 to-rose-400/30',
      iconGlow: 'drop-shadow-[0_0_8px_rgba(249,115,22,0.6)]',
    },
    {
      id: 'profil' as MuridTabType,
      label: 'Profil',
      icon: User,
      accentColor: 'from-violet-600 via-purple-500 to-fuchsia-500',
      activeLabelColor: 'text-purple-700',
      activeIconBg: 'bg-gradient-to-tr from-violet-600 via-purple-500 to-fuchsia-500 text-white shadow-md shadow-purple-500/35 border border-purple-300/70',
      inactiveIconColor: 'text-purple-600 group-hover:text-violet-700',
      inactiveHoverBg: 'group-hover:bg-purple-50/80',
      activeCapsuleBg: 'bg-gradient-to-b from-purple-50/90 to-fuchsia-50/70 border-purple-200/90 shadow-xs shadow-purple-500/15',
      glowColor: 'from-violet-500/40 via-purple-500/35 to-fuchsia-400/30',
      iconGlow: 'drop-shadow-[0_0_8px_rgba(168,85,247,0.6)]',
    },
  ];

  // Current active tab object for dock-level ambient living glow
  const currentTab =
    tabs.find(
      (t) =>
        t.id === activeTab ||
        (t.id === 'misi' && activeTab === 'lab') ||
        (t.id === 'profil' && activeTab === 'portofolio')
    ) || tabs[0];

  return (
    <nav
      id="murid-bottom-nav"
      style={{
        paddingBottom: 'env(safe-area-inset-bottom, 0px)',
      }}
      className="sticky bottom-0 left-0 right-0 w-full z-40 shrink-0 bg-white/98 backdrop-blur-2xl border-t border-slate-200/90 shadow-[0_-4px_24px_rgba(15,23,42,0.08)] transition-all select-none"
    >
      {/* Subtle Living Ambient Glow accent line at top border matching active tab */}
      <div
        className={`h-0.5 w-full bg-gradient-to-r ${currentTab.glowColor} opacity-75 transition-all duration-500`}
      />

      <div className="max-w-md mx-auto relative px-3 py-1.5 sm:py-2">
        {/* Soft Ambient Floating Glow behind Active Tab */}
        <div
          className={`absolute inset-x-12 -top-2 h-8 bg-gradient-to-r ${currentTab.glowColor} blur-xl opacity-40 transition-all duration-500 -z-10 pointer-events-none`}
        />

        {/* Buttons Container maintaining exact position, layout & colors */}
        <div className="flex items-center justify-around gap-1.5 sm:gap-2">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive =
              activeTab === tab.id ||
              (tab.id === 'misi' && activeTab === 'lab') ||
              (tab.id === 'profil' && activeTab === 'portofolio');

            return (
              <button
                key={tab.id}
                id={`nav-tab-${tab.id}`}
                type="button"
                onClick={() => onTabChange(tab.id)}
                className={`flex-1 max-w-[124px] min-h-[52px] py-1 px-2 flex flex-col items-center justify-center gap-0.5 rounded-2xl relative select-none cursor-pointer group transition-all duration-300 ease-out active:scale-95 ${
                  isActive
                    ? `${tab.activeLabelColor} font-black -translate-y-1 sm:-translate-y-1.5`
                    : 'text-slate-600 hover:text-slate-900 font-bold'
                }`}
                style={{
                  WebkitTapHighlightColor: 'transparent',
                  touchAction: 'manipulation',
                }}
              >
                {/* Active Indicator Top Pill & Background Capsule */}
                {isActive && (
                  <>
                    <span
                      className={`absolute inset-0 rounded-2xl ${tab.activeCapsuleBg} -z-10 transition-all duration-300`}
                    />
                    <span
                      className={`absolute -top-1 w-9 h-1 rounded-full bg-gradient-to-r ${tab.accentColor} shadow-[0_0_10px_currentColor] transition-all duration-300 animate-pulse`}
                    />
                  </>
                )}

                {/* Animated Icon Container with Living Gradient & Float Lift */}
                <div
                  className={`w-11 h-7.5 rounded-xl flex items-center justify-center transition-all duration-300 ${
                    isActive
                      ? `${tab.activeIconBg} scale-110`
                      : `${tab.inactiveIconColor} ${tab.inactiveHoverBg} group-hover:scale-110 group-hover:-translate-y-0.5`
                  }`}
                >
                  <Icon
                    className={`w-4.5 h-4.5 transition-transform duration-300 ${
                      isActive
                        ? `stroke-[2.5] ${tab.iconGlow}`
                        : 'stroke-[2.2]'
                    }`}
                  />
                </div>

                {/* Tab Label with Cheerful Typography */}
                <span
                  className={`text-[11px] leading-tight tracking-tight whitespace-nowrap transition-all duration-200 mt-0.5 ${
                    isActive ? 'font-black scale-105' : 'font-semibold'
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};

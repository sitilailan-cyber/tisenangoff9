import React, { useState } from 'react';
import {
  FlaskConical,
  TestTube,
  Droplets,
  Plus,
  RotateCcw,
  Sparkles,
  Info,
  CheckCircle2,
} from 'lucide-react';

interface SimulasiAsamBasaProps {
  onRecordData: (data: {
    param1: string; // Nama Larutan
    param2: string; // Hasil Lakmus Merah & Biru
    param3: string; // Nilai pH
    catatan: string; // Sifat Asam / Basa / Netral
  }) => void;
}

interface SolutionSample {
  id: string;
  name: string;
  formula: string;
  color: string;
  liquidBg: string;
  ph: number;
  lakmusMerahResult: 'merah' | 'biru';
  lakmusBiruResult: 'merah' | 'biru';
  universalColor: string;
  sifat: 'Asam Kuat' | 'Asam Lemah' | 'Netral' | 'Basa Lemah' | 'Basa Kuat';
  description: string;
}

const SOLUTIONS: SolutionSample[] = [
  {
    id: 'sol-1',
    name: 'Asam Klorida (HCl 0.1 M)',
    formula: 'HCl',
    color: '#38bdf8',
    liquidBg: 'from-sky-500/50 to-blue-600/70',
    ph: 1.0,
    lakmusMerahResult: 'merah',
    lakmusBiruResult: 'merah',
    universalColor: '#ef4444', // Merah terang
    sifat: 'Asam Kuat',
    description: 'Terionisasi sempurna menghasilkan konsentrasi ion H⁺ tinggi.',
  },
  {
    id: 'sol-2',
    name: 'Asam Cuka (CH₃COOH)',
    formula: 'CH₃COOH',
    color: '#fbbf24',
    liquidBg: 'from-amber-400/40 to-yellow-600/60',
    ph: 2.9,
    lakmusMerahResult: 'merah',
    lakmusBiruResult: 'merah',
    universalColor: '#f97316', // Oranye
    sifat: 'Asam Lemah',
    description: 'Asam karboksilat terionisasi sebagian, derajat ionisasi α < 1.',
  },
  {
    id: 'sol-3',
    name: 'Jus Jeruk Alami',
    formula: 'Asam Sitrat',
    color: '#f97316',
    liquidBg: 'from-orange-400/60 to-amber-600/70',
    ph: 3.8,
    lakmusMerahResult: 'merah',
    lakmusBiruResult: 'merah',
    universalColor: '#fbbf24', // Kuning-Oranye
    sifat: 'Asam Lemah',
    description: 'Mengandung asam sitrat dan asam askorbat bervalensi organik.',
  },
  {
    id: 'sol-4',
    name: 'Air Akuades Murni (H₂O)',
    formula: 'H₂O',
    color: '#06b6d4',
    liquidBg: 'from-cyan-400/30 to-blue-500/40',
    ph: 7.0,
    lakmusMerahResult: 'merah',
    lakmusBiruResult: 'biru',
    universalColor: '#22c55e', // Hijau netral
    sifat: 'Netral',
    description: 'Konsentrasi [H⁺] sama dengan [OH⁻] = 10⁻⁷ M pada suhu 25°C.',
  },
  {
    id: 'sol-5',
    name: 'Air Sabun / Detergen',
    formula: 'R-COONa',
    color: '#a855f7',
    liquidBg: 'from-purple-400/40 to-indigo-600/60',
    ph: 9.5,
    lakmusMerahResult: 'biru',
    lakmusBiruResult: 'biru',
    universalColor: '#0ea5e9', // Biru muda
    sifat: 'Basa Lemah',
    description: 'Mengalami hidrolisis anion asam lemah menghasilkan ion OH⁻.',
  },
  {
    id: 'sol-6',
    name: 'Natrium Hidroksida (NaOH 0.1 M)',
    formula: 'NaOH',
    color: '#6366f1',
    liquidBg: 'from-indigo-400/50 to-violet-700/70',
    ph: 13.0,
    lakmusMerahResult: 'biru',
    lakmusBiruResult: 'biru',
    universalColor: '#7c3aed', // Ungu gelap
    sifat: 'Basa Kuat',
    description: 'Basa alkali terdisosiasi penuh menghasilkan ion hidroksida pekat.',
  },
];

type IndicatorTool = 'lakmus_merah' | 'lakmus_biru' | 'universal' | 'ph_meter';

export const SimulasiAsamBasa: React.FC<SimulasiAsamBasaProps> = ({ onRecordData }) => {
  const [selectedSolutionId, setSelectedSolutionId] = useState<string>('sol-1');
  const [activeTool, setActiveTool] = useState<IndicatorTool>('lakmus_merah');
  const [isDipped, setIsDipped] = useState<boolean>(false);
  const [testedResults, setTestedResults] = useState<Record<string, { merah?: boolean; biru?: boolean; universal?: boolean; ph?: boolean }>>({});

  const activeSolution = SOLUTIONS.find((s) => s.id === selectedSolutionId) || SOLUTIONS[0];

  const handleDipTest = () => {
    setIsDipped(true);
    setTestedResults((prev) => ({
      ...prev,
      [activeSolution.id]: {
        ...prev[activeSolution.id],
        [activeTool === 'lakmus_merah'
          ? 'merah'
          : activeTool === 'lakmus_biru'
          ? 'biru'
          : activeTool === 'universal'
          ? 'universal'
          : 'ph']: true,
      },
    }));
  };

  const handleSelectSolution = (solId: string) => {
    setSelectedSolutionId(solId);
    setIsDipped(false);
  };

  const handleRecord = () => {
    onRecordData({
      param1: `${activeSolution.name} (${activeSolution.formula})`,
      param2: `Lakmus M: ${activeSolution.lakmusMerahResult.toUpperCase()} • Lakmus B: ${activeSolution.lakmusBiruResult.toUpperCase()}`,
      param3: `pH = ${activeSolution.ph.toFixed(1)}`,
      catatan: `Sifat: ${activeSolution.sifat}. ${activeSolution.description}`,
    });
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 sm:p-6 space-y-6">
      {/* Header Simulasi Asam Basa */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 text-[10px] font-black uppercase">
            Kimia: Larutan Asam & Basa
          </span>
          <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-emerald-600" />
            <span>Simulasi Pengujian Asam dan Basa</span>
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Uji 6 sampel larutan menggunakan kertas lakmus merah, lakmus biru, indikator universal, dan pH meter digital.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRecord}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Catat ke Tabel</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Stage Tabung Reaksi & Uji Indikator */}
        <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-5 sm:p-6 border border-slate-800 flex flex-col items-center justify-between relative shadow-xl min-h-[410px]">
          {/* Layar Digital pH Floating */}
          {isDipped && activeTool === 'ph_meter' && (
            <div className="absolute top-4 left-4 bg-slate-900/95 border border-slate-700 px-3 py-1.5 rounded-xl font-mono text-center shadow-lg z-20 animate-in fade-in">
              <span className="block text-[8px] uppercase tracking-wider text-slate-400">
                Probe pH Meter
              </span>
              <span className="text-xl font-black text-emerald-400">
                pH {activeSolution.ph.toFixed(1)}
              </span>
            </div>
          )}

          {/* Info Larutan Aktif */}
          <div className="text-center space-y-1 mb-2 z-10">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">
              Tabung Sampel Terpilih
            </span>
            <div className="text-base sm:text-lg font-black text-white flex items-center justify-center gap-2">
              <span>{activeSolution.name}</span>
            </div>
          </div>

          {/* Animasi Tabung Reaksi & Kertas / Alat Uji yang Dicelupkan */}
          <div className="relative w-48 h-64 flex flex-col items-center justify-end my-4">
            {/* Kertas Lakmus / Indikator Strip yang dicelupkan */}
            <div
              className={`absolute w-7 rounded-t-md transition-all duration-500 z-20 shadow-lg flex flex-col justify-end items-center overflow-hidden border border-white/20 ${
                isDipped ? 'top-10 h-44' : '-top-8 h-28 opacity-80'
              }`}
              style={{
                backgroundColor:
                  activeTool === 'lakmus_merah'
                    ? isDipped
                      ? activeSolution.lakmusMerahResult === 'merah'
                        ? '#ef4444'
                        : '#3b82f6'
                      : '#ef4444'
                    : activeTool === 'lakmus_biru'
                    ? isDipped
                      ? activeSolution.lakmusBiruResult === 'biru'
                        ? '#3b82f6'
                        : '#ef4444'
                      : '#3b82f6'
                    : activeTool === 'universal'
                    ? isDipped
                      ? activeSolution.universalColor
                      : '#fef08a'
                    : '#475569',
              }}
            >
              {activeTool === 'ph_meter' && (
                <div className="w-2 h-full bg-slate-300 rounded-b-md flex flex-col justify-end items-center">
                  <div className="w-4 h-4 rounded-full bg-emerald-500 mb-1" />
                </div>
              )}
              {activeTool !== 'ph_meter' && (
                <span className="text-[7px] font-black text-white/90 uppercase tracking-tighter mb-1 select-none">
                  {isDipped ? 'REAKSI' : 'STRIP'}
                </span>
              )}
            </div>

            {/* Bentuk Tabung Reaksi Kaca (Glass Test Tube) */}
            <div className="relative w-28 h-56 border-4 border-t-0 border-slate-400/60 rounded-b-full bg-slate-800/30 overflow-hidden flex flex-col justify-end p-2 backdrop-blur-xs shadow-2xl">
              {/* Efek Refleksi Kaca */}
              <div className="absolute top-0 left-2 w-1.5 h-44 bg-white/20 rounded-full" />
              <div className="absolute top-0 right-2 w-1 h-36 bg-white/10 rounded-full" />

              {/* Cairan Larutan di dalam Tabung */}
              <div
                className={`w-full h-40 rounded-b-full bg-gradient-to-t ${activeSolution.liquidBg} transition-all duration-300 relative flex items-center justify-center`}
              >
                {/* Gelembung Udara Kecil */}
                <span className="w-1.5 h-1.5 rounded-full bg-white/40 absolute bottom-6 left-6 animate-ping" />
                <span className="w-2 h-2 rounded-full bg-white/50 absolute bottom-12 right-6 animate-bounce" />
                <span className="text-xs font-mono font-bold text-white/80 z-10 drop-shadow-md">
                  {activeSolution.formula}
                </span>
              </div>
            </div>

            {/* Rak Tabung Bawah */}
            <div className="w-44 h-4 bg-slate-800 rounded-lg border border-slate-700 shadow-md -mt-1" />
          </div>

          {/* Tombol Celupkan / Angkat Uji */}
          <div className="w-full flex items-center justify-center gap-3 mt-2 z-10">
            <button
              type="button"
              onClick={handleDipTest}
              disabled={isDipped}
              className="px-6 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shadow-emerald-600/30 cursor-pointer transition-all active:scale-95"
            >
              <Droplets className="w-4 h-4" />
              <span>Celupkan Alat Uji</span>
            </button>

            {isDipped && (
              <button
                type="button"
                onClick={() => setIsDipped(false)}
                className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs flex items-center gap-1.5 border border-slate-700 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Angkat & Bersihkan</span>
              </button>
            )}
          </div>
        </div>

        {/* Panel Pilihan Larutan & Alat Uji */}
        <div className="lg:col-span-5 space-y-4">
          {/* 1. Pilih Alat Indikator Uji */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
            <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
              1. Pilih Alat Indikator Uji
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'lakmus_merah' as IndicatorTool, label: 'Kertas Lakmus Merah', color: 'border-red-400 text-red-600' },
                { id: 'lakmus_biru' as IndicatorTool, label: 'Kertas Lakmus Biru', color: 'border-blue-400 text-blue-600' },
                { id: 'universal' as IndicatorTool, label: 'Indikator Universal', color: 'border-amber-400 text-amber-600' },
                { id: 'ph_meter' as IndicatorTool, label: 'pH Meter Digital', color: 'border-emerald-400 text-emerald-600' },
              ].map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => {
                    setActiveTool(t.id);
                    setIsDipped(false);
                  }}
                  className={`py-2 px-2.5 rounded-xl text-xs font-bold text-left transition-all cursor-pointer border ${
                    activeTool === t.id
                      ? 'bg-emerald-600 text-white border-emerald-500 shadow-sm font-black'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-emerald-300'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* 2. Rak 6 Sampel Larutan */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
            <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
              2. Pilih Tabung Sampel Larutan
            </label>
            <div className="space-y-1.5">
              {SOLUTIONS.map((sol) => {
                const isSelected = sol.id === selectedSolutionId;
                return (
                  <button
                    key={sol.id}
                    type="button"
                    onClick={() => handleSelectSolution(sol.id)}
                    className={`w-full p-2.5 rounded-xl text-left text-xs font-bold transition-all cursor-pointer flex items-center justify-between border ${
                      isSelected
                        ? 'bg-slate-900 text-white border-emerald-500 shadow-md ring-1 ring-emerald-500/50'
                        : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <span
                        className="w-3.5 h-3.5 rounded-full shrink-0 border border-white/20"
                        style={{ backgroundColor: sol.color }}
                      />
                      <span className="truncate">{sol.name}</span>
                    </div>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-300 shrink-0">
                      {sol.formula}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Hasil Uji Sifat Larutan */}
          {isDipped && (
            <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 text-xs space-y-1.5 animate-in fade-in">
              <div className="font-bold flex items-center gap-1.5 text-emerald-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Hasil Pengujian Saintifik:</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[11px] font-mono pt-1">
                <div>
                  <span className="text-slate-400 block">Lakmus Merah:</span>
                  <span className={activeSolution.lakmusMerahResult === 'merah' ? 'text-rose-400 font-bold' : 'text-blue-400 font-bold'}>
                    Tetap {activeSolution.lakmusMerahResult.toUpperCase()}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Lakmus Biru:</span>
                  <span className={activeSolution.lakmusBiruResult === 'merah' ? 'text-rose-400 font-bold' : 'text-blue-400 font-bold'}>
                    Menjadi {activeSolution.lakmusBiruResult.toUpperCase()}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">pH Skala Universal:</span>
                  <span className="text-amber-300 font-bold">{activeSolution.ph.toFixed(1)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block">Klasifikasi Sifat:</span>
                  <span className="text-emerald-300 font-bold">{activeSolution.sifat}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

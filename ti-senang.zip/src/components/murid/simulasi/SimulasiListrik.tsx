import React, { useState, useMemo, useEffect } from 'react';
import {
  Zap,
  Play,
  Square,
  RotateCcw,
  Plus,
  HelpCircle,
  Lightbulb,
  Gauge,
  Sliders,
  CheckCircle2,
} from 'lucide-react';

interface SimulasiListrikProps {
  onRecordData: (data: {
    param1: string; // Tegangan (V)
    param2: string; // Hambatan (R) & Mode
    param3: string; // Arus (I) & Daya (P)
    catatan: string;
  }) => void;
}

type CircuitMode = 'tunggal' | 'seri' | 'paralel';

export const SimulasiListrik: React.FC<SimulasiListrikProps> = ({ onRecordData }) => {
  const [circuitMode, setCircuitMode] = useState<CircuitMode>('tunggal');
  const [switchClosed, setSwitchClosed] = useState<boolean>(true); // Saklar ON/OFF
  const [voltage, setVoltage] = useState<number>(12); // Volt (1 - 24V)
  const [resistor1, setResistor1] = useState<number>(10); // Ohm (2 - 50 Ohm)
  const [resistor2, setResistor2] = useState<number>(15); // Ohm (2 - 50 Ohm)
  const lampResistance = 5; // Hambatan internal lampu = 5 Ohm

  // Hitung Hambatan Total (R_total)
  const totalResistance = useMemo(() => {
    switch (circuitMode) {
      case 'tunggal':
        return resistor1 + lampResistance;
      case 'seri':
        return resistor1 + resistor2 + lampResistance;
      case 'paralel': {
        const rParallel = (resistor1 * resistor2) / (resistor1 + resistor2);
        return rParallel + lampResistance;
      }
    }
  }, [circuitMode, resistor1, resistor2]);

  // Arus total (I = V / R) jika saklar tertutup
  const currentAmpere = useMemo(() => {
    if (!switchClosed) return 0;
    return Number((voltage / totalResistance).toFixed(3));
  }, [switchClosed, voltage, totalResistance]);

  // Daya listrik total (P = V * I)
  const powerWatt = useMemo(() => {
    if (!switchClosed) return 0;
    return Number((voltage * currentAmpere).toFixed(2));
  }, [switchClosed, voltage, currentAmpere]);

  // Daya pada lampu (Plampu = I_lampu² * R_lampu)
  const lampPower = useMemo(() => {
    if (!switchClosed) return 0;
    return Number((Math.pow(currentAmpere, 2) * lampResistance).toFixed(2));
  }, [switchClosed, currentAmpere]);

  // Kecerahan lampu (0 - 100%)
  const lampBrightness = useMemo(() => {
    if (!switchClosed) return 0;
    // Skala normal lampu 12V 5 ohm = ~25W full bright
    return Math.min(100, Math.round((lampPower / 25) * 100));
  }, [switchClosed, lampPower]);

  // Animasi pergerakan elektron
  const [animTick, setAnimTick] = useState<number>(0);
  useEffect(() => {
    if (!switchClosed || currentAmpere === 0) return;
    const interval = setInterval(() => {
      setAnimTick((t) => (t + 1) % 100);
    }, 50);
    return () => clearInterval(interval);
  }, [switchClosed, currentAmpere]);

  const handleRecord = () => {
    let modeLabel = 'Rangkaian Tunggal';
    if (circuitMode === 'seri') modeLabel = `Rangkaian Seri (R1=${resistor1}Ω, R2=${resistor2}Ω)`;
    if (circuitMode === 'paralel') modeLabel = `Rangkaian Paralel (R1=${resistor1}Ω // R2=${resistor2}Ω)`;

    onRecordData({
      param1: `${voltage} Volt`,
      param2: `${totalResistance.toFixed(1)} Ω (${modeLabel})`,
      param3: `I = ${currentAmpere} A, P = ${powerWatt} W`,
      catatan: switchClosed
        ? `Hukum Ohm I=V/R. Lampu menyala kecerahan ${lampBrightness}% (Daya lampu ${lampPower} W)`
        : 'Saklar terbuka (Rangkaian putus, arus 0 A)',
    });
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 sm:p-6 space-y-6">
      {/* Header Simulasi Listrik */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
        <div>
          <span className="px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 text-[10px] font-black uppercase">
            Fisika: Kelistrikan & Hukum Ohm
          </span>
          <h3 className="text-base font-black text-slate-900 dark:text-white mt-1 flex items-center gap-2">
            <Zap className="w-5 h-5 text-amber-500 fill-amber-500" />
            <span>Simulasi Rangkaian Listrik & Hukum Ohm</span>
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Uji hubungan antara Beda Potensial (<code className="font-mono text-blue-600 font-bold">V</code>),
            Hambatan (<code className="font-mono text-purple-600 font-bold">R</code>), dan Kuat Arus Listrik (
            <code className="font-mono text-amber-600 font-bold">I = V/R</code>) pada rangkaian seri, paralel, dan tunggal.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRecord}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-all active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Catat ke Tabel</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Visual Rangkaian Elektronika (Circuit Board) */}
        <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-4 sm:p-6 border border-slate-800 flex flex-col items-center justify-center relative overflow-hidden shadow-xl min-h-[390px]">
          {/* Layar Multimeter Digital Floating */}
          <div className="absolute top-4 left-4 bg-slate-900/95 border border-slate-700/80 p-2.5 rounded-2xl flex items-center gap-4 text-xs font-mono shadow-lg z-20">
            <div>
              <span className="block text-[8px] uppercase tracking-wider text-slate-400">Voltmeter</span>
              <span className="text-sm font-black text-blue-400">{voltage.toFixed(1)} V</span>
            </div>
            <div className="w-px h-6 bg-slate-700" />
            <div>
              <span className="block text-[8px] uppercase tracking-wider text-slate-400">Amperemeter</span>
              <span className="text-sm font-black text-amber-400">{currentAmpere.toFixed(3)} A</span>
            </div>
            <div className="w-px h-6 bg-slate-700" />
            <div>
              <span className="block text-[8px] uppercase tracking-wider text-slate-400">Wattmeter</span>
              <span className="text-sm font-black text-emerald-400">{powerWatt.toFixed(1)} W</span>
            </div>
          </div>

          {/* Status Saklar */}
          <div className="absolute top-4 right-4 z-20">
            <button
              type="button"
              onClick={() => setSwitchClosed(!switchClosed)}
              className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 border transition-all cursor-pointer shadow-md ${
                switchClosed
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                  : 'bg-rose-500/20 text-rose-300 border-rose-500/50 animate-pulse'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${switchClosed ? 'bg-emerald-400' : 'bg-rose-400'}`} />
              <span>Saklar: {switchClosed ? 'ON (Tertutup)' : 'OFF (Terbuka)'}</span>
            </button>
          </div>

          {/* Skema Rangkaian Menggunakan SVG Interaktif */}
          <svg viewBox="0 0 420 280" className="w-full h-auto max-h-[300px] mt-10">
            {/* Jalur Kabel Utama (Wire Rectangle) */}
            <rect
              x="50"
              y="40"
              width="320"
              height="200"
              rx="16"
              fill="none"
              stroke="#334155"
              strokeWidth="6"
            />

            {/* Jalur Animasi Arus Listrik (Aliran Elektron) */}
            {switchClosed && currentAmpere > 0 && (
              <rect
                x="50"
                y="40"
                width="320"
                height="200"
                rx="16"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="2.5"
                strokeDasharray="8 12"
                strokeDashoffset={-animTick * 3}
                opacity="0.9"
              />
            )}

            {/* KOMPONEN 1: BATERAI / SUMBER TEGANGAN (Sisi Kiri x=50, y=140) */}
            <g transform="translate(50, 140)">
              {/* Tutup kabel di titik baterai */}
              <rect x="-6" y="-25" width="12" height="50" fill="#020617" />
              {/* Plat Positif */}
              <line x1="-16" y1="-18" x2="16" y2="-18" stroke="#38bdf8" strokeWidth="4" />
              <text x="22" y="-14" fill="#38bdf8" fontSize="10" fontWeight="bold">
                +
              </text>
              {/* Plat Negatif */}
              <line x1="-8" y1="-6" x2="8" y2="-6" stroke="#94a3b8" strokeWidth="3" />
              {/* Plat Positif 2 */}
              <line x1="-16" y1="6" x2="16" y2="6" stroke="#38bdf8" strokeWidth="4" />
              {/* Plat Negatif 2 */}
              <line x1="-8" y1="18" x2="8" y2="18" stroke="#94a3b8" strokeWidth="3" />
              <text x="22" y="22" fill="#94a3b8" fontSize="10" fontWeight="bold">
                -
              </text>
              <text
                x="-26"
                y="4"
                fill="#38bdf8"
                fontSize="11"
                fontFamily="monospace"
                fontWeight="bold"
                textAnchor="end"
              >
                {voltage}V
              </text>
            </g>

            {/* KOMPONEN 2: SAKLAR (Sisi Atas x=150, y=40) */}
            <g transform="translate(150, 40)">
              <rect x="-20" y="-8" width="40" height="16" fill="#020617" />
              <circle cx="-14" cy="0" r="3.5" fill="#f59e0b" />
              <circle cx="14" cy="0" r="3.5" fill="#f59e0b" />
              {switchClosed ? (
                <line x1="-14" y1="0" x2="14" y2="0" stroke="#f59e0b" strokeWidth="3" />
              ) : (
                <line x1="-14" y1="0" x2="8" y2="-16" stroke="#ef4444" strokeWidth="3" />
              )}
            </g>

            {/* KOMPONEN 3: RESISTOR (Sisi Atas / Tengah x=270, y=40) */}
            {circuitMode === 'tunggal' && (
              <g transform="translate(270, 40)">
                <rect x="-24" y="-12" width="48" height="24" rx="4" fill="#1e293b" stroke="#cbd5e1" strokeWidth="1.5" />
                {/* Pita Warna Resistor */}
                <line x1="-12" y1="-10" x2="-12" y2="10" stroke="#9333ea" strokeWidth="3" />
                <line x1="-4" y1="-10" x2="-4" y2="10" stroke="#f59e0b" strokeWidth="3" />
                <line x1="4" y1="-10" x2="4" y2="10" stroke="#3b82f6" strokeWidth="3" />
                <line x1="12" y1="-10" x2="12" y2="10" stroke="#eab308" strokeWidth="2" />
                <text x="0" y="-18" fill="#e2e8f0" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                  R = {resistor1}Ω
                </text>
              </g>
            )}

            {circuitMode === 'seri' && (
              <g transform="translate(270, 40)">
                {/* Resistor 1 */}
                <rect x="-44" y="-10" width="36" height="20" rx="3" fill="#1e293b" stroke="#cbd5e1" strokeWidth="1.5" />
                <text x="-26" y="-14" fill="#e2e8f0" fontSize="9" fontFamily="monospace" textAnchor="middle">
                  R1: {resistor1}Ω
                </text>
                {/* Resistor 2 */}
                <rect x="8" y="-10" width="36" height="20" rx="3" fill="#1e293b" stroke="#cbd5e1" strokeWidth="1.5" />
                <text x="26" y="-14" fill="#e2e8f0" fontSize="9" fontFamily="monospace" textAnchor="middle">
                  R2: {resistor2}Ω
                </text>
              </g>
            )}

            {circuitMode === 'paralel' && (
              <g transform="translate(270, 40)">
                {/* Cabang Paralel Atas & Bawah */}
                <line x1="-40" y1="-20" x2="40" y2="-20" stroke="#334155" strokeWidth="4" />
                <line x1="-40" y1="20" x2="40" y2="20" stroke="#334155" strokeWidth="4" />
                <line x1="-40" y1="-20" x2="-40" y2="20" stroke="#334155" strokeWidth="4" />
                <line x1="40" y1="-20" x2="40" y2="20" stroke="#334155" strokeWidth="4" />

                {/* Resistor Cabang 1 */}
                <rect x="-18" y="-28" width="36" height="16" rx="3" fill="#1e293b" stroke="#cbd5e1" strokeWidth="1.5" />
                <text x="0" y="-32" fill="#38bdf8" fontSize="8" fontFamily="monospace" textAnchor="middle">
                  R1: {resistor1}Ω
                </text>
                {/* Resistor Cabang 2 */}
                <rect x="-18" y="12" width="36" height="16" rx="3" fill="#1e293b" stroke="#cbd5e1" strokeWidth="1.5" />
                <text x="0" y="38" fill="#a855f7" fontSize="8" fontFamily="monospace" textAnchor="middle">
                  R2: {resistor2}Ω
                </text>
              </g>
            )}

            {/* KOMPONEN 4: LAMPU PIJAR (Sisi Bawah x=210, y=240) */}
            <g transform="translate(210, 240)">
              {/* Tutup kabel di titik lampu */}
              <rect x="-25" y="-15" width="50" height="30" fill="#020617" />

              {/* Efek Cahaya / Glow Lampu */}
              {lampBrightness > 0 && (
                <circle
                  cx="0"
                  cy="0"
                  r={22 + (lampBrightness / 100) * 28}
                  fill="#facc15"
                  opacity={0.15 + (lampBrightness / 100) * 0.4}
                  className="blur-xs"
                />
              )}

              {/* Kaca Bohlam Lampu */}
              <circle
                cx="0"
                cy="0"
                r="18"
                fill={lampBrightness > 10 ? '#fde047' : '#334155'}
                stroke="#e2e8f0"
                strokeWidth="1.5"
                opacity={0.7 + (lampBrightness / 100) * 0.3}
              />
              {/* Filamen Lampu */}
              <path
                d="M -7 6 L -3 -6 L 0 2 L 3 -6 L 7 6"
                fill="none"
                stroke={lampBrightness > 0 ? '#b45309' : '#64748b'}
                strokeWidth="2"
              />
              <text x="0" y="30" fill="#fde047" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
                Lampu ({lampBrightness}%)
              </text>
            </g>
          </svg>
        </div>

        {/* Panel Kontrol Rangkaian Listrik */}
        <div className="lg:col-span-5 space-y-4">
          {/* Pilihan Mode Rangkaian */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2">
            <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
              1. Pilih Konfigurasi Rangkaian
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'tunggal' as CircuitMode, label: 'Tunggal' },
                { id: 'seri' as CircuitMode, label: 'Seri' },
                { id: 'paralel' as CircuitMode, label: 'Paralel' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setCircuitMode(m.id)}
                  className={`py-2 px-2 text-center rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                    circuitMode === m.id
                      ? 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-xs'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-amber-300'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Slider Tegangan dan Resistor */}
          <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3.5">
            <label className="text-[11px] font-black uppercase tracking-wider text-slate-500 block">
              2. Variabel Sumber Tegangan & Resistor
            </label>

            {/* Slider Tegangan (V) */}
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-600 dark:text-slate-400">Tegangan Baterai (V):</span>
                <span className="text-blue-600 font-mono font-black">{voltage} Volt</span>
              </div>
              <input
                type="range"
                min="1"
                max="24"
                step="1"
                value={voltage}
                onChange={(e) => setVoltage(Number(e.target.value))}
                className="w-full accent-blue-600 cursor-pointer"
              />
            </div>

            {/* Slider Resistor 1 */}
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span className="text-slate-600 dark:text-slate-400">Hambatan Resistor 1 (R₁):</span>
                <span className="text-amber-600 font-mono font-black">{resistor1} Ω</span>
              </div>
              <input
                type="range"
                min="2"
                max="50"
                step="1"
                value={resistor1}
                onChange={(e) => setResistor1(Number(e.target.value))}
                className="w-full accent-amber-600 cursor-pointer"
              />
            </div>

            {/* Slider Resistor 2 (Jika Seri / Paralel) */}
            {(circuitMode === 'seri' || circuitMode === 'paralel') && (
              <div>
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="text-slate-600 dark:text-slate-400">Hambatan Resistor 2 (R₂):</span>
                  <span className="text-purple-600 font-mono font-black">{resistor2} Ω</span>
                </div>
                <input
                  type="range"
                  min="2"
                  max="50"
                  step="1"
                  value={resistor2}
                  onChange={(e) => setResistor2(Number(e.target.value))}
                  className="w-full accent-purple-600 cursor-pointer"
                />
              </div>
            )}

            {/* Rangkuman Nilai Perhitungan Riil */}
            <div className="p-3 rounded-xl bg-slate-900 text-white font-mono text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-400">R Total (+ Lampu 5Ω):</span>
                <span className="text-cyan-300 font-bold">{totalResistance.toFixed(1)} Ω</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Arus I = V / R_total:</span>
                <span className="text-amber-300 font-bold">{currentAmpere} A</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Daya Lampu (P):</span>
                <span className="text-emerald-300 font-bold">{lampPower} Watt</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

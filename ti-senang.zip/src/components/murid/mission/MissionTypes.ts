import { Mission, StudentProgress, AlmeRecommendation, StudentProfileData } from '../../../types';

export type GameMissionStatus = 'completed' | 'available' | 'locked' | 'recommended';
export type SubjectFilter = 'SEMUA' | 'MATEMATIKA' | 'FISIKA' | 'KIMIA' | 'BIOLOGI';

export interface GameMissionItem {
  id: string;
  missionNumber: number;
  missionCode: string; // e.g. "MISSION 01"
  themeTitle: string; // e.g. "DATA EXPLORER"
  title: string;
  description: string;
  subjectCategory: 'Matematika' | 'Fisika' | 'Kimia' | 'Biologi' | 'MIPA';
  subjectName: string;
  difficulty: 'Fundamental' | 'Intermediate' | 'Advanced' | 'Expert' | 'Final Challenge';
  xpReward: number;
  status: GameMissionStatus;
  requiredMissionText: string;
  isUnlocked: boolean;
  score?: number;
  estimatedTime: string;
  isRecommended: boolean;
  recommendationReason?: string;
  iconType: 'barchart' | 'thermometer' | 'sun' | 'atom' | 'leaf' | 'microscope' | 'trophy' | 'calculator' | 'activity';
  progress: number;
  isBoss: boolean;
  isMastered: boolean;
  completedAt?: string;
  rawMission: Mission;
  tpCode?: string;
  tpTitle?: string;
}

export interface MissionJourneyProps {
  missions: Mission[];
  progressList: StudentProgress[];
  almeRecommendation?: AlmeRecommendation | null;
  studentName?: string;
  className?: string;
  studentProfile?: StudentProfileData | null;
  onOpenMission: (mission: Mission) => void;
  onOpenLab?: () => void;
}

import React from 'react';
import { Star, Flame, Sparkles, Trophy, Award, Compass, ShieldCheck } from 'lucide-react';

interface MissionHeaderProps {
  studentName?: string;
  className?: string;
  xp: number;
  level: number;
  streakDays: number;
  completedCount: number;
  totalMissions: number;
}

export const MissionHeader: React.FC<MissionHeaderProps> = ({
  studentName = 'Murid',
  className = 'XII-1',
  xp,
  level,
  streakDays,
  completedCount,
  totalMissions,
}) => {
  const percentage = Math.round((completedCount / (totalMissions || 7)) * 100);

  return (
    <div className="relative rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 border border-slate-800 text-white p-5 sm:p-7 shadow-xl overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-0 w-80 h-80 bg-blue-600/15 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20" />
      <div className="absolute bottom-0 left-1/4 w-60 h-60 bg-pink-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        {/* Left: Title & Subtitle */}
        <div className="space-y-2 max-w-xl">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-xs font-mono font-bold tracking-wider uppercase">
              <Compass className="w-3.5 h-3.5 text-blue-400" />
              MISSION CENTER
            </span>
            <span className="text-xs text-slate-400 font-medium">
              Kelas {className} • {studentName}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-extrabold tracking-tight text-white flex items-center gap-3">
            <span>Perjalanan Belajarmu</span>
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Selesaikan modul eksplorasi STEM, praktikum sensor, dan tantangan data sains untuk naik ke level berikutnya.
          </p>
        </div>

        {/* Right: Gamified Stats Dashboard */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 bg-white/5 backdrop-blur-md p-3.5 sm:p-4 rounded-2xl border border-white/10 shrink-0">
          {/* XP Stat */}
          <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-slate-900/60 border border-amber-500/20">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 flex items-center justify-center shrink-0">
              <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
            </div>
            <div>
              <div className="text-[10px] text-amber-300/80 font-bold uppercase tracking-wider font-mono">
                PENGALAMAN
              </div>
              <div className="text-base sm:text-lg font-mono font-black text-amber-300">
                {xp.toLocaleString()} XP
              </div>
            </div>
          </div>

          {/* Level Stat */}
          <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-slate-900/60 border border-blue-500/20">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/40 text-blue-300 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <div className="text-[10px] text-blue-300/80 font-bold uppercase tracking-wider font-mono">
                TINGKAT
              </div>
              <div className="text-base sm:text-lg font-mono font-black text-blue-300">
                LEVEL {level}
              </div>
            </div>
          </div>

          {/* Streak Stat */}
          <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-slate-900/60 border border-rose-500/20">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-400/40 text-rose-400 flex items-center justify-center shrink-0">
              <Flame className="w-5 h-5 fill-rose-500 text-rose-500 animate-pulse" />
            </div>
            <div>
              <div className="text-[10px] text-rose-300/80 font-bold uppercase tracking-wider font-mono">
                KONSISTENSI
              </div>
              <div className="text-base sm:text-lg font-mono font-black text-rose-400">
                {streakDays} DAYS
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Global Progress Bar */}
      <div className="mt-5 pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-medium">Progress Keseluruhan:</span>
          <span className="font-mono font-bold text-emerald-400">
            {completedCount}/{totalMissions} Misi Selesai ({percentage}%)
          </span>
        </div>

        <div className="flex-1 max-w-md h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-white/10">
          <div
            className="h-full bg-gradient-to-r from-blue-500 via-indigo-400 to-emerald-400 rounded-full transition-all duration-700 shadow-sm"
            style={{ width: `${Math.max(5, percentage)}%` }}
          />
        </div>
      </div>
    </div>
  );
};

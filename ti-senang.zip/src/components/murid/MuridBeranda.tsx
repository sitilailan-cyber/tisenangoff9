import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Users,
  Eye,
  Heart,
  Calendar,
  FlaskConical,
  Zap,
  X,
  Search,
  Upload,
  Camera,
  ExternalLink,
  MessageSquare,
} from 'lucide-react';
import { PortfolioItem } from '../../types';
import { storage } from '../../services/storage';
import { STUDENT_DRIVE_FOLDER_URL } from '../../services/firebaseRealtime';
import { getOptimizedImageUrl } from '../../utils/googleDrive';
import { UploadPortfolioModal } from './UploadPortfolioModal';

import studentCalorimeterPhoto from '../../assets/images/student_physics_calorimeter_1789115270932.jpg';
import studentRegressionPhoto from '../../assets/images/student_data_regression_1789115288218.jpg';
import studentChemPhoto from '../../assets/images/student_chem_experiment_1789115301650.jpg';
import studentBioPhoto from '../../assets/images/student_bio_project_1789115315113.jpg';

interface MuridBerandaProps {
  className: string;
  classPortfolios: PortfolioItem[];
  onOpenDetail?: (item: PortfolioItem) => void;
  studentId?: string;
  studentName?: string;
  classId?: string;
  onRefreshPortfolios?: () => void;
}

export const MuridBeranda: React.FC<MuridBerandaProps> = ({
  className,
  classPortfolios,
  onOpenDetail,
  studentId = 'std-current',
  studentName = 'Murid MIPA',
  classId = 'cls-xii-1',
  onRefreshPortfolios,
}) => {
  const [likes, setLikes] = useState<Record<string, number>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [activeModalItem, setActiveModalItem] = useState<PortfolioItem | null>(null);
  const [showUploadModal, setShowUploadModal] = useState<boolean>(false);
  const [newCommentText, setNewCommentText] = useState<string>('');

  // Sinkronisasi Real-time saat ada update portofolio dari Firebase
  useEffect(() => {
    const handleUpdate = () => {
      if (onRefreshPortfolios) onRefreshPortfolios();
    };
    window.addEventListener('tisenang_portfolios_updated', handleUpdate);
    return () => window.removeEventListener('tisenang_portfolios_updated', handleUpdate);
  }, [onRefreshPortfolios]);

  const handleLike = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    storage.likePortfolio(id, studentId);
    setLikes((prev) => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
    if (onRefreshPortfolios) onRefreshPortfolios();
  };

  const handleSendComment = (portfolioId: string) => {
    if (!newCommentText.trim()) return;
    storage.commentPortfolio(portfolioId, {
      authorName: studentName || 'Murid MIPA',
      text: newCommentText.trim(),
    });
    setNewCommentText('');
    if (onRefreshPortfolios) onRefreshPortfolios();
    // Update active modal view with fresh comments
    const updated = storage.getAllPortfolios().find((p) => p.id === portfolioId);
    if (updated) setActiveModalItem(updated);
  };

  const handleOpenItem = (item: PortfolioItem) => {
    if (onOpenDetail) {
      onOpenDetail(item);
    } else {
      setActiveModalItem(item);
    }
  };

  // Helper to obtain authentic documentation photo from Google Drive (https://drive.google.com/drive/folders/1Xc-5Y2HWvLQie3zuQZmgh9GAtX62D34h?usp=sharing)
  const getPortfolioImage = (item: PortfolioItem): string => {
    const hint = `${item.subjectName || ''} ${item.category || ''} ${item.title || ''}`;
    if (
      item.documentation &&
      typeof item.documentation === 'string' &&
      item.documentation.trim() !== '' &&
      !item.documentation.includes('misi_') &&
      !item.documentation.includes('logo')
    ) {
      if (
        item.documentation.startsWith('data:image') ||
        item.documentation.startsWith('http') ||
        item.documentation.startsWith('/') ||
        item.documentation.startsWith('blob:')
      ) {
        return getOptimizedImageUrl(item.documentation, hint);
      }
    }

    // Ambil foto dokumentasi dari Google Drive folder:
    return getOptimizedImageUrl(item.driveLink || STUDENT_DRIVE_FOLDER_URL, hint);
  };

  // Deteksi tautan drive umum / database (bukan link file laporan spesifik murid)
  const isGenericDriveFolder = (url?: string): boolean => {
    if (!url) return true;
    const clean = url.trim().toLowerCase();
    return (
      clean === STUDENT_DRIVE_FOLDER_URL.toLowerCase() ||
      clean.includes('/drive/folders/') ||
      clean.includes('/folders/1xc-5y2') ||
      clean.includes('/folders/1hfwyt') ||
      clean.includes('folders') ||
      (clean.includes('drive.google.com/drive/u/') && clean.includes('/folders'))
    );
  };

  // Helper to get clean report text without [Tujuan: ...] prefix
  const getCleanReportText = (text?: string): string => {
    if (!text) return '';
    return text.replace(/^\[Tujuan:\s*[^\]]+\]\s*/, '');
  };

  const categories = [
    'Semua',
    'Matematika',
    'Fisika',
    'Kimia',
    'Biologi',
    'Matematika TL',
    'Integrasi Mapel',
  ];

  const filteredPortfolios = classPortfolios.filter((item) => {
    const matchesCategory = (() => {
      if (selectedCategory === 'Semua') return true;

      const catLower = selectedCategory.toLowerCase();
      const subject = (item.subjectName || '').toLowerCase();
      const title = (item.title || '').toLowerCase();
      const category = (item.category || '').toLowerCase();

      if (selectedCategory === 'Matematika TL') {
        return (
          subject.includes('tl') ||
          subject.includes('tingkat lanjut') ||
          title.includes('matematika tl') ||
          title.includes('tingkat lanjut')
        );
      }

      if (selectedCategory === 'Matematika') {
        return (
          (subject.includes('matematika') ||
            title.includes('matematika') ||
            title.includes('regresi') ||
            title.includes('bivariat') ||
            subject.includes('mat')) &&
          !subject.includes('tl') &&
          !title.includes('matematika tl') &&
          !title.includes('tingkat lanjut')
        );
      }

      if (selectedCategory === 'Fisika') {
        return (
          subject.includes('fisika') ||
          title.includes('fisika') ||
          title.includes('kalor') ||
          title.includes('suhu') ||
          title.includes('radiasi')
        );
      }

      if (selectedCategory === 'Kimia') {
        return (
          subject.includes('kimia') ||
          title.includes('kimia') ||
          title.includes('reaksi') ||
          title.includes('termokimia') ||
          title.includes('larutan')
        );
      }

      if (selectedCategory === 'Biologi') {
        return (
          subject.includes('biologi') ||
          title.includes('biologi') ||
          title.includes('daun') ||
          title.includes('transpirasi') ||
          title.includes('stomata') ||
          title.includes('tanaman')
        );
      }

      if (selectedCategory === 'Integrasi Mapel') {
        return (
          subject.includes('integrasi') ||
          subject.includes('mipa') ||
          title.includes('integrasi') ||
          category.includes('proyek') ||
          category.includes('integrasi')
        );
      }

      return (
        subject.includes(catLower) ||
        title.includes(catLower) ||
        category.includes(catLower)
      );
    })();

    const matchesSearch =
      (item.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.studentName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.reflectionSummary || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const firstName = (studentName || 'Murid').split(' ')[0];

  return (
    <div className="space-y-5 max-w-5xl mx-auto pb-8 animate-page-fade-up">
      {/* =========================================================================
          1. WELCOME DASHBOARD HEADER (Futuristic Welcome Student Dashboard)
          ========================================================================= */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#060c24] via-[#0d1c4f] to-[#201048] p-5 sm:p-7 text-white shadow-[0_18px_50px_rgba(2,6,23,0.38),0_0_35px_rgba(59,130,246,0.12)] border border-indigo-500/30">
        {/* Holographic light border accent on top edge */}
        <div className="absolute top-0 left-0 right-0 h-[1.5px] bg-gradient-to-r from-transparent via-cyan-400/60 to-transparent pointer-events-none" />

        {/* Delicate digital grid overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(#38bdf814_1px,transparent_1px)] [background-size:22px_22px] pointer-events-none opacity-60" />

        {/* Dynamic ambient glowing orbs */}
        <div className="absolute -top-20 -left-16 w-72 h-72 rounded-full bg-cyan-500/16 blur-3xl pointer-events-none animate-pulse-subtle" />
        <div className="absolute -bottom-20 -right-16 w-80 h-80 rounded-full bg-fuchsia-600/16 blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 left-1/3 w-56 h-56 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />

        {/* Abstract flowing waves - Futuristic delicate vector curves */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30 animate-wave-float">
          <svg viewBox="0 0 1200 160" preserveAspectRatio="none" className="w-full h-full">
            <defs>
              <linearGradient id="berandaWaveGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.05" />
                <stop offset="40%" stopColor="#38bdf8" stopOpacity="0.3" />
                <stop offset="70%" stopColor="#818cf8" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#c084fc" stopOpacity="0.05" />
              </linearGradient>
              <linearGradient id="berandaWaveGrad2" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#818cf8" stopOpacity="0.05" />
                <stop offset="50%" stopColor="#38bdf8" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#f472b6" stopOpacity="0.05" />
              </linearGradient>
            </defs>
            <path
              d="M 0 90 C 250 145, 550 35, 850 95 C 1020 130, 1120 60, 1200 85"
              fill="none"
              stroke="url(#berandaWaveGrad1)"
              strokeWidth="1.6"
            />
            <path
              d="M 0 115 C 300 55, 600 155, 900 80 C 1040 45, 1140 120, 1200 100"
              fill="none"
              stroke="url(#berandaWaveGrad2)"
              strokeWidth="1.2"
              strokeDasharray="4 6"
            />
          </svg>
        </div>

        {/* Content Container (Compact, Tidy, and Balanced) */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-5 relative z-10">
          <div className="space-y-1 max-w-xl">
            {/* Live Indicator & Class Badge */}
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-slate-900/75 backdrop-blur-md border border-cyan-400/30 text-[10px] sm:text-[11px] font-mono font-bold text-cyan-300 shadow-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <Users className="w-3 h-3 text-cyan-300" />
              <span>Kelas {(className || 'XII-1').replace(/\s*MIPA/gi, '').trim()}</span>
            </div>

            {/* Welcoming Title */}
            <h1 className="text-xl sm:text-2xl font-display font-black tracking-tight text-white drop-shadow-sm leading-tight">
              Hai, <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-blue-200">{firstName}</span> 👋
            </h1>

            {/* Short Engaging Subtitle */}
            <p className="text-xs text-slate-300 leading-normal font-normal">
              Portofolio karya & hasil eksperimen teman sekelas.
            </p>
          </div>

          {/* Right: Action Button */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0 pt-1 sm:pt-0">
            {/* Action Button: Upload Portofolio */}
            <button
              type="button"
              id="btn-upload-portofolio-beranda"
              onClick={() => setShowUploadModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 font-display font-extrabold text-xs sm:text-sm shadow-[0_0_18px_rgba(6,182,212,0.4)] transition-all active:scale-95 cursor-pointer border border-cyan-200/80 shrink-0 min-h-[40px]"
            >
              <Upload className="w-4 h-4 text-slate-950" />
              <span>+ Portofolio</span>
            </button>
          </div>
        </div>
      </div>

      {/* =========================================================================
          2. FILTER & SEARCH CONTROLS (Compact & Refined Navigation)
          ========================================================================= */}
      <div className="bg-[#0c1630]/85 backdrop-blur-md rounded-2xl p-2.5 sm:p-3 border border-cyan-500/25 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Category Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-[0_0_14px_rgba(6,182,212,0.4)] border border-cyan-300/40'
                    : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/60'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Search Box with Clear Icon */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari karya, murid, atau topik..."
            className="w-full pl-9 pr-8 py-2 rounded-xl border border-slate-700/80 bg-slate-900/90 text-xs text-white placeholder-slate-400 focus:ring-2 focus:ring-cyan-500/30 focus:border-cyan-400 focus:outline-none transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5 rounded-full hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* =========================================================================
          3. PORTFOLIOS FEED GRID (Modern Scientific Showcase Cards)
          ========================================================================= */}
      {filteredPortfolios.length === 0 ? (
        <div className="bg-[#101b38]/90 backdrop-blur-md rounded-3xl p-10 sm:p-12 border border-cyan-500/20 text-center space-y-3 shadow-lg">
          <div className="w-14 h-14 rounded-2xl bg-cyan-950/70 border border-cyan-500/30 text-cyan-400 mx-auto flex items-center justify-center shadow-inner">
            <Users className="w-7 h-7" />
          </div>
          <h3 className="font-display font-bold text-white text-base">
            Tidak Ada Karya yang Ditemukan
          </h3>
          <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
            {searchQuery
              ? `Tidak ada hasil pencarian untuk "${searchQuery}". Coba kata kunci atau nama murid lain.`
              : `Belum ada portofolio yang dibagikan untuk kategori ${selectedCategory}.`}
          </p>
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-bold transition-all cursor-pointer inline-flex items-center gap-1.5 border border-cyan-500/30"
            >
              <X className="w-3.5 h-3.5" />
              <span>Reset Pencarian</span>
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
          {filteredPortfolios.map((item) => {
            const likeCount = (likes[item.id] || 0) + (item.id === 'pf-01' ? 4 : 2);
            return (
              <div
                key={item.id}
                id={`classmate-portfolio-${item.id}`}
                className="bg-gradient-to-b from-[#14234b]/95 via-[#101d3e]/95 to-[#0d1733]/95 backdrop-blur-md rounded-2xl sm:rounded-3xl p-4 sm:p-4.5 border border-cyan-500/25 hover:border-cyan-400/60 shadow-[0_8px_24px_rgba(0,0,0,0.4)] hover:shadow-[0_12px_32px_rgba(6,182,212,0.22)] hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between group relative overflow-hidden"
              >
                {/* Micro top gradient accent line on hover */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                <div className="space-y-3">
                  {/* Bagian Atas: Foto Dokumentasi + Badges */}
                  <div className="relative aspect-[16/10] w-full rounded-xl sm:rounded-2xl overflow-hidden bg-slate-950 border border-slate-700/60 shadow-inner">
                    <img
                      src={getPortfolioImage(item)}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                      referrerPolicy="no-referrer"
                    />
                    {/* Soft gradient vignette for contrast */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/65 via-transparent to-slate-950/20 pointer-events-none" />

                    {/* Overlay Badges */}
                    <div className="absolute top-2.5 left-2.5 flex flex-wrap items-center gap-1.5 z-10">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-slate-950/85 backdrop-blur-md text-cyan-300 border border-cyan-400/40 shadow-sm">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse-subtle" />
                        {item.category || 'Eksperimen'}
                      </span>
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-950/85 backdrop-blur-md text-emerald-300 border border-emerald-400/40 shadow-sm">
                        <Camera className="w-3 h-3" />
                        Dokumentasi Murid
                      </span>
                    </div>
                  </div>

                  {/* Bagian Isi: Penulis, Mata Pelajaran, Judul */}
                  <div className="space-y-1.5 px-0.5">
                    {/* Penulis & Mata Pelajaran */}
                    <div className="text-[11px] font-bold uppercase tracking-wider flex items-center gap-1.5">
                      <span className="text-cyan-300 font-extrabold capitalize">
                        {(item.studentName || 'Murid').replace(/\s*MIPA/gi, '').trim()}
                      </span>
                      <span className="text-slate-600">•</span>
                      <span className="truncate text-slate-300 font-medium">
                        {item.subjectName || 'Fisika Eksperimental'}
                      </span>
                    </div>

                    {/* Judul Portofolio */}
                    <h2 className="font-display font-bold text-white text-base leading-snug group-hover:text-cyan-300 transition-colors line-clamp-2">
                      {item.title}
                    </h2>
                  </div>
                </div>

                {/* Bagian Bawah: Tombol Like, XP Badge, Tombol "Buka" */}
                <div className="mt-3.5 pt-3 border-t border-slate-700/60 flex items-center justify-between gap-2">
                  {/* Left: Like & XP (Ukuran diperkecil rapi) */}
                  <div className="flex items-center gap-1.5">
                    <button
                      id={`btn-like-portfolio-${item.id}`}
                      onClick={(e) => handleLike(item.id, e)}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-900/80 hover:bg-rose-950/50 text-slate-400 hover:text-rose-400 border border-slate-700/70 hover:border-rose-500/50 text-[10px] sm:text-[11px] font-semibold transition-all active:scale-90 cursor-pointer shadow-xs"
                      title="Sukai karya ini"
                    >
                      <Heart className="w-3 h-3 fill-rose-500/20 text-rose-400 transition-transform active:scale-125" />
                      <span className="font-mono">{likeCount}</span>
                    </button>

                    <div className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-950/40 border border-amber-500/30 text-amber-300 text-[10px] sm:text-[11px] font-bold font-mono shadow-xs">
                      <Zap className="w-3 h-3 text-amber-400 fill-amber-400" />
                      <span>+{item.xpEarned} XP</span>
                    </div>
                  </div>

                  {/* Right: Tombol "Buka" Lebih Menonjol */}
                  <button
                    id={`btn-view-report-${item.id}`}
                    onClick={() => handleOpenItem(item)}
                    className="inline-flex items-center gap-1.5 px-4 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-cyan-400 via-sky-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-slate-950 text-xs sm:text-sm font-display font-extrabold shadow-[0_0_16px_rgba(6,182,212,0.45)] hover:shadow-[0_0_24px_rgba(6,182,212,0.7)] hover:scale-[1.03] transition-all active:scale-95 cursor-pointer border border-cyan-100/90 group/btn shrink-0"
                  >
                    <span>Buka</span>
                    <Eye className="w-3.5 h-3.5 transition-transform group-hover/btn:scale-110" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* =========================================================================
          4. DETAIL MODAL FOR CLASSMATE PORTFOLIO
          ========================================================================= */}
      {activeModalItem && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0f172a] rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-[0_20px_60px_rgba(0,0,0,0.8)] space-y-4 my-8 animate-in fade-in zoom-in-95 border border-cyan-500/30 text-white">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider">
                  Karya Murid: {(activeModalItem.studentName || 'Murid').replace(/\s*MIPA/gi, '').trim()} • Kelas {(activeModalItem.className || className || 'XII-1').replace(/\s*MIPA/gi, '').trim()}
                </span>
                <h3 className="font-display font-extrabold text-white text-base mt-0.5">
                  {activeModalItem.title}
                </h3>
              </div>
              <button
                onClick={() => setActiveModalItem(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Foto Dokumentasi pada Modal Detail */}
            <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-700/80">
              <img
                src={getPortfolioImage(activeModalItem)}
                alt={activeModalItem.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                <span className="px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-slate-900/85 backdrop-blur-md text-cyan-300 border border-cyan-400/40">
                  {activeModalItem.category}
                </span>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-950/85 backdrop-blur-md text-emerald-300 border border-emerald-400/40 shadow-sm flex items-center gap-1">
                  <Camera className="w-3 h-3" />
                  Foto Dokumentasi Murid
                </span>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-200 leading-relaxed">
              <div className="flex flex-wrap items-center justify-between gap-2 bg-[#0a1226] p-2.5 rounded-xl border border-cyan-500/20">
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400">Karya Murid:</span>
                  <span className="font-bold text-cyan-300 capitalize">{(activeModalItem.studentName || 'Murid').replace(/\s*MIPA/gi, '').trim()}</span>
                  <span className="text-slate-600">•</span>
                  <span className="text-slate-300 font-medium">{activeModalItem.subjectName}</span>
                </div>
                <span className="font-bold text-amber-400 font-mono">+{activeModalItem.xpEarned} XP</span>
              </div>

              {activeModalItem.reflectionSummary && (
                <div className="bg-[#0c1833] p-3.5 rounded-2xl border border-blue-500/25 space-y-1">
                  <h4 className="font-bold text-cyan-300 text-xs">Catatan Laporan & Refleksi Saintifik:</h4>
                  <p className="italic text-slate-300 leading-relaxed">
                    "{getCleanReportText(activeModalItem.reflectionSummary)}"
                  </p>
                </div>
              )}

              {/* Komentar Teman & Guru (Peer Feedback) */}
              <div className="bg-[#0a1226] p-3.5 rounded-2xl border border-slate-800 space-y-2.5">
                <h4 className="font-bold text-cyan-300 text-xs flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Umpan Balik & Komentar Teman / Guru ({activeModalItem.comments?.length || 0})</span>
                </h4>
                
                {/* Daftar Komentar */}
                {activeModalItem.comments && activeModalItem.comments.length > 0 ? (
                  <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                    {activeModalItem.comments.map((c, i) => (
                      <div key={i} className="p-2 rounded-xl bg-[#131f3d] border border-slate-700/60 text-xs space-y-0.5 shadow-2xs">
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="font-bold text-cyan-300">{c.authorName}</span>
                          <span className="text-slate-400 font-mono">
                            {new Date(c.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        <p className="text-slate-200">{c.text}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-400 italic">Belum ada komentar. Jadilah yang pertama memberi apresiasi!</p>
                )}

                {/* Input Komentar Baru */}
                <div className="flex items-center gap-2 pt-1 border-t border-slate-800">
                  <input
                    type="text"
                    value={newCommentText}
                    onChange={(e) => setNewCommentText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSendComment(activeModalItem.id);
                    }}
                    placeholder="Beri apresiasi atau komentar konstruktif..."
                    className="flex-1 h-8 px-2.5 rounded-xl border border-slate-700 text-xs bg-slate-900 text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-cyan-400"
                  />
                  <button
                    type="button"
                    onClick={() => handleSendComment(activeModalItem.id)}
                    className="h-8 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
                  >
                    Kirim
                  </button>
                </div>
              </div>

              {activeModalItem.experimentData && (
                <div className="bg-[#0a1226] p-3.5 rounded-2xl border border-slate-800 space-y-2">
                  <h4 className="font-bold text-cyan-300 text-xs flex items-center gap-1.5">
                    <FlaskConical className="w-4 h-4 text-cyan-400" />
                    Data Eksperimen Terukur
                  </h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-[11px] text-left">
                      <thead className="bg-slate-800 text-cyan-300 font-bold">
                        <tr>
                          <th className="p-1.5">No</th>
                          <th className="p-1.5">Waktu (s)</th>
                          <th className="p-1.5">Suhu (°C)</th>
                          <th className="p-1.5">ΔT (°C)</th>
                          <th className="p-1.5">Kalor Q (J)</th>
                        </tr>
                      </thead>
                      <tbody>
                        {activeModalItem.experimentData.rows.map((r, i) => (
                          <tr key={i} className="border-b border-slate-800">
                            <td className="p-1.5 font-mono text-slate-400">{i + 1}</td>
                            <td className="p-1.5 font-mono text-slate-300">{r.timeSeconds}</td>
                            <td className="p-1.5 font-mono text-slate-300">{r.tempCelsius}°C</td>
                            <td className="p-1.5 font-mono text-slate-300">{r.deltaT}°C</td>
                            <td className="p-1.5 font-mono text-cyan-300">{r.heatJoules} J</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setActiveModalItem(null)}
                className="min-h-[40px] px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold active:scale-95 cursor-pointer shadow-xs transition-colors border border-slate-700"
              >
                Tutup Laporan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload Portofolio Modal */}
      <UploadPortfolioModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onSuccess={() => {
          if (onRefreshPortfolios) {
            onRefreshPortfolios();
          }
        }}
        studentId={studentId}
        studentName={studentName}
        classId={classId}
        className={className}
      />
    </div>
  );
};

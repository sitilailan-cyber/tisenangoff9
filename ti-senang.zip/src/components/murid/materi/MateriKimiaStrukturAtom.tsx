import React, { useState } from 'react';
import {
  Atom,
  Flame,
  Droplets,
  Layers,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  CheckCircle2,
  ChevronRight,
  Zap,
  Activity,
  Wind,
  ShieldCheck,
  Compass,
  Gauge,
  ThermometerSun,
  Waves,
  Eye,
  Beaker,
  Link as LinkIcon,
} from 'lucide-react';

export const MateriKimiaStrukturAtom: React.FC = () => {
  // State Cover: materi baru muncul setelah tombol "⚛️ MULAI BELAJAR" diklik
  const [hasStartedReading, setHasStartedReading] = useState(false);

  // Navigasi Section: 1 sampai 8
  type SectionId = '1' | '2' | '3' | '4' | '5' | '6' | '7' | '8';
  const [activeSection, setActiveSection] = useState<SectionId>('1');

  // State interaktif Section 1: Pemilihan molekul VSEPR
  const [selectedMolecule, setSelectedMolecule] = useState<
    'CO2' | 'BF3' | 'CH4' | 'NH3' | 'H2O'
  >('CO2');

  // State interaktif Section 2: Pemilihan molekul Polaritas
  const [selectedPolarityMolecule, setSelectedPolarityMolecule] = useState<'CO2' | 'H2O'>('CO2');

  // State interaktif Section 3: Pemilihan Jenis Gaya Antarmolekul
  const [selectedIntermolecularForce, setSelectedIntermolecularForce] = useState<
    'london' | 'dipol' | 'hidrogen'
  >('london');

  // State interaktif Section 4: Simulasi Pengaruh Kekuatan Gaya
  const [forceStrengthLevel, setForceStrengthLevel] = useState<'lemah' | 'sedang' | 'kuat'>('sedang');

  // State interaktif Section 6: Rantai Konsep Aktif
  const [activeChainStep, setActiveChainStep] = useState<number>(0);

  const navItems: { id: SectionId; number: string; title: string; shortTitle: string }[] = [
    { id: '1', number: '1', title: 'Geometri Molekul (Teori VSEPR)', shortTitle: '1. Geometri' },
    { id: '2', number: '2', title: 'Polaritas Molekul', shortTitle: '2. Polaritas' },
    { id: '3', number: '3', title: 'Gaya Antarmolekul', shortTitle: '3. Gaya Antarmolekul' },
    { id: '4', number: '4', title: 'Pengaruh terhadap Sifat Fisik Zat', shortTitle: '4. Sifat Fisik' },
    { id: '5', number: '5', title: 'Contoh dalam Kehidupan Sehari-hari', shortTitle: '5. Kehidupan Nyata' },
    { id: '6', number: '6', title: 'Rantai Konsep', shortTitle: '6. Rantai Konsep' },
    { id: '7', number: '7', title: 'Hal Penting yang Harus Dipahami', shortTitle: '7. Hal Penting' },
    { id: '8', number: '8', title: 'Kesimpulan Pembelajaran', shortTitle: '8. Kesimpulan' },
  ];

  const handleNext = () => {
    const currentIndex = navItems.findIndex((item) => item.id === activeSection);
    if (currentIndex < navItems.length - 1) {
      setActiveSection(navItems[currentIndex + 1].id);
    }
  };

  const handlePrev = () => {
    const currentIndex = navItems.findIndex((item) => item.id === activeSection);
    if (currentIndex > 0) {
      setActiveSection(navItems[currentIndex - 1].id);
    }
  };

  // Data Molekul VSEPR
  const vseprData = {
    CO2: {
      formula: 'CO₂',
      name: 'Linear',
      angle: '180°',
      pei: 2,
      peb: 0,
      domain: 2,
      hybrid: 'sp',
      desc: 'Dua ikatan rangkap dua (C=O) tersusun berlawanan arah secara simetris sejauh 180° untuk meminimalkan tolakan pasangan elektron.',
      color: 'from-blue-500 to-cyan-400',
    },
    BF3: {
      formula: 'BF₃',
      name: 'Trigonal Planar',
      angle: '120°',
      pei: 3,
      peb: 0,
      domain: 3,
      hybrid: 'sp²',
      desc: 'Tiga atom Fluorin terikat pada Boron dalam satu bidang datar segitiga simetris dengan sudut ikatan masing-masing 120°.',
      color: 'from-blue-600 to-indigo-400',
    },
    CH4: {
      formula: 'CH₄',
      name: 'Tetrahedral',
      angle: '109,5°',
      pei: 4,
      peb: 0,
      domain: 4,
      hybrid: 'sp³',
      desc: 'Empat ikatan C-H menyebar ke empat sudut bidang ruang tetrahedral secara tiga dimensi dengan sudut optimal 109,5°.',
      color: 'from-rose-500 to-red-400',
    },
    NH3: {
      formula: 'NH₃',
      name: 'Trigonal Piramida',
      angle: '107°',
      pei: 3,
      peb: 1,
      domain: 4,
      hybrid: 'sp³',
      desc: 'Memiliki 1 Pasangan Elektron Bebas (PEB) pada atom Nitrogen yang menekan 3 ikatan N-H ke bawah sehingga sudut menyempit dari 109,5° menjadi ~107°.',
      color: 'from-amber-500 to-rose-400',
    },
    H2O: {
      formula: 'H₂O',
      name: 'Bengkok / V',
      angle: '104,5°',
      pei: 2,
      peb: 2,
      domain: 4,
      hybrid: 'sp³',
      desc: 'Memiliki 2 Pasangan Elektron Bebas (PEB) pada atom Oksigen. Tolakan kuat PEB-PEB menekan kedua ikatan O-H ke bawah membentuk sudut ~104,5° (bentuk V).',
      color: 'from-blue-500 to-red-500',
    },
  };

  // Data Rantai Konsep
  const conceptChain = [
    {
      title: 'Struktur Elektron',
      subtitle: 'Konfigurasi & Valensi',
      desc: 'Konfigurasi elektron valensi menentukan jumlah pasangan elektron ikatan (PEI) dan pasangan elektron bebas (PEB) di sekitar atom pusat.',
      highlight: 'PEI & PEB pada kulit terluar',
      badge: 'Langkah 1',
    },
    {
      title: 'Geometri Molekul',
      subtitle: 'Bentuk Ruang 3D (VSEPR)',
      desc: 'Tolakan antar-pasangan elektron menghasilkan bentuk ruang 3 dimensi (linear, tetrahedral, piramida, bengkok) yang meminimalkan energi tolakan.',
      highlight: 'Penataan spasial simetris / asimetris',
      badge: 'Langkah 2',
    },
    {
      title: 'Polaritas',
      subtitle: 'Momen Dipol Total (μ)',
      desc: 'Bentuk molekul menentukan apakah momen dipol ikatan saling meniadakan (nonpolar) atau menghasilkan momen dipol netto permanen (polar).',
      highlight: 'Distribusi muatan parsial δ+ dan δ-',
      badge: 'Langkah 3',
    },
    {
      title: 'Gaya Antarmolekul',
      subtitle: 'Interaksi Antar Partikel',
      desc: 'Molekul polar berinteraksi lewat gaya dipol-dipol atau ikatan hidrogen, sedangkan molekul nonpolar hanya memiliki gaya London/dispersi.',
      highlight: 'Gaya London < Dipol-Dipol < Ikatan Hidrogen',
      badge: 'Langkah 4',
    },
    {
      title: 'Sifat Fisik Zat',
      subtitle: 'Makroskopis Nyata',
      desc: 'Semakin kuat gaya antarmolekul yang terbentuk, semakin tinggi titik didih, titik leleh, viskositas, serta semakin rendah laju penguapan zat.',
      highlight: 'Titik didih, leleh, viskositas, volatilitas',
      badge: 'Langkah 5',
    },
  ];

  return (
    <div className="space-y-4 sm:space-y-6 w-full min-w-0 font-sans">
      {/* 1. HALAMAN COVER (HANYA COVER YANG TERLIHAT SEBELUM MULAI BELAJAR) */}
      {!hasStartedReading ? (
        <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-slate-950 via-blue-950 to-red-950 p-6 sm:p-12 text-white shadow-2xl border-2 border-red-500/30 animate-in fade-in zoom-in-95">
          {/* Ambient Glow Efek Merah-Biru */}
          <div className="absolute -top-20 -right-20 w-80 h-80 bg-blue-600/25 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-red-600/25 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 max-w-3xl space-y-6">
            {/* Tag Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-red-600/30 via-purple-600/30 to-blue-600/30 text-blue-200 border border-blue-400/40 font-bold text-xs uppercase tracking-wider shadow-md backdrop-blur-md">
              <Atom className="w-4 h-4 text-blue-400 animate-spin" style={{ animationDuration: '8s' }} />
              <span>Kimia SMA • Ikatan Kimia & Bentuk Molekul</span>
            </div>

            {/* Judul Besar & Subjudul */}
            <div className="space-y-2.5">
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight uppercase drop-shadow-md">
                STRUKTUR ATOM &amp; IKATAN KIMIA
              </h1>
              <p className="text-base sm:text-xl lg:text-2xl font-semibold text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-indigo-200 to-rose-300 drop-shadow-xs italic">
                Geometri Molekul, Gaya Antarmolekul, dan Pengaruhnya terhadap Sifat Fisik Zat
              </p>
            </div>

            {/* Visual Ilustrasi 3D Molekul & Gaya Antarmolekul Merah-Biru */}
            <div className="p-5 sm:p-6 rounded-2xl bg-slate-900/80 border border-slate-700/80 backdrop-blur-sm shadow-xl space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Visual Kartu 1: Atom & Ikatan Kimia */}
                <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-blue-900/40 to-slate-900/60 border border-blue-500/30">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-400/30 flex items-center justify-center shrink-0">
                    <Atom className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xs font-bold text-blue-200">Teori VSEPR</h2>
                    <p className="text-[11px] text-slate-300">Penataan ruang elektron kulit valensi</p>
                  </div>
                </div>

                {/* Visual Kartu 2: Polaritas Momen Dipol */}
                <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-indigo-900/40 to-slate-900/60 border border-indigo-500/30">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-400/30 flex items-center justify-center shrink-0">
                    <Compass className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xs font-bold text-indigo-200">Momen Dipol (μ)</h2>
                    <p className="text-[11px] text-slate-300">Distribusi muatan parsial molekul</p>
                  </div>
                </div>

                {/* Visual Kartu 3: Gaya Antarmolekul & Sifat Fisik */}
                <div className="flex items-center gap-3 p-3 rounded-xl bg-gradient-to-r from-red-900/40 to-slate-900/60 border border-red-500/30">
                  <div className="w-10 h-10 rounded-xl bg-red-500/20 text-rose-400 border border-red-400/30 flex items-center justify-center shrink-0">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-xs font-bold text-rose-200">Gaya Antarmolekul</h2>
                    <p className="text-[11px] text-slate-300">Penentu titik didih &amp; sifat zat</p>
                  </div>
                </div>
              </div>

              {/* Diagram Vektor Mini Visual Molekul */}
              <div className="flex flex-wrap items-center justify-center gap-4 pt-2 border-t border-slate-800 text-xs text-slate-300">
                <span className="flex items-center gap-1.5 text-blue-300 font-medium">
                  <span className="w-2.5 h-2.5 rounded-full bg-blue-400 inline-block"></span> Muatan Parsial Positif (δ⁺)
                </span>
                <span className="flex items-center gap-1.5 text-rose-300 font-medium">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block"></span> Muatan Parsial Negatif (δ⁻)
                </span>
                <span className="flex items-center gap-1.5 text-cyan-300 font-medium">
                  <span className="w-4 border-b-2 border-dashed border-cyan-400 inline-block"></span> Ikatan Hidrogen / Gaya Tarik
                </span>
              </div>
            </div>

            {/* Tombol Utama: MULAI BELAJAR */}
            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                type="button"
                id="btn-mulai-belajar-kimia"
                onClick={() => setHasStartedReading(true)}
                className="px-8 py-4 rounded-2xl bg-gradient-to-r from-red-600 via-purple-600 to-blue-600 hover:from-red-500 hover:via-purple-500 hover:to-blue-500 text-white font-extrabold text-base sm:text-lg shadow-xl shadow-red-950/50 hover:shadow-blue-900/50 flex items-center justify-center gap-3 cursor-pointer transition-all transform hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>⚛️ MULAI BELAJAR</span>
                <ArrowRight className="w-5 h-5 animate-pulse" />
              </button>

              <span className="text-xs text-slate-400 italic text-center sm:text-left">
                Klik tombol di atas untuk membuka seluruh 8 modul materi interaktif struktur &amp; ikatan kimia.
              </span>
            </div>
          </div>
        </div>
      ) : (
        /* 2. HALAMAN MATERI (MUNCUL SETELAH TOMBOL DIKLIK DENGAN TRANSISI HALUS) */
        <div className="space-y-4 sm:space-y-6 animate-in fade-in slide-in-from-bottom-3 duration-300">
          {/* Header Bar Kontrol & Reset ke Cover */}
          <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-red-950 p-4 sm:p-5 rounded-2xl border border-red-500/30 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-red-500 flex items-center justify-center text-white shadow-md">
                <Atom className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
                    Kimia SMA
                  </span>
                  <span className="text-xs text-slate-400">Merah-Biru-Putih</span>
                </div>
                <h2 className="text-base sm:text-lg font-extrabold text-white">
                  Struktur Atom &amp; Ikatan Kimia
                </h2>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={() => setHasStartedReading(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 flex items-center gap-1.5 transition-all cursor-pointer"
                title="Tampilkan Halaman Cover"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Lihat Cover</span>
              </button>
            </div>
          </div>

          {/* Navigasi Section: 1 sampai 8 */}
          <div className="bg-slate-900/90 rounded-2xl p-2 sm:p-3 border border-slate-700/80 shadow-md">
            <div className="text-[11px] font-bold text-slate-400 px-2 py-1 mb-1.5 flex items-center justify-between">
              <span>Navigasi Materi (Pilih Bagian):</span>
              <span className="text-blue-300">
                Bagian {activeSection} dari 8
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-1.5">
              {navItems.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setActiveSection(item.id)}
                    className={`px-2.5 py-2 rounded-xl text-xs font-bold transition-all text-center flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                      isActive
                        ? 'bg-gradient-to-r from-red-600 via-purple-600 to-blue-600 text-white shadow-md shadow-blue-900/40 scale-[1.02]'
                        : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60'
                    }`}
                  >
                    <span className="text-[10px] opacity-80">{item.number}</span>
                    <span className="truncate w-full text-center text-[11px] sm:text-xs">
                      {item.shortTitle}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* ======================================================== */}
          {/* SECTION 1: GEOMETRI MOLEKUL & TEORI VSEPR */}
          {/* ======================================================== */}
          {activeSection === '1' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-4">
                <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0">
                    <Atom className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">Bagian 1</span>
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      Geometri Molekul (Teori VSEPR)
                    </h2>
                  </div>
                </div>

                <div className="space-y-3 text-xs sm:text-sm text-slate-200 leading-relaxed">
                  <p>
                    <strong className="text-white">Geometri molekul</strong> adalah susunan tiga dimensi dari atom-atom dalam suatu molekul. Bentuk ini secara akurat diprediksi melalui <strong className="text-blue-300">Teori VSEPR (Valence Shell Electron Pair Repulsion)</strong> atau Teori Tolakan Pasangan Elektron Kulit Valensi.
                  </p>
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-blue-950/70 to-slate-900/80 border border-blue-500/30 text-slate-200">
                    <h3 className="text-xs font-bold text-blue-300 mb-1 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-blue-400" />
                      Prinsip Utama Teori VSEPR:
                    </h3>
                    <p className="text-xs leading-relaxed text-slate-300">
                      Pasangan-pasangan elektron pada kulit valensi atom pusat saling tolak-menolak karena bermuatan negatif sama. Untuk meminimalkan tolakan tersebut, pasangan elektron akan menempatkan diri sejauh mungkin satu sama lain dalam ruang 3 dimensi.
                    </p>
                    <p className="text-xs mt-2 text-rose-300 font-medium">
                      ⚠️ Urutan kekuatan tolakan: <span className="font-bold underline">PEB - PEB &gt; PEB - PEI &gt; PEI - PEI</span>
                      <br />
                      (Pasangan Elektron Bebas memiliki awan elektron lebih bervolume dan menolak ikatan lain lebih kuat sehingga mempersempit sudut ikatan).
                    </p>
                  </div>
                </div>

                {/* Pemilih Contoh Molekul VSEPR Interaktif */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                      <Eye className="w-4 h-4 text-rose-400" />
                      Eksplorasi Bentuk Molekul &amp; Sudut Ikatan:
                    </h3>
                    <span className="text-[11px] text-slate-400">Klik molekul untuk melihat visualisasi</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                    {(['CO2', 'BF3', 'CH4', 'NH3', 'H2O'] as const).map((mKey) => {
                      const isSel = selectedMolecule === mKey;
                      const mData = vseprData[mKey];
                      return (
                        <button
                          key={mKey}
                          type="button"
                          onClick={() => setSelectedMolecule(mKey)}
                          className={`p-3 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                            isSel
                              ? 'bg-gradient-to-br from-blue-600 to-red-600 text-white border-blue-400 shadow-md scale-[1.02]'
                              : 'bg-slate-800/80 text-slate-300 border-slate-700 hover:border-slate-500 hover:bg-slate-800'
                          }`}
                        >
                          <span className="text-base font-black font-mono">{mData.formula}</span>
                          <span className="text-[11px] font-bold leading-tight">{mData.name}</span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-black/30 font-mono">
                            {mData.angle}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Kartu Detail Visualisasi Molekul Terpilih */}
                  {(() => {
                    const current = vseprData[selectedMolecule];
                    return (
                      <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800/90 to-blue-950/60 border-2 border-blue-500/40 shadow-xl space-y-4">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-700/80 pb-3">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-2xl font-black text-white font-mono">{current.formula}</span>
                              <span className="text-xs px-2.5 py-0.5 rounded-full bg-red-500/20 text-rose-300 border border-red-500/30 font-bold">
                                {current.name}
                              </span>
                              <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 font-bold font-mono">
                                Sudut: {current.angle}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 mt-1 leading-relaxed">{current.desc}</p>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <div className="text-center px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700">
                              <span className="text-[10px] text-slate-400 block">PEI</span>
                              <span className="text-sm font-black text-blue-400 font-mono">{current.pei}</span>
                            </div>
                            <div className="text-center px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700">
                              <span className="text-[10px] text-slate-400 block">PEB</span>
                              <span className="text-sm font-black text-rose-400 font-mono">{current.peb}</span>
                            </div>
                            <div className="text-center px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700">
                              <span className="text-[10px] text-slate-400 block">Hibridisasi</span>
                              <span className="text-sm font-black text-amber-300 font-mono">{current.hybrid}</span>
                            </div>
                          </div>
                        </div>

                        {/* Visual SVG 3D-Styled Representasi Geometri Molekul */}
                        <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 flex flex-col items-center justify-center">
                          <svg viewBox="0 0 320 180" className="w-full max-w-xs sm:max-w-sm h-40">
                            <defs>
                              <linearGradient id="gradCenter" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stopColor="#ef4444" />
                                <stop offset="100%" stopColor="#991b1b" />
                              </linearGradient>
                              <linearGradient id="gradLigand" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stopColor="#60a5fa" />
                                <stop offset="100%" stopColor="#1d4ed8" />
                              </linearGradient>
                              <linearGradient id="gradLonePair" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stopColor="#fbbf24" stopOpacity="0.8" />
                                <stop offset="100%" stopColor="#b45309" stopOpacity="0.2" />
                              </linearGradient>
                            </defs>

                            {/* Render molekul sesuai seleksi */}
                            {selectedMolecule === 'CO2' && (
                              <g>
                                {/* Ikatan Ganda Kiri & Kanan */}
                                <line x1="160" y1="86" x2="80" y2="86" stroke="#94a3b8" strokeWidth="4" />
                                <line x1="160" y1="94" x2="80" y2="94" stroke="#94a3b8" strokeWidth="4" />
                                <line x1="160" y1="86" x2="240" y2="86" stroke="#94a3b8" strokeWidth="4" />
                                <line x1="160" y1="94" x2="240" y2="94" stroke="#94a3b8" strokeWidth="4" />

                                {/* Sudut Busur */}
                                <path d="M 120 70 A 40 40 0 0 1 200 70" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 3" />
                                <text x="160" y="60" textAnchor="middle" fill="#38bdf8" fontSize="12" fontWeight="bold">180°</text>

                                {/* Atom O kiri */}
                                <circle cx="80" cy="90" r="20" fill="url(#gradLigand)" />
                                <text x="80" y="95" textAnchor="middle" fill="white" fontWeight="bold" fontSize="13">O</text>

                                {/* Atom C pusat */}
                                <circle cx="160" cy="90" r="22" fill="url(#gradCenter)" />
                                <text x="160" y="95" textAnchor="middle" fill="white" fontWeight="bold" fontSize="14">C</text>

                                {/* Atom O kanan */}
                                <circle cx="240" cy="90" r="20" fill="url(#gradLigand)" />
                                <text x="240" y="95" textAnchor="middle" fill="white" fontWeight="bold" fontSize="13">O</text>
                              </g>
                            )}

                            {selectedMolecule === 'BF3' && (
                              <g>
                                {/* Ikatan 3 arah 120 derajat */}
                                <line x1="160" y1="95" x2="160" y2="35" stroke="#94a3b8" strokeWidth="5" />
                                <line x1="160" y1="95" x2="90" y2="135" stroke="#94a3b8" strokeWidth="5" />
                                <line x1="160" y1="95" x2="230" y2="135" stroke="#94a3b8" strokeWidth="5" />

                                {/* Indikator Sudut */}
                                <text x="195" y="65" fill="#38bdf8" fontSize="11" fontWeight="bold">120°</text>

                                {/* Atom Pusat B */}
                                <circle cx="160" cy="95" r="20" fill="url(#gradCenter)" />
                                <text x="160" y="100" textAnchor="middle" fill="white" fontWeight="bold" fontSize="13">B</text>

                                {/* Atom Ligand F */}
                                <circle cx="160" cy="35" r="18" fill="url(#gradLigand)" />
                                <text x="160" y="40" textAnchor="middle" fill="white" fontWeight="bold" fontSize="12">F</text>

                                <circle cx="90" cy="135" r="18" fill="url(#gradLigand)" />
                                <text x="90" y="140" textAnchor="middle" fill="white" fontWeight="bold" fontSize="12">F</text>

                                <circle cx="230" cy="135" r="18" fill="url(#gradLigand)" />
                                <text x="230" y="140" textAnchor="middle" fill="white" fontWeight="bold" fontSize="12">F</text>
                              </g>
                            )}

                            {selectedMolecule === 'CH4' && (
                              <g>
                                {/* Tetrahedral 4 ikatan */}
                                <line x1="160" y1="90" x2="160" y2="30" stroke="#94a3b8" strokeWidth="5" />
                                <line x1="160" y1="90" x2="100" y2="140" stroke="#94a3b8" strokeWidth="5" />
                                <line x1="160" y1="90" x2="220" y2="140" stroke="#94a3b8" strokeWidth="5" />
                                <line x1="160" y1="90" x2="185" y2="115" stroke="#cbd5e1" strokeWidth="7" strokeDasharray="3 3" />

                                <text x="195" y="65" fill="#38bdf8" fontSize="11" fontWeight="bold">109,5°</text>

                                {/* Atom Pusat C */}
                                <circle cx="160" cy="90" r="22" fill="url(#gradCenter)" />
                                <text x="160" y="95" textAnchor="middle" fill="white" fontWeight="bold" fontSize="14">C</text>

                                {/* H atas */}
                                <circle cx="160" cy="30" r="14" fill="url(#gradLigand)" />
                                <text x="160" y="34" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H</text>

                                {/* H bawah kiri */}
                                <circle cx="100" cy="140" r="14" fill="url(#gradLigand)" />
                                <text x="100" y="144" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H</text>

                                {/* H bawah kanan */}
                                <circle cx="220" cy="140" r="14" fill="url(#gradLigand)" />
                                <text x="220" y="144" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H</text>

                                {/* H proyeksi baji */}
                                <circle cx="185" cy="115" r="12" fill="#93c5fd" />
                                <text x="185" y="119" textAnchor="middle" fill="#0f172a" fontWeight="bold" fontSize="9">H</text>
                              </g>
                            )}

                            {selectedMolecule === 'NH3' && (
                              <g>
                                {/* PEB di atas (elips transparan berkilau) */}
                                <ellipse cx="160" cy="45" rx="14" ry="22" fill="url(#gradLonePair)" />
                                <circle cx="156" cy="42" r="3" fill="#fef08a" />
                                <circle cx="164" cy="42" r="3" fill="#fef08a" />
                                <text x="160" y="20" textAnchor="middle" fill="#fbbf24" fontSize="10" fontWeight="bold">PEB (Tolakan Kuat)</text>

                                {/* Ikatan N-H terdorong ke bawah */}
                                <line x1="160" y1="95" x2="105" y2="145" stroke="#94a3b8" strokeWidth="5" />
                                <line x1="160" y1="95" x2="215" y2="145" stroke="#94a3b8" strokeWidth="5" />
                                <line x1="160" y1="95" x2="160" y2="155" stroke="#cbd5e1" strokeWidth="5" />

                                <text x="120" y="125" fill="#38bdf8" fontSize="11" fontWeight="bold">107°</text>

                                {/* N Pusat */}
                                <circle cx="160" cy="95" r="22" fill="url(#gradCenter)" />
                                <text x="160" y="100" textAnchor="middle" fill="white" fontWeight="bold" fontSize="14">N</text>

                                {/* H ligands */}
                                <circle cx="105" cy="145" r="13" fill="url(#gradLigand)" />
                                <text x="105" y="149" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H</text>
                                <circle cx="215" cy="145" r="13" fill="url(#gradLigand)" />
                                <text x="215" y="149" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H</text>
                                <circle cx="160" cy="155" r="13" fill="url(#gradLigand)" />
                                <text x="160" y="159" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H</text>
                              </g>
                            )}

                            {selectedMolecule === 'H2O' && (
                              <g>
                                {/* 2 PEB di atas atom O */}
                                <ellipse cx="140" cy="50" rx="12" ry="18" fill="url(#gradLonePair)" transform="rotate(-20 140 50)" />
                                <ellipse cx="180" cy="50" rx="12" ry="18" fill="url(#gradLonePair)" transform="rotate(20 180 50)" />
                                <text x="160" y="22" textAnchor="middle" fill="#fbbf24" fontSize="10" fontWeight="bold">2 PEB (Tolakan Ganda)</text>

                                {/* Bentuk Bengkok V */}
                                <line x1="160" y1="90" x2="100" y2="135" stroke="#94a3b8" strokeWidth="5" />
                                <line x1="160" y1="90" x2="220" y2="135" stroke="#94a3b8" strokeWidth="5" />

                                <path d="M 130 110 A 35 35 0 0 0 190 110" fill="none" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 3" />
                                <text x="160" y="125" textAnchor="middle" fill="#38bdf8" fontSize="11" fontWeight="bold">104,5°</text>

                                {/* O Pusat */}
                                <circle cx="160" cy="90" r="22" fill="url(#gradCenter)" />
                                <text x="160" y="95" textAnchor="middle" fill="white" fontWeight="bold" fontSize="14">O</text>

                                {/* H ligands */}
                                <circle cx="100" cy="135" r="14" fill="url(#gradLigand)" />
                                <text x="100" y="139" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H</text>

                                <circle cx="220" cy="135" r="14" fill="url(#gradLigand)" />
                                <text x="220" y="139" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H</text>
                              </g>
                            )}
                          </svg>

                          <span className="text-[11px] text-slate-400 mt-1">
                            Representasi Ruang 3D Geometri Molekul • Teori VSEPR
                          </span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 2: POLARITAS MOLEKUL */}
          {/* ======================================================== */}
          {activeSection === '2' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-4">
                <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center shrink-0">
                    <Compass className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">Bagian 2</span>
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      Polaritas Molekul (Momen Dipol)
                    </h2>
                  </div>
                </div>

                <div className="space-y-3 text-xs sm:text-sm text-slate-200 leading-relaxed">
                  <p>
                    Kepolaran suatu molekul ditentukan oleh dua faktor utama: <strong className="text-white">perbedaan keelektronegatifan antar atom penyusun</strong> dan <strong className="text-blue-300">bentuk geometri molekulnya</strong>.
                  </p>
                  <p>
                    Meskipun ikatan kovalen di dalam molekul bersifat polar (karena elektron ditarik lebih kuat oleh atom yang lebih elektronegatif), molekul secara keseluruhan bisa bersifat <strong className="text-rose-300">Nonpolar</strong> jika bentuk molekulnya simetris sehingga vektor-vektor momen dipol saling meniadakan.
                  </p>
                </div>

                {/* Perbandingan Interaktif: CO2 (Nonpolar) vs H2O (Polar) */}
                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedPolarityMolecule('CO2')}
                      className={`flex-1 p-3 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs sm:text-sm ${
                        selectedPolarityMolecule === 'CO2'
                          ? 'bg-blue-600 border-blue-400 text-white shadow-md'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      CO₂ → Nonpolar (Simetris Linear)
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedPolarityMolecule('H2O')}
                      className={`flex-1 p-3 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs sm:text-sm ${
                        selectedPolarityMolecule === 'H2O'
                          ? 'bg-red-600 border-red-400 text-white shadow-md'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      H₂O → Polar (Asimetris Bengkok / V)
                    </button>
                  </div>

                  {selectedPolarityMolecule === 'CO2' ? (
                    <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-blue-950/70 border border-blue-500/40 space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
                        <span className="font-mono text-lg font-black text-white">CO₂ (Karbondioksida)</span>
                        <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 font-bold border border-blue-500/30">
                          Nonpolar • μ = 0
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                        <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
                          <p>
                            • Atom Oksigen lebih elektronegatif daripada Karbon, sehingga ikatan C=O bersifat polar ke arah O (δ⁻).
                          </p>
                          <p>
                            • Namun karena geometrinya <strong className="text-white">Linear (180°)</strong>, kedua vektor momen dipol berlawanan arah dengan besar yang sama persis:
                          </p>
                          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 font-mono text-center text-xs text-cyan-300 font-bold">
                            μ_total = μ₁ + μ₂ = 0 Debye (Saling Meniadakan)
                          </div>
                          <p className="text-slate-400 text-[11px]">
                            Hasilnya: Distribusi muatan seimbang dan simetris, molekul tidak memiliki kutub permanen (Nonpolar).
                          </p>
                        </div>

                        {/* Visual Vektor Momen Dipol CO2 */}
                        <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 flex flex-col items-center justify-center">
                          <svg viewBox="0 0 280 110" className="w-full max-w-xs h-28">
                            {/* Atom O - C - O */}
                            <circle cx="50" cy="55" r="18" fill="#3b82f6" />
                            <text x="50" y="60" textAnchor="middle" fill="white" fontWeight="bold" fontSize="12">O (δ⁻)</text>

                            <line x1="70" y1="55" x2="120" y2="55" stroke="#94a3b8" strokeWidth="4" />

                            <circle cx="140" cy="55" r="20" fill="#ef4444" />
                            <text x="140" y="60" textAnchor="middle" fill="white" fontWeight="bold" fontSize="13">C (δ⁺)</text>

                            <line x1="160" y1="55" x2="210" y2="55" stroke="#94a3b8" strokeWidth="4" />

                            <circle cx="230" cy="55" r="18" fill="#3b82f6" />
                            <text x="230" y="60" textAnchor="middle" fill="white" fontWeight="bold" fontSize="12">O (δ⁻)</text>

                            {/* Vektor Dipol Kiri & Kanan Berlawanan */}
                            <line x1="125" y1="25" x2="65" y2="25" stroke="#38bdf8" strokeWidth="3" markerEnd="url(#arrowLeft)" />
                            <text x="95" y="18" textAnchor="middle" fill="#38bdf8" fontSize="10" fontWeight="bold">← μ₁</text>

                            <line x1="155" y1="25" x2="215" y2="25" stroke="#38bdf8" strokeWidth="3" markerEnd="url(#arrowRight)" />
                            <text x="185" y="18" textAnchor="middle" fill="#38bdf8" fontSize="10" fontWeight="bold">μ₂ →</text>

                            <text x="140" y="98" textAnchor="middle" fill="#94a3b8" fontSize="11" fontWeight="bold">
                              μ_netto = 0 (Nonpolar)
                            </text>
                          </svg>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-red-950/70 border border-red-500/40 space-y-4">
                      <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
                        <span className="font-mono text-lg font-black text-white">H₂O (Air)</span>
                        <span className="text-xs px-2.5 py-0.5 rounded-full bg-red-500/20 text-rose-300 font-bold border border-red-500/30">
                          Polar • μ &gt; 0
                        </span>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
                        <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
                          <p>
                            • Atom Oksigen sangat elektronegatif menarik pasangan elektron dari kedua atom Hidrogen menuju O (menghasilkan muatan parsial negatif δ⁻ pada O dan δ⁺ pada H).
                          </p>
                          <p>
                            • Geometri molekul H₂O adalah <strong className="text-white">Bengkok / Bentuk V (104,5°)</strong> akibat tolakan 2 Pasangan Elektron Bebas (PEB).
                          </p>
                          <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 font-mono text-center text-xs text-rose-300 font-bold">
                            μ_total = Σ μ ≠ 0 (Resultan Vektor Mengarah ke Oksigen)
                          </div>
                          <p className="text-slate-400 text-[11px]">
                            Hasilnya: Terjadi pemisahan kutub permanen positif dan negatif (Molekul Polar Tinggi).
                          </p>
                        </div>

                        {/* Visual Vektor Momen Dipol H2O */}
                        <div className="p-4 rounded-xl bg-slate-950/90 border border-slate-800 flex flex-col items-center justify-center">
                          <svg viewBox="0 0 280 130" className="w-full max-w-xs h-32">
                            {/* PEB di atas */}
                            <ellipse cx="140" cy="35" rx="16" ry="10" fill="#fbbf24" fillOpacity="0.3" />
                            <text x="140" y="24" textAnchor="middle" fill="#fbbf24" fontSize="9" fontWeight="bold">2 PEB (δ⁻)</text>

                            {/* Atom O Pusat */}
                            <circle cx="140" cy="55" r="20" fill="#ef4444" />
                            <text x="140" y="60" textAnchor="middle" fill="white" fontWeight="bold" fontSize="13">O (δ⁻)</text>

                            {/* Ikatan ke 2 H */}
                            <line x1="125" y1="65" x2="85" y2="105" stroke="#94a3b8" strokeWidth="4" />
                            <line x1="155" y1="65" x2="195" y2="105" stroke="#94a3b8" strokeWidth="4" />

                            <circle cx="80" cy="108" r="14" fill="#3b82f6" />
                            <text x="80" y="112" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H (δ⁺)</text>

                            <circle cx="200" cy="108" r="14" fill="#3b82f6" />
                            <text x="200" y="112" textAnchor="middle" fill="white" fontWeight="bold" fontSize="10">H (δ⁺)</text>

                            {/* Vektor Resultan ke atas */}
                            <line x1="140" y1="105" x2="140" y2="58" stroke="#f43f5e" strokeWidth="3" strokeDasharray="3 3" />
                            <polygon points="140,50 135,60 145,60" fill="#f43f5e" />
                            <text x="215" y="70" textAnchor="start" fill="#f43f5e" fontSize="10" fontWeight="bold">Resultan Dipol ↑</text>
                          </svg>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 3: GAYA ANTARMOLEKUL */}
          {/* ======================================================== */}
          {activeSection === '3' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-4">
                <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
                  <div className="w-10 h-10 rounded-xl bg-red-500/20 text-rose-400 border border-red-500/30 flex items-center justify-center shrink-0">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">Bagian 3</span>
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      Gaya Antarmolekul
                    </h2>
                  </div>
                </div>

                <div className="text-xs sm:text-sm text-slate-200 leading-relaxed space-y-2">
                  <p>
                    <strong className="text-white">Gaya antarmolekul</strong> adalah gaya tarik elektrostatik yang bekerja <span className="underline font-bold text-rose-300">di antara molekul-molekul</span> tetangga (bukan ikatan kimia intramolekul di dalam satu molekul). Gaya inilah yang menyatukan molekul-molekul dalam wujud cair dan padat.
                  </p>
                </div>

                {/* 3 Tab Pilihan Gaya Antarmolekul */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setSelectedIntermolecularForce('london')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      selectedIntermolecularForce === 'london'
                        ? 'bg-blue-600/30 border-blue-400 text-white shadow-md'
                        : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-blue-300">Tingkat Lemah</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-200 font-mono">Mr berpengaruh</span>
                    </div>
                    <h3 className="text-sm font-bold text-white">Gaya London / Dispersi</h3>
                    <p className="text-[11px] text-slate-400 mt-1">Pada molekul nonpolar akibat dipol sesaat</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedIntermolecularForce('dipol')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      selectedIntermolecularForce === 'dipol'
                        ? 'bg-purple-600/30 border-purple-400 text-white shadow-md'
                        : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-purple-300">Tingkat Sedang</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-200 font-mono">Dipol permanen</span>
                    </div>
                    <h3 className="text-sm font-bold text-white">Gaya Dipol - Dipol</h3>
                    <p className="text-[11px] text-slate-400 mt-1">Gaya elektrostatik antar molekul polar</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setSelectedIntermolecularForce('hidrogen')}
                    className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
                      selectedIntermolecularForce === 'hidrogen'
                        ? 'bg-red-600/30 border-rose-400 text-white shadow-md'
                        : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-rose-300">Tingkat Sangat Kuat</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-500/20 text-rose-200 font-mono">H + (F, O, N)</span>
                    </div>
                    <h3 className="text-sm font-bold text-white">Ikatan Hidrogen</h3>
                    <p className="text-[11px] text-slate-400 mt-1">Dipol khusus sangat kuat dengan PEB atom elektronegatif</p>
                  </button>
                </div>

                {/* Penjelasan Terperinci & Ilustrasi Gaya Antarmolekul */}
                <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-850 border border-slate-700 space-y-4">
                  {selectedIntermolecularForce === 'london' && (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-blue-300 font-bold text-sm">
                        <Activity className="w-4 h-4 text-blue-400" />
                        <span>1. Gaya London (Gaya Dispersi)</span>
                      </div>
                      <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
                        <p>
                          • Terjadi pada semua molekul, terutama merupakan satu-satunya gaya antarmolekul pada <strong className="text-white">molekul nonpolar</strong> (seperti O₂, N₂, CH₄, gas mulia, minyak).
                        </p>
                        <p>
                          • Disebabkan oleh pergerakan acak elektron yang pada suatu saat tertentu menghasilkan <strong className="text-blue-300">dipol sesaat (temporary dipole)</strong>. Dipol sesaat ini kemudian menginduksi awan elektron molekul tetangga menjadi <strong className="text-blue-300">dipol terimbas</strong> sehingga timbul gaya tarik lemah sesaat.
                        </p>
                        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300">
                          💡 <strong className="text-white">Faktor yang memengaruhi kekuatan gaya London:</strong> Semakin besar massa molekul relatif (Mr) dan semakin luas area kontak molekul, awan elektron semakin mudah terpolarisasi sehingga gaya London semakin kuat.
                        </div>
                      </div>

                      {/* Ilustrasi Visual Gaya London */}
                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center">
                        <svg viewBox="0 0 320 80" className="w-full max-w-sm h-20">
                          {/* Molekul A Nonpolar berfluktuasi */}
                          <ellipse cx="80" cy="40" rx="35" ry="25" fill="#1e293b" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 3" />
                          <text x="65" y="44" fill="#60a5fa" fontSize="11" fontWeight="bold">δ⁺</text>
                          <text x="95" y="44" fill="#f87171" fontSize="11" fontWeight="bold">δ⁻</text>

                          {/* Garis Gaya Tarik Sesaat */}
                          <line x1="120" y1="40" x2="190" y2="40" stroke="#38bdf8" strokeWidth="2" strokeDasharray="4 4" />
                          <text x="155" y="32" textAnchor="middle" fill="#38bdf8" fontSize="9" fontWeight="bold">Gaya London</text>

                          {/* Molekul B Terimbas */}
                          <ellipse cx="230" cy="40" rx="35" ry="25" fill="#1e293b" stroke="#38bdf8" strokeWidth="2" strokeDasharray="3 3" />
                          <text x="215" y="44" fill="#60a5fa" fontSize="11" fontWeight="bold">δ⁺</text>
                          <text x="245" y="44" fill="#f87171" fontSize="11" fontWeight="bold">δ⁻</text>
                        </svg>
                      </div>
                    </div>
                  )}

                  {selectedIntermolecularForce === 'dipol' && (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-purple-300 font-bold text-sm">
                        <Activity className="w-4 h-4 text-purple-400" />
                        <span>2. Gaya Dipol - Dipol</span>
                      </div>
                      <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
                        <p>
                          • Terjadi di antara <strong className="text-white">molekul-molekul polar</strong> yang memiliki momen dipol permanen (seperti HCl, SO₂, CHCl₃).
                        </p>
                        <p>
                          • Ujung kutub positif (δ⁺) dari satu molekul akan menarik secara elektrostatik ujung kutub negatif (δ⁻) dari molekul tetangga di sebelahnya.
                        </p>
                        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300">
                          💡 <strong className="text-white">Kekuatan:</strong> Lebih kuat daripada gaya London untuk molekul dengan massa Mr yang sebanding, karena gaya tarik berasal dari muatan permanen yang selalu ada.
                        </div>
                      </div>

                      {/* Ilustrasi Visual Dipol-Dipol */}
                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center">
                        <svg viewBox="0 0 320 80" className="w-full max-w-sm h-20">
                          {/* Molekul HCl 1 */}
                          <rect x="35" y="22" width="75" height="36" rx="18" fill="#1e1b4b" stroke="#a855f7" strokeWidth="2" />
                          <text x="55" y="45" fill="#60a5fa" fontSize="12" fontWeight="bold">H δ⁺</text>
                          <text x="88" y="45" fill="#f43f5e" fontSize="12" fontWeight="bold">Cl δ⁻</text>

                          {/* Gaya Tarik Elektrostatik Dipol */}
                          <line x1="115" y1="40" x2="195" y2="40" stroke="#c084fc" strokeWidth="3" strokeDasharray="3 3" />
                          <text x="155" y="32" textAnchor="middle" fill="#c084fc" fontSize="9" fontWeight="bold">Tarik Elektrostatik</text>

                          {/* Molekul HCl 2 */}
                          <rect x="200" y="22" width="75" height="36" rx="18" fill="#1e1b4b" stroke="#a855f7" strokeWidth="2" />
                          <text x="220" y="45" fill="#60a5fa" fontSize="12" fontWeight="bold">H δ⁺</text>
                          <text x="253" y="45" fill="#f43f5e" fontSize="12" fontWeight="bold">Cl δ⁻</text>
                        </svg>
                      </div>
                    </div>
                  )}

                  {selectedIntermolecularForce === 'hidrogen' && (
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
                        <Activity className="w-4 h-4 text-rose-400" />
                        <span>3. Ikatan Hidrogen (Interaksi Terkuat)</span>
                      </div>
                      <div className="text-xs text-slate-300 space-y-2 leading-relaxed">
                        <p>
                          • Merupakan jenis gaya dipol-dipol istimewa yang <strong className="text-rose-300">sangat kuat</strong>.
                        </p>
                        <p>
                          • Terjadi hanya ketika atom <strong className="text-white">Hidrogen (H)</strong> berikatan kovalen langsung dengan atom yang sangat kecil dan sangat elektronegatif: <strong className="text-amber-300">Fluorin (F)</strong>, <strong className="text-blue-300">Oksigen (O)</strong>, atau <strong className="text-emerald-300">Nitrogen (N)</strong> (Jembatan FON).
                        </p>
                        <p>
                          • Atom H yang kekurangan elektron ditarik kuat oleh <strong className="text-white">Pasangan Elektron Bebas (PEB)</strong> atom F, O, atau N pada molekul tetangganya.
                        </p>
                        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300">
                          💧 <strong className="text-white">Dampak Nyata:</strong> Menyebabkan air (H₂O) memiliki titik didih 100°C yang luar biasa tinggi (padahal molekul hidrida segolongannya seperti H₂S yang bermassa lebih besar berwujud gas pada suhu ruang dengan titik didih -60°C).
                        </div>
                      </div>

                      {/* Ilustrasi Visual Ikatan Hidrogen pada H2O */}
                      <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center">
                        <svg viewBox="0 0 320 85" className="w-full max-w-sm h-22">
                          {/* Molekul H2O 1 */}
                          <circle cx="70" cy="40" r="18" fill="#ef4444" />
                          <text x="70" y="45" textAnchor="middle" fill="white" fontWeight="bold" fontSize="11">O δ⁻</text>
                          <circle cx="45" cy="60" r="10" fill="#3b82f6" />
                          <text x="45" y="64" textAnchor="middle" fill="white" fontSize="9">H</text>
                          <circle cx="95" cy="60" r="10" fill="#3b82f6" />
                          <text x="95" y="64" textAnchor="middle" fill="white" fontSize="9">H δ⁺</text>

                          {/* Ikatan Hidrogen garis putus-putus merah */}
                          <line x1="110" y1="55" x2="185" y2="40" stroke="#f43f5e" strokeWidth="3" strokeDasharray="3 3" />
                          <text x="145" y="32" textAnchor="middle" fill="#f43f5e" fontSize="9" fontWeight="bold">Ikatan Hidrogen</text>

                          {/* Molekul H2O 2 */}
                          <circle cx="210" cy="40" r="18" fill="#ef4444" />
                          <text x="210" y="45" textAnchor="middle" fill="white" fontWeight="bold" fontSize="11">O δ⁻</text>
                          <circle cx="185" cy="60" r="10" fill="#3b82f6" />
                          <text x="185" y="64" textAnchor="middle" fill="white" fontSize="9">H</text>
                          <circle cx="235" cy="60" r="10" fill="#3b82f6" />
                          <text x="235" y="64" textAnchor="middle" fill="white" fontSize="9">H</text>
                        </svg>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 4: PENGARUH TERHADAP SIFAT FISIK ZAT */}
          {/* ======================================================== */}
          {activeSection === '4' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-4">
                <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
                    <ThermometerSun className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Bagian 4</span>
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      Pengaruh terhadap Sifat Fisik Zat
                    </h2>
                  </div>
                </div>

                {/* Hukum Kunci Secara Visual Highlight */}
                <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-red-950/80 via-purple-950/70 to-blue-950/80 border-2 border-red-500/40 text-center space-y-2 shadow-lg">
                  <span className="text-xs font-bold uppercase tracking-widest text-amber-300">
                    HUKUM UTAMA HUBUNGAN SIFAT FISIS
                  </span>
                  <p className="text-sm sm:text-base font-extrabold text-white leading-relaxed">
                    “Semakin kuat gaya antarmolekul → Semakin besar energi termal yang diperlukan untuk memisahkan molekul-molekul tersebut.”
                  </p>
                </div>

                {/* Simulasi Interaktif Tingkat Kekuatan Gaya */}
                <div className="space-y-3 pt-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-300">Uji Tingkat Kekuatan Gaya Antarmolekul:</span>
                    <span className="text-xs font-mono text-cyan-300 capitalize">{forceStrengthLevel}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setForceStrengthLevel('lemah')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs ${
                        forceStrengthLevel === 'lemah'
                          ? 'bg-blue-600 text-white border-blue-400 shadow-md'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      Gaya Lemah (London)
                    </button>
                    <button
                      type="button"
                      onClick={() => setForceStrengthLevel('sedang')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs ${
                        forceStrengthLevel === 'sedang'
                          ? 'bg-purple-600 text-white border-purple-400 shadow-md'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      Gaya Sedang (Dipol)
                    </button>
                    <button
                      type="button"
                      onClick={() => setForceStrengthLevel('kuat')}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer font-bold text-xs ${
                        forceStrengthLevel === 'kuat'
                          ? 'bg-red-600 text-white border-red-400 shadow-md'
                          : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                    >
                      Gaya Sangat Kuat (H-Bond)
                    </button>
                  </div>
                </div>

                {/* 5 Kartu Sifat Fisik Sesuai Spek Permintaan */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
                  {/* 1. Titik Didih */}
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-rose-300">1. Titik Didih</span>
                      <ThermometerSun className="w-4 h-4 text-rose-400" />
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Suhu saat tekanan uap cairan sama dengan tekanan luar. Gaya yang lebih kuat menahan molekul dalam fase cair lebih erat.
                    </p>
                    <div className="p-2 rounded-lg bg-slate-900/90 text-[11px] font-mono text-cyan-300">
                      Efek: {forceStrengthLevel === 'lemah' ? 'Rendah (mudah mendidih)' : forceStrengthLevel === 'sedang' ? 'Sedang' : 'Sangat Tinggi (butuh kalor besar)'}
                    </div>
                  </div>

                  {/* 2. Titik Leleh */}
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-blue-300">2. Titik Leleh</span>
                      <Layers className="w-4 h-4 text-blue-400" />
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Suhu perubahan zat dari padat ke cair saat energi kinetik mengatasi gaya kisi penahan molekul.
                    </p>
                    <div className="p-2 rounded-lg bg-slate-900/90 text-[11px] font-mono text-cyan-300">
                      Efek: {forceStrengthLevel === 'lemah' ? 'Rendah' : forceStrengthLevel === 'sedang' ? 'Sedang' : 'Tinggi'}
                    </div>
                  </div>

                  {/* 3. Viskositas */}
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-purple-300">3. Viskositas (Kekentalan)</span>
                      <Droplets className="w-4 h-4 text-purple-400" />
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Ketahanan zat cair untuk mengalir. Molekul yang saling tarik-menarik kuat akan lebih sulit bergeser satu sama lain.
                    </p>
                    <div className="p-2 rounded-lg bg-slate-900/90 text-[11px] font-mono text-cyan-300">
                      Efek: {forceStrengthLevel === 'lemah' ? 'Encer (mudah mengalir)' : forceStrengthLevel === 'sedang' ? 'Sedang' : 'Kental (sukar mengalir)'}
                    </div>
                  </div>

                  {/* 4. Tegangan Permukaan */}
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-cyan-300">4. Tegangan Permukaan</span>
                      <Waves className="w-4 h-4 text-cyan-400" />
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Gaya tarik ke arah dalam yang dialami molekul-molekul di permukaan zat cair sehingga membentuk luas permukaan sekecil mungkin.
                    </p>
                    <div className="p-2 rounded-lg bg-slate-900/90 text-[11px] font-mono text-cyan-300">
                      Efek: {forceStrengthLevel === 'lemah' ? 'Kecil' : forceStrengthLevel === 'sedang' ? 'Sedang' : 'Sangat Besar'}
                    </div>
                  </div>

                  {/* 5. Volatilitas / Penguapan */}
                  <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700 space-y-2 sm:col-span-2 lg:col-span-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-amber-300">5. Volatilitas / Penguapan</span>
                      <Wind className="w-4 h-4 text-amber-400" />
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Kemudahan suatu zat cair untuk menguap menjadi gas pada suhu kamar. Berbanding terbalik dengan kekuatan gaya tarik antarmolekul.
                    </p>
                    <div className="p-2 rounded-lg bg-slate-900/90 text-[11px] font-mono text-rose-300 font-bold">
                      Efek: {forceStrengthLevel === 'lemah' ? 'Sangat Mudah Menguap (Volatil Tinggi, cth: aseton/parfum)' : forceStrengthLevel === 'sedang' ? 'Sedang' : 'Sukar Menguap (Volatil Rendah, cth: air)'}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 5: CONTOH DALAM KEHIDUPAN SEHARI-HARI */}
          {/* ======================================================== */}
          {activeSection === '5' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-4">
                <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0">
                    <Beaker className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">Bagian 5</span>
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      Contoh dalam Kehidupan Sehari-hari
                    </h2>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Konsep struktur atom dan ikatan kimia ini bekerja secara langsung dalam fenomena benda-benda yang kita temui setiap hari:
                </p>

                {/* 4 Kartu Contoh Sesuai Spek Permintaan */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
                  {/* 1. H2O -> Ikatan Hidrogen */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-blue-950/70 to-slate-900 border border-blue-500/40 space-y-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                        <Droplets className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">Air (H₂O)</h3>
                        <span className="text-[10px] text-blue-300 font-mono">Dominan: Ikatan Hidrogen</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Jejaring ikatan hidrogen yang rapat antar-molekul H₂O menyebabkan air berwujud cair pada suhu kamar, memiliki tegangan permukaan tinggi sehingga serangga air bisa berjalan di atasnya, serta memiliki kalor jenis yang tinggi untuk menjaga kestabilan iklim bumi.
                    </p>
                  </div>

                  {/* 2. Alkohol -> Penguapan */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-indigo-950/70 to-slate-900 border border-indigo-500/40 space-y-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                        <Flame className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">Alkohol (Etanol / Hand Sanitizer)</h3>
                        <span className="text-[10px] text-indigo-300 font-mono">Interaksi Antarmolekul &amp; Penguapan</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Meskipun alkohol memiliki gugus -OH berikatan hidrogen, adanya rantai hidrokarbon nonpolar membuat gaya antarmolekul totalnya lebih lemah dibanding air murni. Akibatnya, alkohol cepat menguap di kulit dan menyerap kalor tubuh, menimbulkan sensasi dingin yang instan.
                    </p>
                  </div>

                  {/* 3. Minyak -> Gaya London & Nonpolar */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-amber-950/60 to-slate-900 border border-amber-500/40 space-y-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                        <Layers className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">Minyak Goreng &amp; Lemak</h3>
                        <span className="text-[10px] text-amber-300 font-mono">Dominan: Gaya London (Nonpolar)</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Minyak tersusun atas rantai hidrokarbon panjang yang bersifat nonpolar tanpa ikatan hidrogen. Molekul air polar lebih memilih berikatan kuat dengan sesama molekul air, sehingga minyak dan air tidak dapat bercampur (membentuk dua lapisan terpisah sesuai kaidah <em>like dissolves like</em>).
                    </p>
                  </div>

                  {/* 4. Parfum -> Zat Mudah Menguap */}
                  <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-red-950/70 to-slate-900 border border-red-500/40 space-y-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-red-500/20 text-rose-400 flex items-center justify-center shrink-0">
                        <Wind className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-white">Parfum &amp; Minyak Wangi</h3>
                        <span className="text-[10px] text-rose-300 font-mono">Volatilitas Tinggi &amp; Difusi Aroma</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Senyawa ester dan minyak atsiri dalam parfum memiliki gaya antarmolekul yang relatif lemah dan titik didih rendah. Hal ini menjadikannya sangat mudah menguap (volatil), melepaskan molekul aroma ke udara yang segera berdifusi dan tercium oleh indra penciuman manusia dari kejauhan.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 6: RANTAI KONSEP */}
          {/* ======================================================== */}
          {activeSection === '6' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-4">
                <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center shrink-0">
                    <LinkIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">Bagian 6</span>
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      Rantai Konsep Terpadu
                    </h2>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Kuasai alur keterhubungan logis konsep kimia: <strong className="text-white">dari tingkat sub-mikroskopis elektron hingga sifat makroskopis nyata</strong>. Klik setiap tahapan alur di bawah untuk melihat penjelasan rincinya:
                </p>

                {/* Alur Interaktif 5 Tahap Sesuai Permintaan */}
                <div className="space-y-3 pt-2">
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-1.5 p-2 bg-slate-950 rounded-2xl border border-slate-800">
                    {conceptChain.map((step, idx) => {
                      const isActive = activeChainStep === idx;
                      return (
                        <button
                          key={step.title}
                          type="button"
                          onClick={() => setActiveChainStep(idx)}
                          className={`flex-1 p-2.5 rounded-xl text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-0.5 ${
                            isActive
                              ? 'bg-gradient-to-r from-red-600 via-purple-600 to-blue-600 text-white font-extrabold shadow-md scale-[1.02]'
                              : 'bg-slate-900 hover:bg-slate-800 text-slate-300 font-semibold border border-slate-800'
                          }`}
                        >
                          <span className="text-[10px] opacity-75 font-mono">{step.badge}</span>
                          <span className="text-xs leading-tight">{step.title}</span>
                          {idx < conceptChain.length - 1 && (
                            <span className="text-[10px] text-slate-500 sm:hidden">↓</span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Kotak Penjelasan Rantai Konsep Terpilih */}
                  {(() => {
                    const curr = conceptChain[activeChainStep];
                    return (
                      <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-850 to-blue-950/60 border-2 border-purple-500/40 space-y-3 animate-in fade-in zoom-in-95">
                        <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
                          <div>
                            <span className="text-xs font-bold text-purple-400">{curr.badge}</span>
                            <h3 className="text-base sm:text-lg font-black text-white">{curr.title}</h3>
                            <span className="text-xs text-slate-400">{curr.subtitle}</span>
                          </div>
                          <div className="px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-bold">
                            Alur Ke-{activeChainStep + 1}
                          </div>
                        </div>

                        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">{curr.desc}</p>

                        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between text-xs">
                          <span className="text-slate-400">Fokus Kunci:</span>
                          <span className="font-bold text-rose-300">{curr.highlight}</span>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 7: HAL PENTING YANG HARUS DIPAHAMI */}
          {/* ======================================================== */}
          {activeSection === '7' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-4">
                <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center justify-center shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-rose-400 uppercase tracking-wider">Bagian 7</span>
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      Hal Penting yang Harus Dipahami
                    </h2>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-1">
                  {/* Poin 1 */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 text-xs font-black flex items-center justify-center border border-blue-400/40">1</span>
                      <h3 className="text-xs sm:text-sm font-bold text-white">Susunan Pasangan Elektron</h3>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Susunan pasangan elektron (PEI dan PEB) pada kulit valensi atom pusat menentukan bentuk geometri molekul berdasarkan prinsip tolakan minimum Teori VSEPR.
                    </p>
                  </div>

                  {/* Poin 2 */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 text-xs font-black flex items-center justify-center border border-indigo-400/40">2</span>
                      <h3 className="text-xs sm:text-sm font-bold text-white">Geometri Memengaruhi Polaritas</h3>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Geometri molekul memengaruhi kepolaran secara langsung. Molekul dengan ikatan polar tetap bisa bersifat nonpolar jika bentuknya simetris (vektor dipol saling meniadakan, contohnya CO₂ dan CCl₄).
                    </p>
                  </div>

                  {/* Poin 3 */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 text-xs font-black flex items-center justify-center border border-purple-400/40">3</span>
                      <h3 className="text-xs sm:text-sm font-bold text-white">Polaritas Menentukan Gaya Antarmolekul</h3>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Polaritas berkaitan erat dengan jenis gaya antarmolekul. Molekul nonpolar berikatan via gaya London, molekul polar via dipol-dipol, dan molekul dengan ikatan H-F, H-O, atau H-N memiliki ikatan hidrogen.
                    </p>
                  </div>

                  {/* Poin 4 */}
                  <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 text-xs font-black flex items-center justify-center border border-rose-400/40">4</span>
                      <h3 className="text-xs sm:text-sm font-bold text-white">Gaya Antarmolekul Menentukan Sifat Fisik</h3>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Gaya antarmolekul secara mutlak menentukan sifat fisik makroskopis zat: titik didih, titik leleh, viskositas, tegangan permukaan, serta volatilitas/kemudahan menguap.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* SECTION 8: KESIMPULAN PEMBELAJARAN */}
          {/* ======================================================== */}
          {activeSection === '8' && (
            <div className="space-y-4 animate-in fade-in duration-200">
              <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-red-950 rounded-2xl sm:rounded-3xl p-5 sm:p-8 border-2 border-red-500/40 shadow-xl space-y-5 text-white">
                <div className="flex items-center gap-3 border-b border-slate-700/80 pb-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-red-600 to-blue-600 flex items-center justify-center text-white shrink-0 shadow-md">
                    <CheckCircle2 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-blue-300 uppercase tracking-wider">Bagian 8</span>
                    <h2 className="text-lg sm:text-xl font-black text-white">
                      Kesimpulan Interaktif Pembelajaran
                    </h2>
                  </div>
                </div>

                <div className="space-y-3 text-xs sm:text-sm text-slate-200 leading-relaxed">
                  <p>
                    Melalui pemahaman <strong className="text-white">Struktur Atom &amp; Ikatan Kimia</strong>, kita menyadari bahwa sifat materi di dunia nyata bukanlah suatu kebetulan, melainkan hasil langsung dari keteraturan mikroskopis:
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700 flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-white block text-xs">Penolakan Elektron (VSEPR)</strong>
                        <span className="text-[11px] text-slate-300">Menghasilkan arsitektur geometri molekul yang stabil dan efisien.</span>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700 flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-white block text-xs">Simetri Geometri &amp; Polaritas</strong>
                        <span className="text-[11px] text-slate-300">Bentuk simetris menghilangkan momen dipol; bentuk asimetris menghasilkan polaritas netto.</span>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700 flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-white block text-xs">Hierarki Gaya Tarik</strong>
                        <span className="text-[11px] text-slate-300">Ikatan Hidrogen &gt; Gaya Dipol-Dipol &gt; Gaya London (Dispersi).</span>
                      </div>
                    </div>

                    <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-700 flex items-start gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <strong className="text-white block text-xs">Aplikasi Dunia Nyata</strong>
                        <span className="text-[11px] text-slate-300">Menjelaskan mengapa air mendukung kehidupan, alkohol mendinginkan kulit, dan parfum menyebarkan wangi.</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-700/80 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
                  <span className="text-slate-300 italic">
                    ✨ Anda telah menyelesaikan pembelajaran materi offline Kimia SMA! Tuliskan poin penting yang Anda peroleh di kolom catatan di bawah.
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const el = document.getElementById('input-catatan-penting-offline');
                      if (el) {
                        el.scrollIntoView({ behavior: 'smooth' });
                        el.focus();
                      }
                    }}
                    className="px-4 py-2 rounded-xl bg-white text-slate-950 font-bold hover:bg-slate-100 transition-all cursor-pointer text-center shrink-0 shadow-md"
                  >
                    Tulis Catatan Informasi Penting ↓
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Navigasi Bawah: Sebelumnya & Selanjutnya */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePrev}
              disabled={activeSection === '1'}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeSection === '1'
                  ? 'bg-slate-800/40 text-slate-500 cursor-not-allowed border border-slate-800'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
              }`}
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Bagian Sebelumnya</span>
            </button>

            <span className="text-[11px] text-slate-400">
              Bagian {activeSection} dari 8
            </span>

            <button
              type="button"
              onClick={handleNext}
              disabled={activeSection === '8'}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeSection === '8'
                  ? 'bg-slate-800/40 text-slate-500 cursor-not-allowed border border-slate-800'
                  : 'bg-gradient-to-r from-red-600 to-blue-600 hover:from-red-500 hover:to-blue-500 text-white shadow-md'
              }`}
            >
              <span>Bagian Selanjutnya</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

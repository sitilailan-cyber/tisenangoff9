import React, { useState } from 'react';
import {
  Dna,
  Binary,
  ArrowRight,
  ArrowLeft,
  RotateCcw,
  Sparkles,
  Info,
  CheckCircle2,
  ChevronRight,
  GitFork,
  HeartPulse,
} from 'lucide-react';

export const MateriBiologiPewarisanSifat: React.FC = () => {
  const [hasStartedReading, setHasStartedReading] = useState(false);
  const [activeSection, setActiveSection] = useState<'A' | 'B' | 'C' | 'D'>('A');

  // Interaktif Section B: Monohibrid Punnett Square (Bb x Bb)
  const [induk1Alel, setInduk1Alel] = useState<'BB' | 'Bb' | 'bb'>('Bb');
  const [induk2Alel, setInduk2Alel] = useState<'BB' | 'Bb' | 'bb'>('Bb');

  const sections: { id: 'A' | 'B' | 'C' | 'D'; label: string; title: string }[] = [
    { id: 'A', label: 'Bagian A', title: 'Gen & Kromosom' },
    { id: 'B', label: 'Bagian B', title: 'Hukum Mendel I' },
    { id: 'C', label: 'Bagian C', title: 'Hukum Mendel II' },
    { id: 'D', label: 'Bagian D', title: 'Hereditas Manusia' },
  ];

  const handleNextSection = () => {
    if (activeSection === 'A') setActiveSection('B');
    else if (activeSection === 'B') setActiveSection('C');
    else if (activeSection === 'C') setActiveSection('D');
  };

  const handlePrevSection = () => {
    if (activeSection === 'D') setActiveSection('C');
    else if (activeSection === 'C') setActiveSection('B');
    else if (activeSection === 'B') setActiveSection('A');
  };

  return (
    <div className="space-y-4 sm:space-y-6 w-full min-w-0">
      {!hasStartedReading ? (
        <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-emerald-950 via-teal-950 to-slate-950 p-6 sm:p-10 text-white shadow-xl border border-emerald-500/40">
          <div className="absolute -top-12 -right-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
          <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 max-w-2xl space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-400/20 text-emerald-200 border border-emerald-400/30 text-xs font-bold uppercase tracking-wider">
              <Dna className="w-3.5 h-3.5" />
              <span>Biologi SMA Fase F • Genetika</span>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              PEWARISAN SIFAT
            </h1>

            <p className="text-sm sm:text-base text-emerald-100 font-medium leading-relaxed">
              Memahami Pola Hereditas, Hukum Mendel, Genotipe–Fenotipe, dan Transmisi Sifat Genetik pada Makhluk Hidup
            </p>

            <div className="flex flex-wrap gap-2 pt-2">
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                🧬 Gen, Alel & DNA
              </span>
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                🌱 Hukum Mendel I & II
              </span>
              <span className="px-3 py-1 rounded-lg bg-white/10 text-xs font-semibold text-emerald-200 border border-white/10">
                🩸 Hereditas Golongan Darah & Silsilah
              </span>
            </div>

            <div className="pt-4">
              <button
                type="button"
                onClick={() => setHasStartedReading(true)}
                className="px-6 py-3 rounded-xl sm:rounded-2xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black text-sm sm:text-base transition-all shadow-lg shadow-emerald-400/25 active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                <span>🚀 MULAI BELAJAR BIOLOGI</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-4 sm:space-y-6 animate-in fade-in">
          {/* Header Navigasi Bagian Materi */}
          <div className="bg-slate-900/90 rounded-2xl p-3 sm:p-4 border border-slate-700/80 shadow-md flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              {sections.map((sec) => (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => setActiveSection(sec.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    activeSection === sec.id
                      ? 'bg-emerald-400 text-slate-950 shadow-md font-extrabold'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {sec.title}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => setHasStartedReading(false)}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Cover</span>
            </button>
          </div>

          {/* BAGIAN A: GEN & KROMOSOM */}
          {activeSection === 'A' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian A</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Konsep Gen, DNA, dan Alel</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <Dna className="w-5 h-5" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm text-slate-300 leading-relaxed">
                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-2">
                  <h3 className="font-bold text-emerald-300 flex items-center gap-2 text-sm">
                    <span>🧬 Gen & Alel</span>
                  </h3>
                  <p>
                    <strong>Gen</strong> adalah unit terkecil materi genetik pembawa sifat yang tersusun dari segmen DNA
                    pada lokus spesifik kromosom.
                  </p>
                  <p>
                    <strong>Alel</strong> adalah pasangan gen sejenis yang terletak pada lokus bersesuaian pada kromosom
                    homolog (misal alel B untuk bulat, b untuk keriput).
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-2">
                  <h3 className="font-bold text-teal-300 flex items-center gap-2 text-sm">
                    <span>🔬 Genotipe vs Fenotipe</span>
                  </h3>
                  <p>
                    <strong>Genotipe:</strong> Susunan genetik aktual suatu individu yang tidak tampak langsung (contoh:
                    BB, Bb, bb).
                  </p>
                  <p>
                    <strong>Fenotipe:</strong> Karakteristik fisik atau sifat biologis yang teramati secara langsung
                    sebagai hasil ekspresi genotipe dan lingkungan (contoh: bunga merah, biji bulat).
                  </p>
                </div>
              </div>

              {/* Istilah Penting */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700">
                  <strong className="text-emerald-300 block mb-1">Dominan</strong>
                  Sifat gen yang menutupi alel pasangannya, diekspresikan dengan huruf kapital (misal B).
                </div>
                <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700">
                  <strong className="text-emerald-300 block mb-1">Resesif</strong>
                  Sifat gen yang tertutupi oleh sifat dominan, hanya muncul bila dalam keadaan homozigot (misal bb).
                </div>
                <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700">
                  <strong className="text-emerald-300 block mb-1">Homozigot vs Heterozigot</strong>
                  Homozigot memiliki alel identik (BB atau bb), sedangkan heterozigot memiliki alel berbeda (Bb).
                </div>
              </div>
            </div>
          )}

          {/* BAGIAN B: HUKUM MENDEL I (MONOHIBRID) */}
          {activeSection === 'B' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian B</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Hukum Mendel I (Hukum Segregasi Bebas)</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <GitFork className="w-5 h-5" />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-r from-teal-950 to-emerald-950 border border-emerald-500/30 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-2">
                <p>
                  <strong>Hukum Segregasi Bebas:</strong> Pada saat pembentukan gamet (meiosis), pasangan gen (alel) akan
                  memisah (bersegregasi) secara bebas sehingga setiap gamet hanya membawa satu gen dari pasangannya.
                </p>
                <p className="text-emerald-300 font-semibold">
                  Contoh: Persilangan Monohibrid (satu sifat beda, misal bentuk biji bulat [B] vs keriput [b]).
                </p>
              </div>

              {/* Punnett Square Monohibrid */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-4">
                <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wide">
                  🌱 Simulasi Papan Catur Punnett Persilangan Monohibrid (F2: Bb x Bb)
                </h4>

                <div className="overflow-x-auto">
                  <table className="w-full text-center border-collapse max-w-sm mx-auto text-xs sm:text-sm">
                    <thead>
                      <tr>
                        <th className="p-2 border border-slate-700 bg-slate-900 text-slate-400">Gamet</th>
                        <th className="p-2 border border-slate-700 bg-emerald-950 text-emerald-300 font-bold">B</th>
                        <th className="p-2 border border-slate-700 bg-emerald-950 text-emerald-300 font-bold">b</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="p-2 border border-slate-700 bg-emerald-950 text-emerald-300 font-bold">B</td>
                        <td className="p-3 border border-slate-700 bg-slate-900 font-mono font-bold text-white">
                          BB <span className="block text-[10px] text-emerald-300 font-sans">Bulat</span>
                        </td>
                        <td className="p-3 border border-slate-700 bg-slate-900 font-mono font-bold text-white">
                          Bb <span className="block text-[10px] text-emerald-300 font-sans">Bulat</span>
                        </td>
                      </tr>
                      <tr>
                        <td className="p-2 border border-slate-700 bg-emerald-950 text-emerald-300 font-bold">b</td>
                        <td className="p-3 border border-slate-700 bg-slate-900 font-mono font-bold text-white">
                          Bb <span className="block text-[10px] text-emerald-300 font-sans">Bulat</span>
                        </td>
                        <td className="p-3 border border-slate-700 bg-slate-900 font-mono font-bold text-amber-300">
                          bb <span className="block text-[10px] text-amber-300 font-sans">Keriput</span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 text-center">
                    <span className="text-slate-400 block mb-1">Rasio Genotipe F2:</span>
                    <strong className="text-emerald-300 text-sm font-mono">BB : Bb : bb = 1 : 2 : 1</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">(25% BB : 50% Bb : 25% bb)</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 text-center">
                    <span className="text-slate-400 block mb-1">Rasio Fenotipe F2:</span>
                    <strong className="text-emerald-300 text-sm font-mono">Bulat : Keriput = 3 : 1</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">(75% Bulat : 25% Keriput)</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* BAGIAN C: HUKUM MENDEL II (DIHIBRID) */}
          {activeSection === 'C' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian C</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Hukum Mendel II (Asortasi Bebas)</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <Binary className="w-5 h-5" />
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 text-xs sm:text-sm text-slate-200 leading-relaxed space-y-2">
                <p>
                  <strong>Hukum Pengelompokan Bebas (Asortasi Bebas):</strong> Bila dua individu berbeda satu sama lain
                  dalam dua pasang sifat atau lebih, maka penurunan sifat yang satu tidak tergantung pada penurunan
                  sifat yang lain.
                </p>
                <p className="text-emerald-300 font-semibold">
                  Contoh Dihibrid: Biji bulat-kuning (BBKK) disilangkan dengan biji keriput-hijau (bbkk).
                </p>
              </div>

              {/* Rasio F2 Dihibrid 9:3:3:1 */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-emerald-500/30 space-y-3">
                <h4 className="text-xs font-bold text-emerald-300 uppercase tracking-wide">
                  Rasio Fenotipe Keturunan F2 Persilangan Dihibrid:
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
                  <div className="p-3 rounded-xl bg-slate-800 border border-emerald-500/40">
                    <span className="text-lg font-bold text-emerald-300 block">9 / 16</span>
                    <strong className="text-white">Bulat Kuning</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">B_K_</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-800 border border-teal-500/40">
                    <span className="text-lg font-bold text-teal-300 block">3 / 16</span>
                    <strong className="text-white">Bulat Hijau</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">B_kk</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-800 border border-amber-500/40">
                    <span className="text-lg font-bold text-amber-300 block">3 / 16</span>
                    <strong className="text-white">Keriput Kuning</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">bbK_</span>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-800 border border-red-500/40">
                    <span className="text-lg font-bold text-red-300 block">1 / 16</span>
                    <strong className="text-white">Keriput Hijau</strong>
                    <span className="text-[10px] text-slate-400 block mt-0.5">bbkk</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* BAGIAN D: HEREDITAS PADA MANUSIA */}
          {activeSection === 'D' && (
            <div className="bg-slate-900/90 rounded-2xl sm:rounded-3xl p-5 sm:p-7 border border-slate-700/80 shadow-md space-y-5">
              <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Bagian D</span>
                  <h2 className="text-lg sm:text-xl font-bold text-white">Hereditas pada Manusia</h2>
                </div>
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-300 flex items-center justify-center">
                  <HeartPulse className="w-5 h-5" />
                </div>
              </div>

              {/* Golongan Darah ABO & Rhesus */}
              <div className="p-4 rounded-xl bg-slate-800/80 border border-slate-700/70 space-y-3">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <span>🩸 Pewarisan Golongan Darah Sistem ABO (Alel Ganda):</span>
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700">
                    <strong className="text-emerald-300 block">Golongan A</strong>
                    <span className="text-slate-300 font-mono">IᴬIᴬ atau IᴬIᴼ</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700">
                    <strong className="text-emerald-300 block">Golongan B</strong>
                    <span className="text-slate-300 font-mono">IᴮIᴮ atau IᴮIᴼ</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700">
                    <strong className="text-emerald-300 block">Golongan AB</strong>
                    <span className="text-slate-300 font-mono">IᴬIᴮ (Kodominan)</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-700">
                    <strong className="text-emerald-300 block">Golongan O</strong>
                    <span className="text-slate-300 font-mono">IᴼIᴼ (Resesif)</span>
                  </div>
                </div>
              </div>

              {/* Kelainan Genetik */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm">
                <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700 space-y-1.5">
                  <h4 className="font-bold text-emerald-300">Penyakit Terpaut Kromosom X (Seks):</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>Buta Warna & Hemofilia</strong> dikendalikan oleh gen resesif pada kromosom X. Laki-laki (XY)
                    lebih rentan menderita kelainan karena hanya memiliki satu kromosom X.
                  </p>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-800/70 border border-slate-700 space-y-1.5">
                  <h4 className="font-bold text-emerald-300">Kelainan Terpaut Autosom:</h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong>Albinisme & Anemia Sel Sabit (Sickle Cell)</strong> diwariskan melalui autosom (kromosom tubuh)
                    dan dapat terjadi pada laki-laki maupun perempuan dengan frekuensi peluang yang sama.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Tombol Navigasi Bawah */}
          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handlePrevSection}
              disabled={activeSection === 'A'}
              className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white disabled:opacity-30 disabled:cursor-not-allowed text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Bagian Sebelumnya</span>
            </button>

            <button
              type="button"
              onClick={handleNextSection}
              disabled={activeSection === 'D'}
              className="px-4 py-2 rounded-xl bg-emerald-400 hover:bg-emerald-300 text-slate-950 disabled:opacity-30 disabled:cursor-not-allowed text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <span>Bagian Berikutnya</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

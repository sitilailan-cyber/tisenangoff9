import React, { useState } from 'react';
import {
  Trophy,
  RotateCcw,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Flag,
  Dna,
  X,
} from 'lucide-react';
import { joyfulGameMusic } from '../../../services/audio/joyfulGameMusic';

interface BiologiBalapanPewarisanProps {
  onFinishGame: (score: number) => void;
  onBackToGameList?: () => void;
  onClose?: () => void;
}

interface RaceQuestion {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

const RACE_QUESTIONS: RaceQuestion[] = [
  {
    id: 1,
    question: 'Tokoh biologi yang dijuluki sebagai "Bapak Genetika" karena meneliti pewarisan sifat pada kacang ercis adalah...',
    options: ['Gregor Johann Mendel', 'Charles Darwin', 'Louis Pasteur', 'Robert Hooke'],
    correct: 0,
    explanation: 'Gregor Johann Mendel meneliti pola pewarisan sifat tanaman ercis (Pisum sativum) dan merumuskan Hukum Mendel.',
  },
  {
    id: 2,
    question: 'Sifat fisik atau karakteristik yang tampak dan dapat diamati langsung pada suatu individu disebut...',
    options: ['Genotip', 'Fenotip', 'Alel homozigot', 'Kariotipe'],
    correct: 1,
    explanation: 'Fenotip adalah perwujudan atau ekspresi fisik gen yang dapat diamati langsung (contoh: warna bunga, bentuk biji, tinggi tanaman).',
  },
  {
    id: 3,
    question: 'Susunan genetik sebenarnya dari suatu individu (misalnya: BB, Bb, atau bb) dinamakan...',
    options: ['Fenotip', 'Sentromer', 'Genotip', 'Nukleosom'],
    correct: 2,
    explanation: 'Genotip adalah komposisi alel/faktor genetik penyusun sifat yang diwariskan dari kedua induk.',
  },
  {
    id: 4,
    question: 'Sifat gen yang mampu menutupi ekspresi dari gen pasangannya saat keadaan heterozigot disebut sifat...',
    options: ['Resesif', 'Intermediet', 'Kodominan', 'Dominan'],
    correct: 3,
    explanation: 'Gen dominan menutupi pengaruh alel pasangannya (resesif) sehingga hanya sifat dominan yang terekspresikan (misal: Bb berfenotip dominan).',
  },
  {
    id: 5,
    question: 'Individu yang memiliki pasangan alel yang tidak identik atau berbeda (misalnya: Tt atau Mm) disebut...',
    options: ['Homozigot dominan', 'Heterozigot', 'Homozigot resesif', 'Hemizigot'],
    correct: 1,
    explanation: 'Heterozigot memiliki dua alel yang berlainan pada lokus yang sama (Tt), sedangkan homozigot memiliki alel identik (TT atau tt).',
  },
  {
    id: 6,
    question: 'Rasio fenotip keturunan F2 pada persilangan monohibrid dominan penuh (Aa × Aa) adalah...',
    options: ['3 : 1', '1 : 2 : 1', '9 : 3 : 3 : 1', '1 : 1'],
    correct: 0,
    explanation: 'Persilangan monohibrid dominan penuh menghasilkan perbandingan fenotip F2 yaitu 3 dominan : 1 resesif (genotip: 1 AA : 2 Aa : 1 aa).',
  },
  {
    id: 7,
    question: 'Rasio fenotip keturunan F2 pada persilangan dihibrid Hukum II Mendel (AaBb × AaBb) adalah...',
    options: ['12 : 3 : 1', '9 : 7', '9 : 3 : 3 : 1', '15 : 1'],
    correct: 2,
    explanation: 'Persilangan dihibrid menghasilkan 16 kombinasi dengan perbandingan fenotip F2 yaitu 9 : 3 : 3 : 1 sesuai hukum pengelompokan bebas.',
  },
  {
    id: 8,
    question: 'Contoh kelainan genetik pada manusia yang terpaut pada kromosom kelamin X adalah...',
    options: ['Albinisme & Anemia', 'Sindrom Down', 'Polidaktili', 'Buta warna & Hemofilia'],
    correct: 3,
    explanation: 'Buta warna dan hemofilia merupakan kelainan genetik resesif yang terpaut pada kromosom X (gonosom).',
  },
  {
    id: 9,
    question: 'Sistem penggolongan darah manusia tipe ABO dikendalikan oleh fenomena genetika...',
    options: ['Poligeni', 'Alel ganda (Iᴬ, Iᴮ, Iᴼ)', 'Pautan autosom', 'Kriptomeri'],
    correct: 1,
    explanation: 'Golongan darah ABO diatur oleh alel ganda pada satu lokus gen yang sama, yaitu alel Iᴬ, Iᴮ, dan Iᴼ.',
  },
  {
    id: 10,
    question: 'Hukum I Mendel yang menyatakan pemisahan pasangan alel secara bebas saat pembentukan gamet disebut hukum...',
    options: ['Segregasi bebas alel', 'Asortasi bebas gen', 'Dominansi mutlak', 'Pautan kelamin'],
    correct: 0,
    explanation: 'Hukum I Mendel adalah Hukum Segregasi Bebas (pemisahan alel secara bebas pada saat pembentukan gamet/meiosis).',
  },
];

export const BiologiBalapanPewarisan: React.FC<BiologiBalapanPewarisanProps> = ({
  onFinishGame,
  onBackToGameList,
  onClose,
}) => {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [p1Distance, setP1Distance] = useState<number>(0);
  const [p2Distance, setP2Distance] = useState<number>(0);
  const [p1Score, setP1Score] = useState<number>(0);
  const [p2Score, setP2Score] = useState<number>(0);

  const [p1SelectedOpt, setP1SelectedOpt] = useState<number | null>(null);
  const [p2SelectedOpt, setP2SelectedOpt] = useState<number | null>(null);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const currentQ = RACE_QUESTIONS[currentIdx];
  const isRoundEvaluated = p1SelectedOpt !== null && p2SelectedOpt !== null;

  // Evaluasi ketika kedua pemain telah memilih
  const evaluateAnswers = (p1Choice: number, p2Choice: number) => {
    const isP1Correct = p1Choice === currentQ.correct;
    const isP2Correct = p2Choice === currentQ.correct;

    if (isP1Correct) {
      setP1Distance((prev) => Math.min(100, prev + 10));
      setP1Score((prev) => prev + 10);
    } else {
      setP1Distance((prev) => Math.min(100, prev + 2));
    }

    if (isP2Correct) {
      setP2Distance((prev) => Math.min(100, prev + 10));
      setP2Score((prev) => prev + 10);
    } else {
      setP2Distance((prev) => Math.min(100, prev + 2));
    }

    if (isP1Correct || isP2Correct) {
      joyfulGameMusic.playCorrect();
    } else {
      joyfulGameMusic.playWrong();
    }
  };

  const handleP1Select = (idx: number) => {
    if (p1SelectedOpt !== null || isFinished) return;
    setP1SelectedOpt(idx);
    if (p2SelectedOpt !== null) {
      evaluateAnswers(idx, p2SelectedOpt);
    }
  };

  const handleP2Select = (idx: number) => {
    if (p2SelectedOpt !== null || isFinished) return;
    setP2SelectedOpt(idx);
    if (p1SelectedOpt !== null) {
      evaluateAnswers(p1SelectedOpt, idx);
    }
  };

  const handleNextRound = () => {
    if (currentIdx + 1 < RACE_QUESTIONS.length) {
      setCurrentIdx((prev) => prev + 1);
      setP1SelectedOpt(null);
      setP2SelectedOpt(null);
    } else {
      setIsFinished(true);
      joyfulGameMusic.playVictory();
    }
  };

  const handleRestart = () => {
    setCurrentIdx(0);
    setP1Distance(0);
    setP2Distance(0);
    setP1Score(0);
    setP2Score(0);
    setP1SelectedOpt(null);
    setP2SelectedOpt(null);
    setIsFinished(false);
  };

  const isP1Leading = p1Distance > p2Distance;
  const isP2Leading = p2Distance > p1Distance;
  const isDraw = p1Distance === p2Distance;

  return (
    <div className="w-full max-w-4xl mx-auto rounded-2xl overflow-hidden shadow-2xl border border-emerald-500/40 bg-slate-950 text-white font-sans text-xs">
      {/* 1. Header Kompak */}
      <div className="px-3 py-2 bg-slate-900/95 border-b border-emerald-900/50 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          {onBackToGameList && (
            <button
              type="button"
              onClick={onBackToGameList}
              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] sm:text-xs font-bold transition-all flex items-center gap-1 border border-slate-700 cursor-pointer shrink-0 active:scale-95"
            >
              ← <span>Game</span>
            </button>
          )}

          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 font-extrabold text-[11px] sm:text-xs truncate">
            <Dna className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="truncate">Balapan Lari Pewarisan (2 Pemain)</span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 text-[11px] sm:text-xs">
          <div className="px-2 py-0.5 rounded-lg bg-slate-900 border border-emerald-800/60 text-emerald-300 font-bold">
            Ronde: <span className="font-mono text-white">{currentIdx + 1}/10</span>
          </div>
          {(onClose || onBackToGameList) && (
            <button
              type="button"
              onClick={onClose || onBackToGameList}
              className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-colors flex items-center justify-center cursor-pointer shrink-0"
              title="Tutup Game & Kembali"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* 2. Konten Utama: Finish Screen ATAU 2 Kolom Soal Pemain */}
      {isFinished ? (
        <div className="p-4 sm:p-6 text-center space-y-4 animate-in fade-in zoom-in-95 duration-200">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-emerald-400 via-amber-400 to-purple-400 p-0.5 shadow-xl">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Trophy className="w-7 h-7 text-amber-400 animate-bounce" />
            </div>
          </div>

          <div>
            <h2 className="text-base sm:text-xl font-black text-white">
              {isP1Leading
                ? '🏆 Juara 1: Pelari 1! 🏃‍♂️🎉'
                : isP2Leading
                ? '🏆 Juara 1: Pelari 2! 🏃‍♀️🎉'
                : '🤝 Balapan Lari Berakhir Seri! 🏃‍♂️🏃‍♀️'}
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-md mx-auto">
              {isP1Leading
                ? 'Selamat untuk Pelari 1 (Hijau)! Pemahaman konsep pewarisan sifatmu sangat luar biasa!'
                : isP2Leading
                ? 'Selamat untuk Pelari 2 (Ungu)! Pemahaman konsep pewarisan sifatmu sangat luar biasa!'
                : 'Kedua pelari sama-sama hebat dan menguasai konsep pewarisan sifat dengan sangat baik!'}
            </p>
          </div>

          {/* Kartu Statistik Pemain */}
          <div className="grid grid-cols-2 gap-2 sm:gap-3 max-w-md mx-auto pt-1">
            {/* Pemain 1 */}
            <div className="p-2 sm:p-3 rounded-xl bg-slate-900/90 border border-emerald-500/50 text-left">
              <div className="flex items-center gap-1.5 mb-1">
                <span className="text-base sm:text-lg">🏃‍♂️</span>
                <span className="font-extrabold text-emerald-400 text-xs sm:text-sm">Pelari 1</span>
              </div>
              <div className="text-[10px] sm:text-[11px] text-slate-300 space-y-0.5">
                <p>Jarak: <span className="font-bold text-emerald-300">{p1Distance}m</span></p>
                <p>Skor: <span className="font-bold text-white">{p1Score} poin</span></p>
              </div>
            </div>

            {/* Pemain 2 */}
            <div className="p-2 sm:p-3 rounded-xl bg-slate-900/90 border border-purple-500/50 text-left">
              <div className="flex items-center gap-1.5 mb-1">
                <span className="text-base sm:text-lg">🏃‍♀️</span>
                <span className="font-extrabold text-purple-400 text-xs sm:text-sm">Pelari 2</span>
              </div>
              <div className="text-[10px] sm:text-[11px] text-slate-300 space-y-0.5">
                <p>Jarak: <span className="font-bold text-purple-300">{p2Distance}m</span></p>
                <p>Skor: <span className="font-bold text-white">{p2Score} poin</span></p>
              </div>
            </div>
          </div>

          {/* Tombol Aksi */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleRestart}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-all border border-slate-700 flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Lari Lagi</span>
            </button>
            <button
              type="button"
              onClick={() => onFinishGame(Math.max(p1Score, p2Score) * 10 || 100)}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 text-white font-black text-xs shadow-lg shadow-emerald-500/25 flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Trophy className="w-3.5 h-3.5 text-amber-300" />
              <span>Selesaikan Misi & Buka Misi 5 dan Misi 6</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      ) : (
        <div className="p-1.5 sm:p-3 md:p-4 space-y-2 sm:space-y-3">
          {/* GRID 2 KOLOM: KOTAK SOAL TETAP BERDAMPINGAN WALAUPUN DARI TAMPILAN HP (grid-cols-2) */}
          <div className="grid grid-cols-2 gap-1.5 sm:gap-3 md:gap-4 items-stretch">
            {/* ===================== KOLOM SOAL PEMAIN 1 ===================== */}
            <div className="flex flex-col rounded-xl bg-slate-900/90 border border-emerald-500/40 p-1.5 sm:p-2.5 md:p-3 shadow-md space-y-1.5 sm:space-y-2.5">
              {/* Header Kolom Pemain 1 */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div className="flex items-center gap-1 sm:gap-1.5">
                  <span className="text-sm sm:text-base">🏃‍♂️</span>
                  <div className="min-w-0">
                    <h3 className="font-black text-[10px] sm:text-xs md:text-sm text-emerald-400 leading-tight truncate">
                      Pemain 1 (Pelari Hijau)
                    </h3>
                    <p className="text-[9px] sm:text-[10px] text-slate-400 font-medium">
                      Skor: <span className="text-white font-bold">{p1Score}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {isP1Leading && (
                    <span className="text-[8px] sm:text-[9px] px-1 sm:px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30 whitespace-nowrap">
                      🔥 Unggul
                    </span>
                  )}
                  {isDraw && (
                    <span className="text-[8px] sm:text-[9px] px-1 sm:px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-bold whitespace-nowrap">
                      🤝 Seri
                    </span>
                  )}
                  <span className="text-[8px] sm:text-[10px] font-mono font-bold text-emerald-300 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-800 whitespace-nowrap">
                    {p1Distance}m/100m
                  </span>
                </div>
              </div>

              {/* LINTASAN BALAPAN LARI PEMAIN 1 (DI ATAS KOTAK SOAL) */}
              <div className="p-1 sm:p-2 rounded-lg bg-slate-950 border border-emerald-600/40 shadow-inner">
                <div className="flex items-center justify-between text-[8px] sm:text-[9px] font-bold text-slate-400 mb-0.5 sm:mb-1">
                  <span className="text-emerald-400">🏁 Start (0m)</span>
                  <span className="text-amber-400 font-mono flex items-center gap-0.5">
                    <Flag className="w-2.5 h-2.5 text-amber-400" />
                    Finis (100m)
                  </span>
                </div>
                {/* Track Bar Lari Pemain 1 */}
                <div className="w-full bg-slate-900 h-5 sm:h-7 rounded-md border border-slate-800 relative overflow-hidden flex items-center px-1">
                  {/* Garis Finis Kotak-kotak */}
                  <div className="absolute right-0 top-0 bottom-0 w-2.5 sm:w-3 bg-[repeating-linear-gradient(45deg,#fff,#fff_2px,#000_2px,#000_4px)] opacity-20 pointer-events-none" />
                  {/* Orang Lari Pemain 1 */}
                  <div
                    className="h-3.5 sm:h-5 rounded bg-gradient-to-r from-emerald-600 via-teal-400 to-emerald-300 transition-all duration-500 ease-out flex items-center justify-end pr-0.5 sm:pr-1 shadow-md shadow-emerald-500/40"
                    style={{ width: `${Math.max(12, p1Distance)}%` }}
                  >
                    <span className="text-[11px] sm:text-xs drop-shadow transform scale-x-[-1]">🏃‍♂️</span>
                  </div>
                </div>
              </div>

              {/* KOTAK SOAL PEMAIN 1 */}
              <div className="flex-1 flex flex-col justify-between p-1.5 sm:p-2.5 rounded-xl bg-slate-950/90 border border-emerald-900/60 space-y-1.5 sm:space-y-2">
                <div>
                  <div className="flex items-center justify-between text-[8px] sm:text-[9px] text-slate-400 mb-0.5 sm:mb-1">
                    <span className="font-extrabold text-emerald-400 uppercase tracking-wider">
                      Soal Pemain 1
                    </span>
                    <span className="px-1 sm:px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 font-mono font-bold text-slate-300 text-[8px] sm:text-[9px]">
                      Ronde {currentIdx + 1}/10
                    </span>
                  </div>
                  <h4 className="text-[10px] sm:text-[11px] md:text-xs font-bold text-white leading-snug line-clamp-4">
                    {currentQ.question}
                  </h4>
                </div>

                {/* 4 Opsi Pilihan Pemain 1 */}
                <div className="grid grid-cols-1 gap-1 sm:gap-1.5 pt-0.5">
                  {currentQ.options.map((opt, i) => {
                    const isSelected = p1SelectedOpt === i;
                    const isCorrectOpt = i === currentQ.correct;

                    let btnStyle = 'bg-slate-900/90 hover:bg-slate-800 border-slate-800 text-slate-200 cursor-pointer';

                    if (p1SelectedOpt !== null && !isRoundEvaluated) {
                      // Jawaban tersimpan tetapi menunggu Pemain 2
                      if (isSelected) {
                        btnStyle = 'bg-emerald-800/80 border-emerald-400 text-white font-bold ring-1 ring-emerald-400/60';
                      } else {
                        btnStyle = 'bg-slate-900/40 border-slate-800/50 text-slate-500 opacity-60';
                      }
                    } else if (isRoundEvaluated) {
                      // Hasil sudah dievaluasi untuk kedua pemain
                      if (isCorrectOpt) {
                        btnStyle = 'bg-emerald-600/90 border-emerald-400 text-white font-bold ring-2 ring-emerald-400/50 shadow-md';
                      } else if (isSelected) {
                        btnStyle = 'bg-rose-600/90 border-rose-400 text-white font-bold ring-1 ring-rose-400/50';
                      } else {
                        btnStyle = 'bg-slate-900/30 border-slate-800/50 text-slate-500 opacity-40';
                      }
                    }

                    return (
                      <button
                        key={i}
                        type="button"
                        disabled={p1SelectedOpt !== null}
                        onClick={() => handleP1Select(i)}
                        className={`w-full py-1 sm:py-1.5 px-1.5 sm:px-2.5 rounded-lg border text-left transition-all flex items-center gap-1 sm:gap-1.5 active:scale-98 ${btnStyle}`}
                      >
                        <span className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded bg-black/40 border border-white/10 flex items-center justify-center text-[8px] sm:text-[9px] font-black shrink-0">
                          {String.fromCharCode(65 + i)}
                        </span>
                        <span className="text-[9px] sm:text-[10px] md:text-[11px] font-medium flex-1 leading-tight break-words">
                          {opt}
                        </span>
                        {/* Status Icon */}
                        {p1SelectedOpt !== null && !isRoundEvaluated && isSelected && (
                          <span className="text-[8px] sm:text-[9px] px-1 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-bold shrink-0">
                            ✓ Terkunci
                          </span>
                        )}
                        {isRoundEvaluated && isCorrectOpt && (
                          <CheckCircle2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-emerald-300 shrink-0" />
                        )}
                        {isRoundEvaluated && isSelected && !isCorrectOpt && (
                          <XCircle className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-rose-300 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Status Jawaban Pemain 1 */}
                <div className="pt-0.5">
                  {p1SelectedOpt === null && (
                    <p className="text-[8px] sm:text-[10px] text-amber-300 font-medium text-center truncate">
                      ⏱️ Pilih jawaban P1
                    </p>
                  )}
                  {p1SelectedOpt !== null && !isRoundEvaluated && (
                    <p className="text-[8px] sm:text-[10px] text-emerald-300 font-bold text-center animate-pulse truncate">
                      ✓ P1 siap! Tunggu P2...
                    </p>
                  )}
                  {isRoundEvaluated && (
                    <div className="text-center text-[8px] sm:text-[10px] font-bold">
                      {p1SelectedOpt === currentQ.correct ? (
                        <span className="text-emerald-400">✨ Benar! Lari +10m</span>
                      ) : (
                        <span className="text-rose-400">❌ Kurang Tepat! Lari +2m</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* ===================== KOLOM SOAL PEMAIN 2 ===================== */}
            <div className="flex flex-col rounded-xl bg-slate-900/90 border border-purple-500/40 p-1.5 sm:p-2.5 md:p-3 shadow-md space-y-1.5 sm:space-y-2.5">
              {/* Header Kolom Pemain 2 */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div className="flex items-center gap-1 sm:gap-1.5">
                  <span className="text-sm sm:text-base">🏃‍♀️</span>
                  <div className="min-w-0">
                    <h3 className="font-black text-[10px] sm:text-xs md:text-sm text-purple-400 leading-tight truncate">
                      Pemain 2 (Pelari Ungu)
                    </h3>
                    <p className="text-[9px] sm:text-[10px] text-slate-400 font-medium">
                      Skor: <span className="text-white font-bold">{p2Score}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {isP2Leading && (
                    <span className="text-[8px] sm:text-[9px] px-1 sm:px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold border border-purple-500/30 whitespace-nowrap">
                      🔥 Unggul
                    </span>
                  )}
                  {isDraw && (
                    <span className="text-[8px] sm:text-[9px] px-1 sm:px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-bold whitespace-nowrap">
                      🤝 Seri
                    </span>
                  )}
                  <span className="text-[8px] sm:text-[10px] font-mono font-bold text-purple-300 bg-purple-950/80 px-1.5 py-0.5 rounded border border-purple-800 whitespace-nowrap">
                    {p2Distance}m/100m
                  </span>
                </div>
              </div>

              {/* LINTASAN BALAPAN LARI PEMAIN 2 (DI ATAS KOTAK SOAL) */}
              <div className="p-1 sm:p-2 rounded-lg bg-slate-950 border border-purple-600/40 shadow-inner">
                <div className="flex items-center justify-between text-[8px] sm:text-[9px] font-bold text-slate-400 mb-0.5 sm:mb-1">
                  <span className="text-purple-400">🏁 Start (0m)</span>
                  <span className="text-amber-400 font-mono flex items-center gap-0.5">
                    <Flag className="w-2.5 h-2.5 text-amber-400" />
                    Finis (100m)
                  </span>
                </div>
                {/* Track Bar Lari Pemain 2 */}
                <div className="w-full bg-slate-900 h-5 sm:h-7 rounded-md border border-slate-800 relative overflow-hidden flex items-center px-1">
                  {/* Garis Finis Kotak-kotak */}
                  <div className="absolute right-0 top-0 bottom-0 w-2.5 sm:w-3 bg-[repeating-linear-gradient(45deg,#fff,#fff_2px,#000_2px,#000_4px)] opacity-20 pointer-events-none" />
                  {/* Orang Lari Pemain 2 */}
                  <div
                    className="h-3.5 sm:h-5 rounded bg-gradient-to-r from-purple-600 via-fuchsia-400 to-pink-300 transition-all duration-500 ease-out flex items-center justify-end pr-0.5 sm:pr-1 shadow-md shadow-purple-500/40"
                    style={{ width: `${Math.max(12, p2Distance)}%` }}
                  >
                    <span className="text-[11px] sm:text-xs drop-shadow transform scale-x-[-1]">🏃‍♀️</span>
                  </div>
                </div>
              </div>

              {/* KOTAK SOAL PEMAIN 2 */}
              <div className="flex-1 flex flex-col justify-between p-1.5 sm:p-2.5 rounded-xl bg-slate-950/90 border border-purple-900/60 space-y-1.5 sm:space-y-2">
                <div>
                  <div className="flex items-center justify-between text-[8px] sm:text-[9px] text-slate-400 mb-0.5 sm:mb-1">
                    <span className="font-extrabold text-purple-400 uppercase tracking-wider">
                      Soal Pemain 2
                    </span>
                    <span className="px-1 sm:px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 font-mono font-bold text-slate-300 text-[8px] sm:text-[9px]">
                      Ronde {currentIdx + 1}/10
                    </span>
                  </div>
                  <h4 className="text-[10px] sm:text-[11px] md:text-xs font-bold text-white leading-snug line-clamp-4">
                    {currentQ.question}
                  </h4>
                </div>

                {/* 4 Opsi Pilihan Pemain 2 */}
                <div className="grid grid-cols-1 gap-1 sm:gap-1.5 pt-0.5">
                  {currentQ.options.map((opt, i) => {
                    const isSelected = p2SelectedOpt === i;
                    const isCorrectOpt = i === currentQ.correct;

                    let btnStyle = 'bg-slate-900/90 hover:bg-slate-800 border-slate-800 text-slate-200 cursor-pointer';

                    if (p2SelectedOpt !== null && !isRoundEvaluated) {
                      // Jawaban tersimpan tetapi menunggu Pemain 1
                      if (isSelected) {
                        btnStyle = 'bg-purple-800/80 border-purple-400 text-white font-bold ring-1 ring-purple-400/60';
                      } else {
                        btnStyle = 'bg-slate-900/40 border-slate-800/50 text-slate-500 opacity-60';
                      }
                    } else if (isRoundEvaluated) {
                      // Hasil sudah dievaluasi untuk kedua pemain
                      if (isCorrectOpt) {
                        btnStyle = 'bg-emerald-600/90 border-emerald-400 text-white font-bold ring-2 ring-emerald-400/50 shadow-md';
                      } else if (isSelected) {
                        btnStyle = 'bg-rose-600/90 border-rose-400 text-white font-bold ring-1 ring-rose-400/50';
                      } else {
                        btnStyle = 'bg-slate-900/30 border-slate-800/50 text-slate-500 opacity-40';
                      }
                    }

                    return (
                      <button
                        key={i}
                        type="button"
                        disabled={p2SelectedOpt !== null}
                        onClick={() => handleP2Select(i)}
                        className={`w-full py-1 sm:py-1.5 px-1.5 sm:px-2.5 rounded-lg border text-left transition-all flex items-center gap-1 sm:gap-1.5 active:scale-98 ${btnStyle}`}
                      >
                        <span className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded bg-black/40 border border-white/10 flex items-center justify-center text-[8px] sm:text-[9px] font-black shrink-0">
                          {String.fromCharCode(65 + i)}
                        </span>
                        <span className="text-[9px] sm:text-[10px] md:text-[11px] font-medium flex-1 leading-tight break-words">
                          {opt}
                        </span>
                        {/* Status Icon */}
                        {p2SelectedOpt !== null && !isRoundEvaluated && isSelected && (
                          <span className="text-[8px] sm:text-[9px] px-1 py-0.2 rounded bg-purple-500/20 text-purple-300 font-bold shrink-0">
                            ✓ Terkunci
                          </span>
                        )}
                        {isRoundEvaluated && isCorrectOpt && (
                          <CheckCircle2 className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-emerald-300 shrink-0" />
                        )}
                        {isRoundEvaluated && isSelected && !isCorrectOpt && (
                          <XCircle className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-rose-300 shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Status Jawaban Pemain 2 */}
                <div className="pt-0.5">
                  {p2SelectedOpt === null && (
                    <p className="text-[8px] sm:text-[10px] text-amber-300 font-medium text-center truncate">
                      ⏱️ Pilih jawaban P2
                    </p>
                  )}
                  {p2SelectedOpt !== null && !isRoundEvaluated && (
                    <p className="text-[8px] sm:text-[10px] text-purple-300 font-bold text-center animate-pulse truncate">
                      ✓ P2 siap! Tunggu P1...
                    </p>
                  )}
                  {isRoundEvaluated && (
                    <div className="text-center text-[8px] sm:text-[10px] font-bold">
                      {p2SelectedOpt === currentQ.correct ? (
                        <span className="text-emerald-400">✨ Benar! Lari +10m</span>
                      ) : (
                        <span className="text-rose-400">❌ Kurang Tepat! Lari +2m</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 3. Panel Pembahasan & Tombol Lanjut Ronde (Muncul setelah kedua pemain menjawab) */}
          {isRoundEvaluated && (
            <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/95 border border-emerald-800/80 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-2.5 animate-in fade-in duration-200">
              <p className="text-[10px] sm:text-xs text-slate-300 leading-relaxed flex-1">
                <span className="font-bold text-teal-400">💡 Pembahasan Konsep: </span>
                {currentQ.explanation}
              </p>
              <button
                type="button"
                onClick={handleNextRound}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer shrink-0 active:scale-95"
              >
                <span>
                  {currentIdx + 1 < RACE_QUESTIONS.length
                    ? `Lanjut ke Ronde ${currentIdx + 2} →`
                    : 'Lihat Hasil Akhir Balapan 🏆'}
                </span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

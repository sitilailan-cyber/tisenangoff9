import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Trophy,
  RotateCcw,
  ArrowRight,
  ArrowLeft,
  ArrowUp,
  ArrowDown,
  CheckCircle2,
  XCircle,
  Compass,
  AlertTriangle,
  X,
  Sparkles,
  Flame,
  Flag,
  Lock,
  Unlock,
  Volume2,
  VolumeX,
  Pause,
  Play,
  Heart,
  HelpCircle,
  Shield,
  Zap,
} from 'lucide-react';
import { joyfulGameMusic } from '../../../services/audio/joyfulGameMusic';

interface FisikaLabirinKalorProps {
  onFinishGame: (score: number) => void;
  onBackToGameList?: () => void;
  onClose?: () => void;
}

interface MazeQuestion {
  id: number;
  topic: string;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
}

const LABIRIN_QUESTIONS: MazeQuestion[] = [
  {
    id: 1,
    topic: 'Pengertian Kalor',
    question:
      'Kalor adalah energi yang berpindah dari benda bersuhu tinggi ke benda bersuhu rendah karena adanya perbedaan ....',
    options: ['massa', 'suhu', 'volume', 'bentuk', 'warna'],
    correct: 1, // B
    explanation: 'Kalor berpindah karena adanya perbedaan suhu.',
  },
  {
    id: 2,
    topic: 'Perpindahan Kalor',
    question:
      'Ketika sendok logam dimasukkan ke dalam teh panas, gagang sendok lama-kelamaan terasa panas. Perpindahan kalor tersebut terjadi secara ....',
    options: ['konduksi', 'konveksi', 'radiasi', 'evaporasi', 'sublimasi'],
    correct: 0, // A
    explanation:
      'Konduksi adalah perpindahan kalor melalui zat tanpa perpindahan keseluruhan zat.',
  },
  {
    id: 3,
    topic: 'Penerapan Kalor dalam Kehidupan',
    question:
      'Pakaian basah yang dijemur di bawah sinar matahari menjadi kering karena air mengalami ....',
    options: ['pembekuan', 'pengembunan', 'penguapan', 'pencairan', 'penyubliman'],
    correct: 2, // C
    explanation: 'Air pada pakaian berubah menjadi uap melalui penguapan.',
  },
  {
    id: 4,
    topic: 'Perubahan Wujud',
    question:
      'Es batu yang dibiarkan di dalam ruangan berubah menjadi air. Perubahan wujud tersebut disebut ....',
    options: ['menguap', 'membeku', 'mengembun', 'mencair', 'menyublim'],
    correct: 3, // D
    explanation: 'Mencair adalah perubahan wujud dari padat menjadi cair.',
  },
  {
    id: 5,
    topic: 'Kalor dan Perubahan Suhu',
    question:
      'Ketika air dipanaskan, suhu air meningkat. Hal ini menunjukkan bahwa kalor yang diterima air dapat ....',
    options: [
      'menurunkan suhu air',
      'menaikkan suhu air',
      'menghilangkan massa air',
      'mengubah air menjadi es',
      'menghentikan gerak partikel air',
    ],
    correct: 1, // B
    explanation: 'Kalor dapat meningkatkan suhu benda.',
  },
  {
    id: 6,
    topic: 'Perhitungan Kalor (1)',
    question:
      'Sebanyak 1 kg air dipanaskan sehingga suhunya naik sebesar 2°C. Jika kalor jenis air adalah 4.200 J/kg°C, kalor yang diperlukan adalah ....',
    options: ['2.100 J', '4.200 J', '6.200 J', '8.400 J', '12.600 J'],
    correct: 3, // D
    explanation: 'Q = m · c · ΔT = 1 × 4.200 × 2 = 8.400 J.',
  },
  {
    id: 7,
    topic: 'Perhitungan Kalor (2)',
    question:
      'Sebanyak 2 kg air dipanaskan dari suhu 20°C menjadi 25°C. Jika kalor jenis air adalah 4.200 J/kg°C, kalor yang diperlukan adalah ....',
    options: ['4.200 J', '8.400 J', '21.000 J', '42.000 J', '84.000 J'],
    correct: 3, // D
    explanation: 'Q = m · c · ΔT = 2 × 4.200 × 5 = 42.000 J.',
  },
  {
    id: 8,
    topic: 'Perhitungan Kalor (3)',
    question:
      'Sebanyak 1 kg es pada suhu 0°C dicairkan seluruhnya menjadi air pada suhu 0°C. Jika kalor lebur es adalah 336.000 J/kg, kalor yang diperlukan adalah ....',
    options: ['33.600 J', '168.000 J', '336.000 J', '420.000 J', '672.000 J'],
    correct: 2, // C
    explanation: 'Q = m · L = 1 × 336.000 = 336.000 J.',
  },
  {
    id: 9,
    topic: 'Kalor saat Perubahan Wujud',
    question:
      'Ketika air mendidih pada suhu 100°C dan terus dipanaskan pada tekanan normal, suhu air tetap selama proses mendidih berlangsung karena kalor digunakan untuk ....',
    options: [
      'menurunkan suhu air',
      'mengubah wujud air menjadi uap',
      'membekukan air',
      'mengurangi energi partikel',
      'mengubah uap menjadi air',
    ],
    correct: 1, // B
    explanation: 'Kalor digunakan untuk mengubah wujud cair menjadi gas.',
  },
  {
    id: 10,
    topic: 'Penerapan Kalor dalam Eksperimen',
    question:
      'Seorang siswa menyinari wadah berisi air menggunakan lampu pemanas. Setelah beberapa saat, suhu air meningkat dan sebagian air menguap. Kesimpulan yang tepat adalah ....',
    options: [
      'kalor hanya dapat menaikkan suhu benda',
      'kalor hanya dapat mengubah wujud benda',
      'kalor dapat menyebabkan perubahan suhu dan wujud',
      'penguapan terjadi tanpa menerima energi',
      'suhu air selalu tetap ketika dipanaskan',
    ],
    correct: 2, // C
    explanation: 'Kalor dapat meningkatkan suhu dan menyebabkan perubahan wujud.',
  },
];

// Peta Grid Labirin 2D Sungguhan: 21 Kolom x 15 Baris
// 0 = Jalur (Dapat dilalui), 1 = Dinding (Tidak dapat ditembus)
const MAZE_COLS = 21;
const MAZE_ROWS = 15;
const CELL_SIZE = 30; // 30px per cell -> SVG viewBox: 630 x 450

const MAZE_GRID: number[][] = [
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
  [1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1],
  [1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1],
  [1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1],
  [1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1],
  [1, 0, 1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1],
  [1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
  [1, 0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1],
  [1, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1],
  [1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1],
  [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1],
  [1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 1],
  [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
];

interface QuestionStation {
  id: number;
  x: number;
  y: number;
  label: string;
}

// 10 Titik Soal yang tersebar di persimpangan dan koridor labirin
const QUESTION_STATIONS: QuestionStation[] = [
  { id: 1, x: 1, y: 7, label: 'Pos 1' },
  { id: 2, x: 3, y: 1, label: 'Pos 2' },
  { id: 3, x: 7, y: 3, label: 'Pos 3' },
  { id: 4, x: 1, y: 13, label: 'Pos 4' },
  { id: 5, x: 5, y: 9, label: 'Pos 5' },
  { id: 6, x: 11, y: 5, label: 'Pos 6' },
  { id: 7, x: 9, y: 13, label: 'Pos 7' },
  { id: 8, x: 15, y: 1, label: 'Pos 8' },
  { id: 9, x: 19, y: 5, label: 'Pos 9' },
  { id: 10, x: 15, y: 11, label: 'Pos 10' },
];

const START_TILE = { x: 1, y: 1 };
const EXIT_TILE = { x: 19, y: 13 };
const FIRE_START_TILE = { x: 19, y: 1 };

// Algoritma BFS Pathfinding agar Api mengejar pion secara alami menyusuri jalur labirin
function getNextFireStep(
  fireX: number,
  fireY: number,
  targetX: number,
  targetY: number
): { x: number; y: number } {
  if (fireX === targetX && fireY === targetY) return { x: fireX, y: fireY };

  const queue: Array<[number, number]> = [[fireX, fireY]];
  const visited = Array.from({ length: MAZE_ROWS }, () => Array(MAZE_COLS).fill(false));
  const parent = Array.from({ length: MAZE_ROWS }, () =>
    Array<[number, number] | null>(MAZE_COLS).fill(null)
  );

  visited[fireY][fireX] = true;
  let found = false;

  while (queue.length > 0) {
    const [cx, cy] = queue.shift()!;
    if (cx === targetX && cy === targetY) {
      found = true;
      break;
    }
    const neighbors: Array<[number, number]> = [
      [cx, cy - 1],
      [cx, cy + 1],
      [cx - 1, cy],
      [cx + 1, cy],
    ];
    for (const [nx, ny] of neighbors) {
      if (
        nx >= 0 &&
        nx < MAZE_COLS &&
        ny >= 0 &&
        ny < MAZE_ROWS &&
        MAZE_GRID[ny][nx] === 0 &&
        !visited[ny][nx]
      ) {
        visited[ny][nx] = true;
        parent[ny][nx] = [cx, cy];
        queue.push([nx, ny]);
      }
    }
  }

  if (!found) return { x: fireX, y: fireY };

  let curr: [number, number] = [targetX, targetY];
  let prev: [number, number] = curr;
  while (curr[0] !== fireX || curr[1] !== fireY) {
    prev = curr;
    const p = parent[curr[1]][curr[0]];
    if (!p) break;
    curr = p;
  }
  return { x: prev[0], y: prev[1] };
}

export const FisikaLabirinKalor: React.FC<FisikaLabirinKalorProps> = ({
  onFinishGame,
  onBackToGameList,
  onClose,
}) => {
  // State Permainan
  const [playerPos, setPlayerPos] = useState<{ x: number; y: number }>({ ...START_TILE });
  const [firePos, setFirePos] = useState<{ x: number; y: number }>({ ...FIRE_START_TILE });
  const [lives, setLives] = useState<number>(3);
  const [score, setScore] = useState<number>(0);
  const [attempts, setAttempts] = useState<number>(0);
  const [solvedStationIds, setSolvedStationIds] = useState<number[]>([]);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(joyfulGameMusic.getIsMuted());
  const [isInvulnerable, setIsInvulnerable] = useState<boolean>(false);
  const [alertNotice, setAlertNotice] = useState<string | null>(null);

  // Modal Soal & Hasil
  const [activeQuestion, setActiveQuestion] = useState<MazeQuestion | null>(null);
  const [activeStationId, setActiveStationId] = useState<number | null>(null);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [wrongOptIndexes, setWrongOptIndexes] = useState<number[]>([]);
  const [isAnswerSubmitted, setIsAnswerSubmitted] = useState<boolean>(false);
  const [isAnswerCorrect, setIsAnswerCorrect] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [isWon, setIsWon] = useState<boolean>(false);

  // Waktu Permainan & Kecepatan Api
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const fireSpeedRef = useRef<number>(750); // Kecepatan awal sedang (750ms per langkah)
  const isMovingRef = useRef<boolean>(false);
  const keyIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Apakah game sedang aktif berjalan (bebas dari pause, modal soal, dan game over)
  const isGameRunning = !isPaused && activeQuestion === null && !isGameOver && !isWon;

  // Sound Music Toggle
  const handleToggleMute = () => {
    const nextMuted = joyfulGameMusic.toggleMute();
    setIsMuted(nextMuted);
  };

  // 1. Timer Permainan
  useEffect(() => {
    if (!isGameRunning) return;
    const timer = setInterval(() => {
      setElapsedSeconds((prev) => {
        const next = prev + 1;
        // Setiap 15 detik, percepat api sedikit (tidak ekstrem, batas minimal 480ms)
        if (next % 15 === 0 && fireSpeedRef.current > 480) {
          fireSpeedRef.current = Math.max(480, fireSpeedRef.current - 20);
        }
        return next;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [isGameRunning]);

  // 2. Loop Pengejaran Api (Hanya saat game aktif dan tidak ada pop-up soal)
  useEffect(() => {
    if (!isGameRunning) return;

    let timeoutId: ReturnType<typeof setTimeout>;

    const stepFire = () => {
      setFirePos((prevFire) => {
        const next = getNextFireStep(prevFire.x, prevFire.y, playerPos.x, playerPos.y);
        return next;
      });

      timeoutId = setTimeout(stepFire, fireSpeedRef.current);
    };

    timeoutId = setTimeout(stepFire, fireSpeedRef.current);
    return () => clearTimeout(timeoutId);
  }, [isGameRunning, playerPos.x, playerPos.y]);

  // 3. Deteksi Tabrakan Api dengan Pion
  useEffect(() => {
    if (!isGameRunning || isInvulnerable) return;

    if (firePos.x === playerPos.x && firePos.y === playerPos.y) {
      joyfulGameMusic.playWrong();
      const nextLives = lives - 1;
      setLives(nextLives);

      if (nextLives <= 0) {
        setIsGameOver(true);
      } else {
        // Terkena api: mundurkan api ke posisi awal agar adil, beri shield sementara
        setIsInvulnerable(true);
        setFirePos({ ...FIRE_START_TILE });
        setAlertNotice('🔥 Tersentuh Api! Nyawa berkurang 1. Segera cari rute aman!');
        setTimeout(() => setAlertNotice(null), 3000);
        setTimeout(() => setIsInvulnerable(false), 2500);
      }
    }
  }, [firePos, playerPos, isGameRunning, isInvulnerable, lives]);

  // 4. Logika Pergerakan Pion (Tidak boleh menembus dinding)
  const movePlayer = useCallback(
    (dx: number, dy: number) => {
      if (!isGameRunning) return;

      setPlayerPos((prev) => {
        const nx = prev.x + dx;
        const ny = prev.y + dy;

        // Cek batas dan dinding
        if (nx < 0 || nx >= MAZE_COLS || ny < 0 || ny >= MAZE_ROWS) return prev;
        if (MAZE_GRID[ny][nx] === 1) return prev; // Menabrak dinding!

        // Cek apakah mencapai stasiun soal yang belum dikerjakan
        const station = QUESTION_STATIONS.find((s) => s.x === nx && s.y === ny);
        if (station && !solvedStationIds.includes(station.id)) {
          // Buka pop-up soal! Ini otomatis mem-pause seluruh game: pion, api, timer
          const q = LABIRIN_QUESTIONS.find((item) => item.id === station.id);
          if (q) {
            setActiveQuestion(q);
            setActiveStationId(station.id);
            setSelectedOpt(null);
            setWrongOptIndexes([]);
            setIsAnswerSubmitted(false);
            setIsAnswerCorrect(false);
          }
        }

        // Cek apakah mencapai EXIT
        if (nx === EXIT_TILE.x && ny === EXIT_TILE.y) {
          if (solvedStationIds.length >= QUESTION_STATIONS.length) {
            setIsWon(true);
            joyfulGameMusic.playVictory();
          } else {
            setAlertNotice(
              `⚠️ Gerbang FINIS masih terkunci! Selesaikan semua 10 soal kalor (${solvedStationIds.length}/10 tuntas).`
            );
            setTimeout(() => setAlertNotice(null), 3500);
          }
        }

        return { x: nx, y: ny };
      });
    },
    [isGameRunning, solvedStationIds]
  );

  // 5. Kontrol Keyboard (Laptop/Desktop: Panah & WASD)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isGameRunning) return;

      const key = e.key.toLowerCase();
      if (['arrowup', 'w'].includes(key)) {
        e.preventDefault();
        movePlayer(0, -1);
      } else if (['arrowdown', 's'].includes(key)) {
        e.preventDefault();
        movePlayer(0, 1);
      } else if (['arrowleft', 'a'].includes(key)) {
        e.preventDefault();
        movePlayer(-1, 0);
      } else if (['arrowright', 'd'].includes(key)) {
        e.preventDefault();
        movePlayer(1, 0);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isGameRunning, movePlayer]);

  // Kontrol Tombol D-Pad Mobile dengan hold berulang
  const startDpadMove = (dx: number, dy: number) => {
    movePlayer(dx, dy);
    if (keyIntervalRef.current) clearInterval(keyIntervalRef.current);
    keyIntervalRef.current = setInterval(() => {
      movePlayer(dx, dy);
    }, 150);
  };

  const stopDpadMove = () => {
    if (keyIntervalRef.current) {
      clearInterval(keyIntervalRef.current);
      keyIntervalRef.current = null;
    }
  };

  // 6. Penanganan Menjawab Soal Fisika di Pop-up
  const handleSelectAnswer = (optIdx: number) => {
    if (isAnswerSubmitted || !activeQuestion) return;
    if (wrongOptIndexes.includes(optIdx)) return; // Pilihan salah yang sudah dicoba

    setSelectedOpt(optIdx);
    setAttempts((prev) => prev + 1);

    const isCorrect = optIdx === activeQuestion.correct;

    if (isCorrect) {
      setIsAnswerCorrect(true);
      setIsAnswerSubmitted(true);
      joyfulGameMusic.playCorrect();
      setScore((prev) => prev + 10);
      if (activeStationId && !solvedStationIds.includes(activeStationId)) {
        setSolvedStationIds((prev) => [...prev, activeStationId]);
      }
    } else {
      // Jawaban salah: JANGAN beri tahu kunci jawaban benar!
      // Catat sebagai opsi salah agar ditandai merah, lalu biarkan pemain mencoba lagi
      setIsAnswerCorrect(false);
      setWrongOptIndexes((prev) => (prev.includes(optIdx) ? prev : [...prev, optIdx]));
      joyfulGameMusic.playWrong();
    }
  };

  // Menutup Pop-up Soal jika siswa belum mampu menjawab (tombol close 'X')
  const handleCloseQuestionModal = () => {
    setActiveQuestion(null);
    setActiveStationId(null);
    setSelectedOpt(null);
    setWrongOptIndexes([]);
    setIsAnswerSubmitted(false);
    setIsAnswerCorrect(false);

    // Beri perlindungan jeda aman 1.2 detik sebelum api kembali aktif mengejar
    setIsInvulnerable(true);
    setTimeout(() => setIsInvulnerable(false), 1200);
  };

  // Menutup Pop-up Soal dan Melanjutkan Permainan setelah berhasil menjawab benar
  const handleResumeGameAfterQuestion = () => {
    setActiveQuestion(null);
    setActiveStationId(null);
    setSelectedOpt(null);
    setWrongOptIndexes([]);
    setIsAnswerSubmitted(false);
    setIsAnswerCorrect(false);

    // Beri perlindungan jeda aman 1.2 detik sebelum api aktif mengejar
    setIsInvulnerable(true);
    setTimeout(() => setIsInvulnerable(false), 1200);
  };

  // Mulai Ulang (Restart Game)
  const handleRestartGame = () => {
    setPlayerPos({ ...START_TILE });
    setFirePos({ ...FIRE_START_TILE });
    setLives(3);
    setScore(0);
    setAttempts(0);
    setSolvedStationIds([]);
    setIsPaused(false);
    setIsInvulnerable(false);
    setAlertNotice(null);
    setActiveQuestion(null);
    setActiveStationId(null);
    setSelectedOpt(null);
    setWrongOptIndexes([]);
    setIsAnswerSubmitted(false);
    setIsAnswerCorrect(false);
    setIsGameOver(false);
    setIsWon(false);
    setElapsedSeconds(0);
    fireSpeedRef.current = 750;
  };

  return (
    <div className="w-full max-w-4xl mx-auto rounded-3xl overflow-hidden shadow-2xl border-2 border-cyan-500/40 bg-[#040817] text-white font-sans select-none flex flex-col">
      {/* 1. TOP HEADER & HUD KONTROL (Dark Futuristic Navy, Cyan & Orange) */}
      <div className="px-3 sm:px-6 py-3 bg-gradient-to-r from-[#07112c] via-[#09173a] to-[#07112c] border-b border-cyan-800/50 flex flex-wrap items-center justify-between gap-2.5">
        <div className="flex items-center gap-2 min-w-0">
          {onBackToGameList && (
            <button
              type="button"
              onClick={onBackToGameList}
              className="px-2.5 py-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-cyan-300 hover:text-white text-xs font-bold transition-all flex items-center gap-1 border border-cyan-900/60 cursor-pointer shrink-0 active:scale-95 shadow-md"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Kembali</span>
            </button>
          )}

          <div className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-950/80 border border-cyan-400/50 text-cyan-300 font-extrabold text-xs shadow-[0_0_15px_rgba(6,182,212,0.2)] truncate">
            <Compass className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow shrink-0" />
            <span className="truncate tracking-wide">Rute Labirin Kalor 2D</span>
          </div>
        </div>

        {/* Stats & HUD Badges */}
        <div className="flex items-center gap-2 text-xs flex-wrap">
          {/* Nyawa Pion (3 Hearts) */}
          <div className="px-2.5 py-1 rounded-xl bg-[#08152e] border border-rose-500/40 text-rose-300 font-bold flex items-center gap-1 shadow-inner">
            <span className="text-[11px] text-slate-300">Nyawa:</span>
            <div className="flex items-center gap-0.5">
              {[1, 2, 3].map((heart) => (
                <Heart
                  key={heart}
                  className={`w-3.5 h-3.5 ${
                    heart <= lives
                      ? 'fill-rose-500 text-rose-500 animate-pulse'
                      : 'fill-transparent text-slate-600'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* Progres Soal */}
          <div className="px-2.5 py-1 rounded-xl bg-[#08152e] border border-cyan-500/40 text-cyan-300 font-bold flex items-center gap-1 shadow-inner">
            <span>🎯</span>
            <span className="text-[11px] text-slate-300 hidden sm:inline">Soal:</span>
            <span className="font-mono text-white font-black">
              {solvedStationIds.length}/10
            </span>
          </div>

          {/* Skor */}
          <div className="px-2.5 py-1 rounded-xl bg-[#08152e] border border-amber-500/40 text-amber-300 font-bold flex items-center gap-1 shadow-inner">
            <span>⭐</span>
            <span className="text-[11px] text-slate-300 hidden sm:inline">Skor:</span>
            <span className="font-mono text-white font-black">{score}</span>
          </div>

          {/* Tombol Suara */}
          <button
            type="button"
            onClick={handleToggleMute}
            className="p-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors cursor-pointer shrink-0"
            title={isMuted ? 'Nyalakan Suara' : 'Bisukan Suara'}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>

          {/* Tombol Jeda (Pause / Resume) */}
          <button
            type="button"
            onClick={() => setIsPaused((prev) => !prev)}
            className="p-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors cursor-pointer shrink-0"
            title={isPaused ? 'Lanjutkan' : 'Jeda Permainan'}
          >
            {isPaused ? <Play className="w-4 h-4 text-emerald-400" /> : <Pause className="w-4 h-4 text-amber-400" />}
          </button>

          {/* Tombol Mulai Ulang */}
          <button
            type="button"
            onClick={handleRestartGame}
            className="p-1.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors cursor-pointer shrink-0"
            title="Mulai Ulang Permainan"
          >
            <RotateCcw className="w-4 h-4 text-orange-400" />
          </button>

          {/* Tombol Tutup */}
          {(onClose || onBackToGameList) && (
            <button
              type="button"
              onClick={onClose || onBackToGameList}
              className="p-1.5 rounded-xl bg-slate-800/90 hover:bg-rose-900/60 hover:text-rose-200 text-slate-300 border border-slate-700 transition-colors cursor-pointer shrink-0"
              title="Tutup Game"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* 2. AREA UTAMA: PETA LABIRIN 2D SUNGGUHAN (Ukuran Besar & Grid Responsif) */}
      <div className="p-2 sm:p-4 bg-gradient-to-b from-[#050b1d] via-[#040816] to-[#030612] relative flex-1 flex flex-col items-center">
        {/* Floating Notification Toast */}
        {alertNotice && (
          <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 px-4 py-2 rounded-2xl bg-slate-900/95 border-2 border-orange-500 text-orange-200 text-xs font-bold shadow-2xl flex items-center gap-2 animate-bounce max-w-[90%] text-center">
            <AlertTriangle className="w-4 h-4 text-orange-400 shrink-0" />
            <span>{alertNotice}</span>
          </div>
        )}

        {/* Overlay saat Jeda (Paused) */}
        {isPaused && (
          <div className="absolute inset-0 z-20 bg-black/80 backdrop-blur-xs flex flex-col items-center justify-center gap-3 p-4">
            <div className="p-3 rounded-full bg-cyan-950 border border-cyan-400/50 shadow-[0_0_20px_#06b6d4]">
              <Pause className="w-8 h-8 text-cyan-400" />
            </div>
            <h3 className="text-lg font-black text-white">PERMAINAN DIJEDA</h3>
            <p className="text-xs text-slate-300 text-center max-w-xs">
              Seluruh pergerakan pion, api pengejar, dan timer sedang berhenti.
            </p>
            <button
              type="button"
              onClick={() => setIsPaused(false)}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs shadow-lg transition-all flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Lanjutkan Permainan</span>
            </button>
          </div>
        )}

        {/* Info Legend Bar */}
        <div className="w-full flex items-center justify-between text-xs text-slate-400 mb-2 px-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold text-cyan-300 flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee] inline-block" />
              Jelajahi labirin & hindari api pengejar 🔥
            </span>
          </div>
          <div className="flex items-center gap-3 text-[11px] font-medium hidden sm:flex">
            <span className="flex items-center gap-1 text-sky-300">🕵️‍♀️ Pion Kamu</span>
            <span className="flex items-center gap-1 text-orange-400">🔥 Api Pengejar</span>
            <span className="flex items-center gap-1 text-amber-300">❓ Stasiun Soal</span>
            <span className="flex items-center gap-1 text-emerald-400">🏁 Pintu EXIT</span>
          </div>
        </div>

        {/* SVG Container: Peta Labirin 2D Ukuran Besar Responsif */}
        <div className="relative w-full rounded-2xl overflow-hidden border-2 border-cyan-500/40 bg-[#02050e] shadow-[0_0_35px_rgba(6,182,212,0.18)] max-h-[380px] sm:max-h-[440px] md:max-h-[480px]">
          <svg
            viewBox={`0 0 ${MAZE_COLS * CELL_SIZE} ${MAZE_ROWS * CELL_SIZE}`}
            className="w-full h-auto select-none block"
            style={{ touchAction: 'manipulation' }}
          >
            <defs>
              {/* Pattern Grid Koridor Cyber */}
              <pattern id="mazeFloorPattern" width="15" height="15" patternUnits="userSpaceOnUse">
                <path d="M 15 0 L 0 0 0 15" fill="none" stroke="rgba(6, 182, 212, 0.08)" strokeWidth="0.8" />
              </pattern>

              {/* Gradient Dinding Logam Cyber */}
              <linearGradient id="cyberWallGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0e1f3d" />
                <stop offset="50%" stopColor="#0a162d" />
                <stop offset="100%" stopColor="#050b18" />
              </linearGradient>

              {/* Glow Filters */}
              <filter id="pawnGlowFilter" x="-40%" y="-40%" width="180%" height="180%">
                <feDropShadow dx="0" dy="0" stdDeviation="4" floodColor="#38bdf8" floodOpacity="0.9" />
              </filter>
              <filter id="fireGlowFilter" x="-40%" y="-40%" width="180%" height="180%">
                <feDropShadow dx="0" dy="0" stdDeviation="5" floodColor="#f97316" floodOpacity="0.95" />
              </filter>
              <filter id="portalGlowFilter" x="-40%" y="-40%" width="180%" height="180%">
                <feDropShadow dx="0" dy="0" stdDeviation="6" floodColor="#22d3ee" floodOpacity="0.9" />
              </filter>
            </defs>

            {/* Base Background Koridor */}
            <rect
              x="0"
              y="0"
              width={MAZE_COLS * CELL_SIZE}
              height={MAZE_ROWS * CELL_SIZE}
              fill="#030816"
            />
            <rect
              x="0"
              y="0"
              width={MAZE_COLS * CELL_SIZE}
              height={MAZE_ROWS * CELL_SIZE}
              fill="url(#mazeFloorPattern)"
            />

            {/* Render Dinding-Dinding Labirin (Grid Cell = 1) */}
            {MAZE_GRID.map((row, y) =>
              row.map((cell, x) => {
                if (cell === 1) {
                  return (
                    <g key={`wall-${x}-${y}`}>
                      <rect
                        x={x * CELL_SIZE}
                        y={y * CELL_SIZE}
                        width={CELL_SIZE}
                        height={CELL_SIZE}
                        fill="url(#cyberWallGrad)"
                        stroke="#133e5c"
                        strokeWidth="1"
                      />
                      {/* Bevel highlight atas & kiri dinding */}
                      <line
                        x1={x * CELL_SIZE}
                        y1={y * CELL_SIZE}
                        x2={(x + 1) * CELL_SIZE}
                        y2={y * CELL_SIZE}
                        stroke="rgba(6, 182, 212, 0.25)"
                        strokeWidth="1"
                      />
                      <line
                        x1={x * CELL_SIZE}
                        y1={y * CELL_SIZE}
                        x2={x * CELL_SIZE}
                        y2={(y + 1) * CELL_SIZE}
                        stroke="rgba(6, 182, 212, 0.25)"
                        strokeWidth="1"
                      />
                    </g>
                  );
                }
                return null;
              })
            )}

            {/* TITIK START (1, 1) */}
            <g transform={`translate(${START_TILE.x * CELL_SIZE + CELL_SIZE / 2}, ${START_TILE.y * CELL_SIZE + CELL_SIZE / 2})`}>
              <circle r="12" fill="#042f2e" stroke="#10b981" strokeWidth="1.8" />
              <text y="3.5" textAnchor="middle" fontSize="10" fill="#6ee7b7" fontWeight="bold">
                S
              </text>
            </g>

            {/* TITIK EXIT (19, 13) */}
            <g
              transform={`translate(${EXIT_TILE.x * CELL_SIZE + CELL_SIZE / 2}, ${EXIT_TILE.y * CELL_SIZE + CELL_SIZE / 2})`}
              filter={solvedStationIds.length >= QUESTION_STATIONS.length ? 'url(#portalGlowFilter)' : undefined}
            >
              <circle
                r="13"
                fill={solvedStationIds.length >= QUESTION_STATIONS.length ? '#854d0e' : '#1e1b4b'}
                stroke={solvedStationIds.length >= QUESTION_STATIONS.length ? '#fbbf24' : '#6366f1'}
                strokeWidth="2.2"
              />
              <text y="4" textAnchor="middle" fontSize="11">
                {solvedStationIds.length >= QUESTION_STATIONS.length ? '🏁' : '🔒'}
              </text>
            </g>

            {/* 10 TITIK STASIUN SOAL TERSEBAR DI LABIRIN */}
            {QUESTION_STATIONS.map((st) => {
              const isSolved = solvedStationIds.includes(st.id);
              const cx = st.x * CELL_SIZE + CELL_SIZE / 2;
              const cy = st.y * CELL_SIZE + CELL_SIZE / 2;

              return (
                <g key={`st-${st.id}`} transform={`translate(${cx}, ${cy})`}>
                  {/* Aura denyut untuk soal yang belum diselesaikan */}
                  {!isSolved && (
                    <circle
                      r="12"
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="1.2"
                      opacity="0.6"
                      className="animate-ping"
                    />
                  )}
                  {/* Base Circle */}
                  <circle
                    r="10.5"
                    fill={isSolved ? '#064e3b' : '#082f49'}
                    stroke={isSolved ? '#10b981' : '#06b6d4'}
                    strokeWidth="1.8"
                  />
                  {/* Icon */}
                  <text
                    y="3.5"
                    textAnchor="middle"
                    fontSize={isSolved ? '9' : '10'}
                    fill={isSolved ? '#a7f3d0' : '#e0f2fe'}
                    fontWeight="bold"
                  >
                    {isSolved ? '✓' : '?'}
                  </text>
                </g>
              );
            })}

            {/* API PENGEJAR (CHASER FIRE) */}
            <g
              transform={`translate(${firePos.x * CELL_SIZE + CELL_SIZE / 2}, ${firePos.y * CELL_SIZE + CELL_SIZE / 2})`}
              filter="url(#fireGlowFilter)"
              style={{ transition: `transform ${fireSpeedRef.current}ms linear` }}
            >
              {/* Gelombang Aura Panas */}
              <circle r="15" fill="none" stroke="#f97316" strokeWidth="1.5" opacity="0.4" className="animate-ping" />
              {/* Bola Api */}
              <circle r="12" fill="#7c2d12" stroke="#ea580c" strokeWidth="2" />
              <circle r="6" fill="#f97316" />
              <text y="4" textAnchor="middle" fontSize="12">🔥</text>
            </g>

            {/* PION PEMAIN (PLAYER PAWN) */}
            <g
              transform={`translate(${playerPos.x * CELL_SIZE + CELL_SIZE / 2}, ${playerPos.y * CELL_SIZE + CELL_SIZE / 2})`}
              filter="url(#pawnGlowFilter)"
              style={{ transition: 'transform 120ms ease-out' }}
            >
              {/* Shield aura jika sedang kebal */}
              {isInvulnerable ? (
                <circle
                  r="16"
                  fill="none"
                  stroke="#fbbf24"
                  strokeWidth="2.5"
                  strokeDasharray="4 3"
                  className="animate-spin"
                />
              ) : (
                <circle r="14" fill="none" stroke="#38bdf8" strokeWidth="1.2" opacity="0.5" className="animate-pulse" />
              )}
              {/* Badan Kapsul Pion */}
              <circle r="11" fill="#0284c7" stroke="#38bdf8" strokeWidth="2.2" />
              <circle r="5.5" fill="#e0f2fe" />
              <text y="3.5" textAnchor="middle" fontSize="10">🕵️‍♀️</text>
            </g>
          </svg>
        </div>

        {/* 3. KONTROL D-PAD VIRTUAL UNTUK HP / TABLET & HINT LAPTOP */}
        <div className="w-full mt-3 flex flex-col sm:flex-row items-center justify-between gap-3 px-2">
          {/* Petunjuk Kontrol Keyboard untuk Laptop */}
          <div className="hidden sm:flex items-center gap-2 text-[11px] text-slate-400 bg-slate-900/80 px-3 py-2 rounded-xl border border-slate-800">
            <span className="font-bold text-cyan-300">Kontrol Laptop:</span>
            <span>Gunakan tombol panah</span>
            <kbd className="px-1.5 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-[10px] text-white font-mono">↑</kbd>
            <kbd className="px-1.5 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-[10px] text-white font-mono">↓</kbd>
            <kbd className="px-1.5 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-[10px] text-white font-mono">←</kbd>
            <kbd className="px-1.5 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-[10px] text-white font-mono">→</kbd>
            <span>atau</span>
            <kbd className="px-1.5 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-[10px] text-white font-mono">W A S D</kbd>
          </div>

          {/* D-Pad Sentuh (Sangat Nyaman di Layar Sentuh HP & Tablet) */}
          <div className="w-full sm:w-auto flex items-center justify-center">
            <div className="relative w-36 h-36 bg-slate-900/90 rounded-full border-2 border-cyan-500/40 p-2 shadow-xl flex items-center justify-center">
              {/* Tombol Atas */}
              <button
                type="button"
                onPointerDown={() => startDpadMove(0, -1)}
                onPointerUp={stopDpadMove}
                onPointerLeave={stopDpadMove}
                className="absolute top-1.5 left-1/2 -translate-x-1/2 w-11 h-10 rounded-t-xl bg-cyan-950 hover:bg-cyan-800 active:bg-cyan-600 text-cyan-300 border border-cyan-500/50 flex items-center justify-center shadow-md active:scale-90 cursor-pointer touch-none"
                aria-label="Atas"
              >
                <ArrowUp className="w-5 h-5" />
              </button>

              {/* Tombol Bawah */}
              <button
                type="button"
                onPointerDown={() => startDpadMove(0, 1)}
                onPointerUp={stopDpadMove}
                onPointerLeave={stopDpadMove}
                className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-11 h-10 rounded-b-xl bg-cyan-950 hover:bg-cyan-800 active:bg-cyan-600 text-cyan-300 border border-cyan-500/50 flex items-center justify-center shadow-md active:scale-90 cursor-pointer touch-none"
                aria-label="Bawah"
              >
                <ArrowDown className="w-5 h-5" />
              </button>

              {/* Tombol Kiri */}
              <button
                type="button"
                onPointerDown={() => startDpadMove(-1, 0)}
                onPointerUp={stopDpadMove}
                onPointerLeave={stopDpadMove}
                className="absolute left-1.5 top-1/2 -translate-y-1/2 w-10 h-11 rounded-l-xl bg-cyan-950 hover:bg-cyan-800 active:bg-cyan-600 text-cyan-300 border border-cyan-500/50 flex items-center justify-center shadow-md active:scale-90 cursor-pointer touch-none"
                aria-label="Kiri"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>

              {/* Tombol Kanan */}
              <button
                type="button"
                onPointerDown={() => startDpadMove(1, 0)}
                onPointerUp={stopDpadMove}
                onPointerLeave={stopDpadMove}
                className="absolute right-1.5 top-1/2 -translate-y-1/2 w-10 h-11 rounded-r-xl bg-cyan-950 hover:bg-cyan-800 active:bg-cyan-600 text-cyan-300 border border-cyan-500/50 flex items-center justify-center shadow-md active:scale-90 cursor-pointer touch-none"
                aria-label="Kanan"
              >
                <ArrowRight className="w-5 h-5" />
              </button>

              {/* Center Pivot Indicator */}
              <div className="w-7 h-7 rounded-full bg-slate-950 border border-cyan-400/30 flex items-center justify-center text-[10px] text-cyan-400 font-bold">
                🎮
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. MODAL POP-UP SOAL FISIKA (Ketika Pion Menyentuh Ikon Soal) */}
      {/* SELAMA MODAL DIBUKA: SELURUH GAME (PION, API, TIMER) TERHENTI TOTAL */}
      {activeQuestion && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5 animate-in fade-in duration-200">
          <div className="w-full max-w-lg rounded-3xl bg-[#09152e] border-2 border-cyan-400/60 p-4 sm:p-6 shadow-[0_0_50px_rgba(6,182,212,0.3)] space-y-4 max-h-[90vh] overflow-y-auto relative">
            {/* Header Pop-up Soal + Tombol Tutup (Close) */}
            <div className="flex items-center justify-between border-b border-cyan-900/60 pb-3">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-orange-500/20 border border-orange-500/40 text-orange-400 font-black text-xs uppercase tracking-wider">
                  {activeQuestion.topic}
                </span>
                <span className="text-white font-bold text-sm">
                  Soal #{activeQuestion.id}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-md bg-cyan-950 border border-cyan-500/40 text-cyan-300 text-[11px] font-bold hidden sm:inline">
                  Game Terhenti
                </span>
                {/* Tombol Close Pop-up jika siswa belum mampu menjawab */}
                <button
                  type="button"
                  onClick={handleCloseQuestionModal}
                  className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-rose-900/60 text-slate-300 hover:text-rose-200 border border-slate-700 hover:border-rose-500/60 transition-colors cursor-pointer"
                  title="Tutup soal dan kembali menjelajah"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Kotak Pertanyaan Fisika */}
            <div className="p-3.5 sm:p-4 rounded-2xl bg-[#050c1c] border border-cyan-900/70">
              <h3 className="text-xs sm:text-sm font-bold text-white leading-relaxed">
                {activeQuestion.question}
              </h3>
            </div>

            {/* Peringatan jika jawaban salah: biarkan mencoba kembali tanpa memberitahu jawaban benar */}
            {!isAnswerCorrect && wrongOptIndexes.length > 0 && (
              <div className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-500/50 text-rose-200 text-xs flex items-center justify-between gap-2 animate-shake">
                <div className="flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span className="font-semibold">Jawaban salah! Silakan coba pilih jawaban lain.</span>
                </div>
                <button
                  type="button"
                  onClick={handleCloseQuestionModal}
                  className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-bold border border-slate-600 cursor-pointer shrink-0"
                >
                  Tutup Soal
                </button>
              </div>
            )}

            {/* Pilihan Jawaban Pilihan Ganda (A s.d E) */}
            <div className="space-y-2 pt-1">
              {activeQuestion.options.map((opt, i) => {
                const isSelected = selectedOpt === i;
                const isWrong = wrongOptIndexes.includes(i);
                const isCorrectOpt = isAnswerCorrect && i === activeQuestion.correct;

                let btnClass =
                  'bg-[#07132a] hover:bg-[#0c1f44] border-slate-800 text-slate-200 hover:border-cyan-500/50';

                if (isCorrectOpt) {
                  btnClass =
                    'bg-emerald-950/80 border-emerald-400 text-emerald-100 font-bold ring-2 ring-emerald-400/40 shadow-[0_0_15px_rgba(16,185,129,0.25)]';
                } else if (isWrong) {
                  btnClass =
                    'bg-rose-950/80 border-rose-500/80 text-rose-300 ring-1 ring-rose-500/40 opacity-80';
                }

                return (
                  <button
                    key={i}
                    type="button"
                    disabled={isAnswerCorrect || isWrong}
                    onClick={() => handleSelectAnswer(i)}
                    className={`w-full py-2.5 px-3 rounded-xl border transition-all flex items-center gap-3 text-left cursor-pointer active:scale-98 ${btnClass}`}
                  >
                    <span className="w-6 h-6 rounded-lg bg-black/60 border border-white/10 flex items-center justify-center text-[11px] font-black shrink-0 text-cyan-300">
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className="text-xs sm:text-sm font-medium flex-1 leading-snug">
                      {opt}
                    </span>
                    {isCorrectOpt && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    )}
                    {isWrong && (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Umpan Balik & Tombol Lanjutkan (HANYA MUNCUL KETIKA SUDAH BENAR) */}
            {isAnswerCorrect && (
              <div className="p-3.5 rounded-xl border flex flex-col gap-2.5 animate-in fade-in duration-200 bg-emerald-950/40 border-emerald-500/50 text-emerald-200">
                <div className="flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div className="text-xs leading-relaxed">
                    <span className="font-black mr-1">🎉 Benar Sekali! (+10 Poin)</span>
                    <span className="text-slate-300">{activeQuestion.explanation}</span>
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    onClick={handleResumeGameAfterQuestion}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-xs sm:text-sm shadow-xl flex items-center gap-2 cursor-pointer active:scale-95 transition-all"
                  >
                    <span>Lanjutkan Penjelajahan</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 5. MODAL GAME OVER (KALAH KARENA TERSENTUH API HABIS NYAWA) */}
      {isGameOver && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#091124] border-2 border-rose-500/70 p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-rose-950/80 border border-rose-500/50 flex items-center justify-center text-3xl shadow-[0_0_20px_#f43f5e]">
              🔥
            </div>
            <div>
              <h2 className="text-xl font-black text-rose-300">Pion Tertangkap Api!</h2>
              <p className="text-xs text-slate-300 mt-1">
                Seluruh nyawa telah habis. Jangan menyerah, atur strategi dan hindari jalur sempit yang diintai api!
              </p>
            </div>

            <div className="flex items-center justify-center gap-4 py-1 text-xs">
              <div className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-400 block text-[10px]">Soal Tuntas</span>
                <span className="font-bold text-cyan-300">{solvedStationIds.length}/10</span>
              </div>
              <div className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-400 block text-[10px]">Total Skor</span>
                <span className="font-bold text-amber-300">{score}</span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleRestartGame}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center gap-2 cursor-pointer active:scale-95"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Mulai Ulang</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 6. MODAL MENANG (SELESAIKAN SOAL & CAPAI EXIT) */}
      {isWon && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-3xl bg-[#09152e] border-2 border-amber-400/70 p-6 shadow-2xl text-center space-y-4">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-950/80 border border-amber-500/50 flex items-center justify-center text-3xl shadow-[0_0_25px_#f59e0b]">
              🏆
            </div>
            <div>
              <h2 className="text-xl font-black text-amber-300">Selamat! Berhasil Lolos dari Labirin!</h2>
              <p className="text-xs text-slate-300 mt-1">
                Kamu berhasil menyelesaikan seluruh soal suhu dan kalor serta mencapai pintu EXIT dengan selamat!
              </p>
            </div>

            <div className="flex items-center justify-center gap-4 py-1 text-xs">
              <div className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-400 block text-[10px]">Total Skor</span>
                <span className="font-bold text-amber-300 font-mono text-base">{score} Poin</span>
              </div>
              <div className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-400 block text-[10px]">Sisa Nyawa</span>
                <span className="font-bold text-rose-400 font-mono text-base">{lives} ❤️</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={handleRestartGame}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs border border-slate-700 flex items-center gap-1.5 cursor-pointer active:scale-95"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Main Lagi</span>
              </button>
              <button
                type="button"
                onClick={() => onFinishGame(score)}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 hover:from-orange-400 hover:to-yellow-400 text-slate-950 font-black text-xs shadow-lg flex items-center gap-2 cursor-pointer active:scale-95 transition-all"
              >
                <Trophy className="w-4 h-4" />
                <span>Selesaikan Misi & Lanjut Misi 5</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

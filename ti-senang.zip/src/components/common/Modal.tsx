import React, { useEffect } from 'react';
import { X } from 'lucide-react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl' | '5xl' | '6xl';
  headerStyle?: React.CSSProperties;
  bodyStyle?: React.CSSProperties;
}

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  children,
  maxWidth = 'md',
  headerStyle,
  bodyStyle,
}) => {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const maxWidthClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    '2xl': 'max-w-2xl',
    '3xl': 'max-w-3xl',
    '4xl': 'max-w-4xl',
    '5xl': 'max-w-5xl',
    '6xl': 'max-w-6xl',
  }[maxWidth] || 'max-w-md';

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
    >
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      />

      {/* Modal Card with semi-transparent container & backdrop blur */}
      <div
        className={`relative w-full ${maxWidthClasses} rounded-2xl shadow-2xl border border-white/40 overflow-hidden z-10 my-8 backdrop-blur-md`}
        onClick={(e) => e.stopPropagation()}
      >
        {title ? (
          <div
            style={{ backgroundColor: 'rgba(49, 65, 244, 0.85)', ...headerStyle }}
            className="flex items-center justify-between px-6 py-4 border-b border-white/25"
          >
            <div>
              <h3 className="text-base font-bold font-display text-white leading-snug">
                {title}
              </h3>
              {subtitle && (
                <p className="text-xs text-blue-100 mt-0.5">
                  {subtitle}
                </p>
              )}
            </div>
            <button
              onClick={onClose}
              className="p-2 -mr-2 text-white/80 hover:text-white rounded-lg hover:bg-white/15 transition-colors cursor-pointer"
              aria-label="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        ) : (
          <button
            onClick={onClose}
            className="absolute top-3.5 right-3.5 p-1.5 text-slate-800 hover:text-slate-950 rounded-full bg-white/40 hover:bg-white/70 border border-white/50 transition-colors z-20 cursor-pointer shadow-xs"
            aria-label="Tutup"
          >
            <X className="w-4 h-4" />
          </button>
        )}

        <div
          style={{ backgroundColor: 'rgba(61, 170, 233, 0.85)', ...bodyStyle }}
          className={`p-6 sm:p-7 ${!title ? 'pt-10 sm:pt-10' : ''}`}
        >
          {children}
        </div>
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { Download, FileDown, FileSpreadsheet, ChevronDown } from 'lucide-react';

interface ExportDropdownProps {
  onExportPdf: () => void;
  onExportExcel: () => void;
  label?: string;
  className?: string;
  buttonClassName?: string;
  align?: 'left' | 'right';
  theme?: 'dark' | 'light' | 'emerald';
}

export const ExportDropdown: React.FC<ExportDropdownProps> = ({
  onExportPdf,
  onExportExcel,
  label = 'Unduh',
  className = '',
  buttonClassName = '',
  align = 'right',
  theme = 'light',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getButtonStyles = () => {
    if (buttonClassName) return buttonClassName;
    switch (theme) {
      case 'dark':
        return 'bg-white/20 hover:bg-white/30 text-white border border-white/30';
      case 'emerald':
        return 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm';
      case 'light':
      default:
        return 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 shadow-2xs';
    }
  };

  return (
    <div ref={dropdownRef} className={`relative inline-block text-left ${className}`}>
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer select-none active:scale-95 ${getButtonStyles()}`}
        aria-haspopup="true"
        aria-expanded={isOpen}
      >
        <Download className="w-3.5 h-3.5 shrink-0" />
        <span>{label}</span>
        <ChevronDown
          className={`w-3 h-3 shrink-0 transition-transform duration-200 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {isOpen && (
        <div
          className={`absolute ${
            align === 'right' ? 'right-0' : 'left-0'
          } mt-1.5 w-48 rounded-2xl bg-white border border-slate-200 shadow-xl z-50 py-1.5 overflow-hidden animate-in fade-in zoom-in-95`}
        >
          <div className="px-3 py-1 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100">
            Pilih Format Berkas
          </div>
          <button
            type="button"
            onClick={() => {
              setIsOpen(false);
              onExportPdf();
            }}
            className="w-full text-left px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-purple-50 hover:text-purple-900 flex items-center gap-2.5 transition-colors cursor-pointer"
          >
            <div className="w-6 h-6 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
              <FileDown className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="font-bold text-slate-900">Format PDF</div>
              <div className="text-[10px] text-slate-400 font-normal">Cetak / Berkas Dokumen</div>
            </div>
          </button>
          <button
            type="button"
            onClick={() => {
              setIsOpen(false);
              onExportExcel();
            }}
            className="w-full text-left px-3.5 py-2 text-xs font-semibold text-slate-700 hover:bg-emerald-50 hover:text-emerald-900 flex items-center gap-2.5 transition-colors cursor-pointer"
          >
            <div className="w-6 h-6 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="w-3.5 h-3.5" />
            </div>
            <div>
              <div className="font-bold text-slate-900">Format Excel</div>
              <div className="text-[10px] text-slate-400 font-normal">Tabel Data (.xlsx)</div>
            </div>
          </button>
        </div>
      )}
    </div>
  );
};

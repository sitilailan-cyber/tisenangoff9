/**
 * TI SENANG - Welcome Greeting Overlay Component
 * Tampil singkat (3-4 detik) setelah login berhasil:
 * - Fade in & subtle slide
 * - Ambient glow futuristik
 * - Menyajikan nama pengguna dinamis
 */

import React, { useEffect, useState } from 'react';
import { Sparkles, CheckCircle2, Volume2, VolumeX } from 'lucide-react';
import { User } from '../../types';
import { getGreetingText, isAudioGreetingEnabled, setAudioGreetingEnabled } from '../../services/audioGreeting';

interface WelcomeToastProps {
  user: User | null;
  onDismiss?: () => void;
}

export const WelcomeToast: React.FC<WelcomeToastProps> = ({ user, onDismiss }) => {
  const [visible, setVisible] = useState(false);
  const [audioActive, setAudioActive] = useState(() => isAudioGreetingEnabled());

  useEffect(() => {
    if (!user) {
      setVisible(false);
      return;
    }

    // Tampilkan dengan animasi fade in & slide
    setVisible(true);

    const timer = setTimeout(() => {
      setVisible(false);
      if (onDismiss) onDismiss();
    }, 3600);

    return () => clearTimeout(timer);
  }, [user, onDismiss]);

  if (!user || !visible) return null;

  const { toastTitle, subtitle } = getGreetingText(user);
  const isMurid = user.role === 'murid';

  const toggleAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    const next = !audioActive;
    setAudioActive(next);
    setAudioGreetingEnabled(next);
  };

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed top-5 left-1/2 -translate-x-1/2 z-50 pointer-events-auto select-none transition-all duration-500 transform animate-slide-in-down"
    >
      <div
        className={`relative flex items-center gap-3.5 px-5 py-3 rounded-2xl shadow-2xl backdrop-blur-xl border transition-all ${
          isMurid
            ? 'bg-slate-950/90 border-pink-500/50 shadow-[0_0_35px_rgba(236,72,153,0.35)] text-white'
            : 'bg-slate-950/90 border-cyan-400/50 shadow-[0_0_35px_rgba(6,182,212,0.35)] text-white'
        }`}
      >
        {/* Glow backdrop pulse */}
        <div
          className={`absolute -inset-1 rounded-2xl blur-lg opacity-40 pointer-events-none -z-10 ${
            isMurid ? 'bg-gradient-to-r from-pink-500 to-purple-500' : 'bg-gradient-to-r from-blue-500 to-cyan-400'
          }`}
        />

        {/* Icon */}
        <div
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
            isMurid
              ? 'bg-pink-500/20 border-pink-400/50 text-pink-300'
              : 'bg-cyan-500/20 border-cyan-400/50 text-cyan-300'
          }`}
        >
          <Sparkles className="w-5 h-5 animate-spin-slow text-amber-300" />
        </div>

        {/* Text */}
        <div className="flex flex-col text-left pr-2">
          <h4 className="text-sm sm:text-base font-extrabold font-display tracking-tight text-white flex items-center gap-1.5">
            <span>{toastTitle}</span>
          </h4>
          <p className="text-[11px] text-slate-300 font-medium">
            {subtitle}
          </p>
        </div>

        {/* Audio status indicator / toggle */}
        <button
          type="button"
          onClick={toggleAudio}
          title={audioActive ? 'Audio sapaan aktif (Klik untuk senyap)' : 'Audio sapaan senyap (Klik untuk aktifkan)'}
          className="p-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700/60 cursor-pointer shrink-0"
        >
          {audioActive ? (
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
          ) : (
            <VolumeX className="w-3.5 h-3.5 text-slate-400" />
          )}
        </button>
      </div>
    </div>
  );
};

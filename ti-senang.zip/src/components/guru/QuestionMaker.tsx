import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  HelpCircle,
  CheckCircle2,
  XCircle,
  MoveDown,
  ArrowUpDown,
  FileQuestion,
  ListOrdered,
  CheckSquare,
  Sparkles,
} from 'lucide-react';
import { QuestionCategoryType, QuestionItem, MatchingPair } from '../../types';

interface QuestionMakerProps {
  questions: QuestionItem[];
  onChange: (updatedQuestions: QuestionItem[]) => void;
  mode?: 'latihan' | 'asesmen'; // latihan = PG, PGK, isian; asesmen = 6 tipe lengkap
  subjectName?: string;
  topic?: string;
}

export const QuestionMaker: React.FC<QuestionMakerProps> = ({
  questions = [],
  onChange,
  mode = 'asesmen',
  subjectName = 'Fisika',
  topic = 'Kalor & Termodinamika',
}) => {
  const [activeTab, setActiveTab] = useState<QuestionCategoryType>('pilihan_ganda');

  // Kategori soal yang diizinkan berdasarkan mode
  const allowedCategories: Array<{
    type: QuestionCategoryType;
    label: string;
    icon: any;
    desc: string;
  }> =
    mode === 'latihan'
      ? [
          { type: 'pilihan_ganda', label: 'Pilihan Ganda (PG)', icon: FileQuestion, desc: '1 jawaban benar' },
          { type: 'mcma', label: 'PG Kompleks (PGK)', icon: CheckSquare, desc: 'Multiple pilihan benar' },
          { type: 'isian', label: 'Isian Singkat', icon: HelpCircle, desc: 'Jawaban teks / angka' },
        ]
      : [
          { type: 'pilihan_ganda', label: 'Pilihan Ganda (PG)', icon: FileQuestion, desc: '1 jawaban benar' },
          { type: 'benar_salah', label: 'Benar / Salah', icon: CheckCircle2, desc: 'Pernyataan benar atau salah' },
          { type: 'mcma', label: 'MCMA / PG Kompleks', icon: CheckSquare, desc: 'Centang beberapa opsi benar' },
          { type: 'isian', label: 'Isian Singkat', icon: HelpCircle, desc: 'Jawaban teks pendek / numerik' },
          { type: 'jodohkan', label: 'Menjodohkan', icon: ArrowUpDown, desc: 'Pasangkan konsep dan deskripsi' },
          { type: 'mengurutkan', label: 'Mengurutkan', icon: ListOrdered, desc: 'Susun langkah / tahap berurutan' },
        ];

  const handleGenerateAiQuestions = () => {
    const ts = Date.now();
    if (mode === 'latihan') {
      const generated: QuestionItem[] = [
        // 2 Soal Pilihan Ganda (PG)
        {
          id: `q-ai-${ts}-1`,
          category: 'pilihan_ganda',
          prompt:
            'Pada percobaan kalorimeter ideal tanpa rugi kalor ke lingkungan, jika 200 gram air bersuhu 80°C dicampur dengan 200 gram air bersuhu 20°C, maka suhu kesetimbangan termal akhir adalah...',
          options: ['40°C', '50°C', '60°C', '70°C'],
          correctAnswer: '50°C',
          explanation:
            'Karena massa dan kalor jenis kedua fluida air identik, suhu kesetimbangan T_akhir = (80 + 20) / 2 = 50°C.',
          points: 15,
        },
        {
          id: `q-ai-${ts}-2`,
          category: 'pilihan_ganda',
          prompt:
            'Persamaan regresi linear laju pemanasan air adalah ŷ = 3.5x + 25, dengan x adalah waktu (menit) dan ŷ adalah suhu (°C). Nilai gradien regresi 3.5 menyatakan bahwa...',
          options: [
            'Suhu awal air sebelum dipanaskan adalah 3.5°C',
            'Suhu air meningkat sebesar 3.5°C untuk setiap pertambahan 1 menit waktu pemanasan',
            'Air mendidih setelah dipanaskan selama 3.5 menit',
            'Koefisien determinasi eksperimen sebesar 35%',
          ],
          correctAnswer:
            'Suhu air meningkat sebesar 3.5°C untuk setiap pertambahan 1 menit waktu pemanasan',
          explanation:
            'Gradien (slope) m = 3.5 merepresentasikan laju perubahan suhu per satuan waktu menit pemanasan.',
          points: 15,
        },
        // 2 Soal Pilihan Ganda Kompleks (PGK / MCMA)
        {
          id: `q-ai-${ts}-3`,
          category: 'mcma',
          prompt:
            'Pilihlah DUA faktor utama yang secara langsung mempercepat laju perpindahan kalor secara konduksi pada dinding kalorimeter:',
          options: [
            'Memperbesar luas penampang kontak termal konduktor',
            'Menggunakan bahan isolator dengan konduktivitas termal sangat rendah',
            'Memperbesar selisih perbedaan temperatur antara kedua permukaan',
            'Menambah ketebalan dinding bahan isolasi penahan kalor',
          ],
          correctAnswer: [
            'Memperbesar luas penampang kontak termal konduktor',
            'Memperbesar selisih perbedaan temperatur antara kedua permukaan',
          ],
          explanation:
            'Menurut Hukum Fourier: H = k · A · ΔT / L. Laju konduksi meningkat saat luas (A) dan gradien temperatur (ΔT) membesar.',
          points: 20,
        },
        {
          id: `q-ai-${ts}-4`,
          category: 'mcma',
          prompt:
            'Pilihlah DUA langkah saintifik yang tepat untuk memastikan data pengujian sensor IoT kalorimeter memiliki presisi dan akurasi tinggi:',
          options: [
            'Melakukan kalibrasi sensor menggunakan titik acuan es melebur (0°C) dan air mendidih (100°C)',
            'Mengubah volume air secara acak saat proses pencatatan data sedang berlangsung',
            'Melakukan pencatatan pengukuran berulang (triplo) untuk menghitung rata-rata dan standar deviasi',
            'Menempatkan sensor tepat di samping sumber api tanpa menyentuh fluida uji',
          ],
          correctAnswer: [
            'Melakukan kalibrasi sensor menggunakan titik acuan es melebur (0°C) dan air mendidih (100°C)',
            'Melakukan pencatatan pengukuran berulang (triplo) untuk menghitung rata-rata dan standar deviasi',
          ],
          explanation:
            'Kalibrasi pada titik acuan standar dan pengukuran berulang (repetisi) meminimalkan galat sistematis serta acak.',
          points: 20,
        },
        // 2 Soal Isian Singkat
        {
          id: `q-ai-${ts}-5`,
          category: 'isian',
          prompt:
            'Tuliskan simbol atau satuan standar internasional (SI) untuk besaran kapasitas kalor jenis suatu zat (misal: J/(kg.K) atau J/kg K)!',
          correctAnswer: 'J/(kg·K)',
          explanation: 'Satuan SI kapasitas kalor jenis adalah Joule per kilogram Kelvin (J/(kg·K) atau J/kg K).',
          points: 15,
        },
        {
          id: `q-ai-${ts}-6`,
          category: 'isian',
          prompt:
            'Berapakah nilai koefisien korelasi Pearson maksimum yang menyatakan adanya hubungan linear positif sempurna antarvariabel?',
          correctAnswer: '1',
          explanation: 'Nilai korelasi Pearson bernilai antara -1 hingga +1. Nilai +1 menyatakan korelasi linear positif sempurna.',
          points: 15,
        },
      ];
      onChange(generated);
    } else {
      // mode === 'asesmen' (6 Tipe Lengkap: PG, Benar Salah, MCMA, Isian, Jodohkan, Urutkan)
      const sLower = (subjectName || '').toLowerCase();
      const tLower = (topic || '').toLowerCase();
      const isMath = sLower.includes('mat') || tLower.includes('regresi') || tLower.includes('aljabar') || tLower.includes('statistika') || tLower.includes('fungsi') || tLower.includes('kalkulus') || tLower.includes('matriks');
      const isKimia = sLower.includes('kim') || tLower.includes('larutan') || tLower.includes('reaksi') || tLower.includes('asam') || tLower.includes('senyawa') || tLower.includes('entalpi');
      const isBiologi = sLower.includes('bio') || tLower.includes('sel') || tLower.includes('fotosintesis') || tLower.includes('ekosistem') || tLower.includes('enzim') || tLower.includes('gen');
      const isInformatika = sLower.includes('inf') || sLower.includes('komp') || tLower.includes('algoritma') || tLower.includes('koding') || tLower.includes('program') || tLower.includes('data');

      let generated: QuestionItem[] = [];

      if (isMath) {
        generated = [
          {
            id: `q-ai-asm-${ts}-1`,
            category: 'pilihan_ganda',
            prompt:
              `Dalam pemodelan matematika data bivariat regresi linear sederhana ŷ = 3,5x + 12,0 antara variabel bebas (X) dan variabel terikat (Y) materi ${topic}, jika nilai X = 4 dan nilai koefisien determinasi R² = 0,81, interpretasi matematis yang tepat adalah...`,
            options: [
              'Prediksi nilai ŷ = 26,0 dan 81% variasi variabel terikat dapat dijelaskan oleh model regresi linear.',
              'Prediksi nilai ŷ = 24,5 dan 19% variasi variabel terikat dipengaruhi oleh variabel bebas.',
              'Prediksi nilai ŷ = 28,0 dan korelasi kedua variabel berbanding terbalik.',
              'Prediksi nilai ŷ = 30,0 dan model tidak layak digunakan untuk estimasi data.',
            ],
            correctAnswer:
              'Prediksi nilai ŷ = 26,0 dan 81% variasi variabel terikat dapat dijelaskan oleh model regresi linear.',
            explanation:
              'Substitusi X = 4 ke persamaan: ŷ = 3,5(4) + 12,0 = 14,0 + 12,0 = 26,0. R² = 0,81 menunjukkan 81% variabilitas data dijelaskan oleh model matematis.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-2`,
            category: 'benar_salah',
            prompt:
              'Pernyataan: Jika nilai koefisien korelasi Pearson r bernilai negatif (r < 0), maka grafik diagram pencar memiliki tren menurun di mana setiap kenaikan nilai variabel bebas x akan diiringi oleh penurunan nilai variabel terikat y.',
            correctAnswer: true,
            explanation:
              'Benar. Nilai r negatif menunjukkan arah hubungan linear berlawanan arah dengan nilai gradien b < 0.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-3`,
            category: 'mcma',
            prompt:
              'Pilihlah DUA sifat yang BENAR mengenai koefisien korelasi linear Pearson (r) dalam analisis statistika matematika:',
            options: [
              'Rentang nilai r selalu berada pada interval tertutup [-1, +1]',
              'Nilai r = 0 menunjukkan tidak adanya hubungan linear antarvariabel',
              'Nilai r selalu bernilai positif meskipun gradien garis regresi bernilai negatif',
              'Satuan pengukuran data variabel x dan y mempengaruhi besar nilai r',
            ],
            correctAnswer: [
              'Rentang nilai r selalu berada pada interval tertutup [-1, +1]',
              'Nilai r = 0 menunjukkan tidak adanya hubungan linear antarvariabel',
            ],
            explanation:
              'Koefisien korelasi Pearson r bersifat tak berdimensi dengan nilai absolut maksimum 1 dan r = 0 berarti tidak terdapat korelasi linear.',
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-4`,
            category: 'isian',
            prompt:
              'Pada persamaan regresi linear sederhana ŷ = 5 + 2x, jika rata-rata data variabel x (x̄) bernilai 10, berapakah nilai rata-rata data variabel y (ȳ)?',
            correctAnswer: '25',
            explanation: 'Garis regresi selalu melalui titik rata-rata (x̄, ȳ), sehingga ȳ = 5 + 2(10) = 25.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-5`,
            category: 'jodohkan',
            prompt:
              'Jodohkan istilah analisis regresi dan statistika matematika di sebelah kiri dengan konsep yang tepat di sebelah kanan:',
            matchingPairs: [
              { id: 'p-1', premise: 'Koefisien Determinasi (R²)', match: 'Proporsi variasi variabel terikat yang diterangkan variabel bebas' },
              { id: 'p-2', premise: 'Intersep Garis (a)', match: 'Nilai prediksi y saat nilai variabel x bernilai nol' },
              { id: 'p-3', premise: 'Gradien Kemiringan (b)', match: 'Besarnya perubahan nilai y untuk setiap kenaikan 1 satuan x' },
            ],
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-6`,
            category: 'mengurutkan',
            prompt:
              'Urutkan langkah-langkah sistematis dalam penyusunan model regresi linear matematika dari tahapan awal:',
            sequenceItems: [
              '1. Mengumpulkan pasangan data bivariat (x, y) dan membuat diagram pencar (scatter plot)',
              '2. Menghitung koefisien korelasi Pearson (r) untuk mengetahui kekuatan arah korelasi',
              '3. Menghitung gradien (b) dan konstanta intersep (a) metode kuadrat terkecil',
              '4. Menyusun model persamaan regresi ŷ = a + bx dan menguji kelayakan model menggunakan R²',
            ],
            points: 15,
          },
        ];
      } else if (isKimia) {
        generated = [
          {
            id: `q-ai-asm-${ts}-1`,
            category: 'pilihan_ganda',
            prompt:
              `Dalam eksperimen termokimia materi ${topic}, reaksi pelarutan suatu zat dalam kalorimeter menyebabkan suhu larutan naik dari 25°C menjadi 35°C. Jenis reaksi termokimia dan tanda perubahan entalpi (ΔH) yang tepat adalah...`,
            options: [
              'Reaksi eksoterm dengan nilai perubahan entalpi ΔH bernilai negatif (ΔH < 0).',
              'Reaksi endoterm dengan nilai perubahan entalpi ΔH bernilai positif (ΔH > 0).',
              'Reaksi adiabatik dengan nilai perubahan entalpi ΔH bernilai nol (ΔH = 0).',
              'Reaksi reversibel tanpa adanya pertukaran kalor sistem ke lingkungan.',
            ],
            correctAnswer:
              'Reaksi eksoterm dengan nilai perubahan entalpi ΔH bernilai negatif (ΔH < 0).',
            explanation:
              'Kenaikan suhu pada kalorimeter menunjukkan kalor dilepas oleh sistem reaksi ke lingkungan (eksoterm), sehingga ΔH < 0.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-2`,
            category: 'benar_salah',
            prompt:
              'Pernyataan: Menurut Hukum Hess, nilai perubahan entalpi (ΔH) suatu reaksi kimia hanya bergantung pada keadaan awal reaktan dan keadaan akhir produk, bukan pada jalannya tahapan reaksi.',
            correctAnswer: true,
            explanation: 'Benar. Entalpi merupakan fungsi keadaan sehingga nilai ΔH independen dari lintasan reaksi.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-3`,
            category: 'mcma',
            prompt:
              'Pilihlah DUA faktor berikut yang terbukti secara kinetika kimia dapat meningkatkan laju reaksi zat pereaksi:',
            options: [
              'Meningkatkan konsentrasi larutan zat pereaksi',
              'Menambahkan katalis untuk menurunkan energi aktivasi reaksi',
              'Memperkecil luas permukaan bidang sentuh padatan reaktan',
              'Menurunkan suhu sistem reaksi secara konstan',
            ],
            correctAnswer: [
              'Meningkatkan konsentrasi larutan zat pereaksi',
              'Menambahkan katalis untuk menurunkan energi aktivasi reaksi',
            ],
            explanation:
              'Konsentrasi lebih tinggi memperbanyak frekuensi tumbukan efektif partikel, dan katalis menurunkan energi aktivasi Ea.',
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-4`,
            category: 'isian',
            prompt:
              'Tuliskan rumus kalor larutan q = m · c · ΔT, jika massa air 100 gram, kalor jenis air 4,2 J/(g·°C), dan kenaikan suhu 10°C, berapakah kalor yang diserap larutan dalam satuan Joule (tuliskan angkanya saja)?',
            correctAnswer: '4200',
            explanation: 'q = 100 g × 4,2 J/(g·°C) × 10°C = 4200 Joule.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-5`,
            category: 'jodohkan',
            prompt:
              'Jodohkan konsep termokimia dan kinetika di sebelah kiri dengan prinsip ilmiah yang tepat di sebelah kanan:',
            matchingPairs: [
              { id: 'p-1', premise: 'Reaksi Eksoterm', match: 'Melepas kalor ke lingkungan, ΔH bernilai negatif' },
              { id: 'p-2', premise: 'Reaksi Endoterm', match: 'Menyerap kalor dari lingkungan, ΔH bernilai positif' },
              { id: 'p-3', premise: 'Katalisator', match: 'Zat pemercepat laju reaksi dengan menurunkan energi aktivasi' },
            ],
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-6`,
            category: 'mengurutkan',
            prompt:
              'Urutkan tahapan pelaksanaan eksperimen penentuan entalpi reaksi menggunakan kalorimeter sederhana:',
            sequenceItems: [
              '1. Mengukur volume dan suhu awal larutan pereaksi sebelum dicampurkan',
              '2. Mencampurkan pereaksi ke dalam kalorimeter dan mengaduk secara merata',
              '3. Mencatat suhu tertinggi yang terbaca stabil pada termometer digital',
              '4. Menghitung jumlah kalor q_larutan dan perubahan entalpi molar ΔH reaksi',
            ],
            points: 15,
          },
        ];
      } else if (isBiologi) {
        generated = [
          {
            id: `q-ai-asm-${ts}-1`,
            category: 'pilihan_ganda',
            prompt:
              `Dalam penyelidikan fisiologi tumbuhan materi ${topic}, peningkatan intensitas cahaya pada rentang optimal meningkatkan laju fotosintesis hingga mencapai titik jenuh. Faktor yang menjadi pembatas utama laju fotosintesis setelah titik jenuh cahaya tercapai adalah...`,
            options: [
              'Konsentrasi gas karbon dioksida (CO₂) dan suhu lingkungan.',
              'Ketersediaan pigmen klorofil pada kloroplas daun semata.',
              'Panjang gelombang cahaya hijau yang diserap pigmen fotosintetik.',
              'Ketebalan lapisan kutikula pada jaringan epidermis atas daun.',
            ],
            correctAnswer:
              'Konsentrasi gas karbon dioksida (CO₂) dan suhu lingkungan.',
            explanation:
              'Pada intensitas cahaya tinggi, laju reaksi gelap fotosintesis dibatasi oleh ketersediaan CO₂ dan kinetika enzim rubisco yang dipengaruhi suhu.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-2`,
            category: 'benar_salah',
            prompt:
              'Pernyataan: Pada respirasi seluler aerob, tahap glikolisis berlangsung di sitosol tanpa memerlukan oksigen bebas dan menghasilkan 2 molekul asam piruvat, 2 ATP, dan 2 NADH.',
            correctAnswer: true,
            explanation: 'Benar. Glikolisis adalah tahap anaerobik di sitosol yang memecah glukosa menjadi piruvat.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-3`,
            category: 'mcma',
            prompt:
              'Pilihlah DUA organel sel eukariotik yang memiliki membran ganda dan memiliki materi genetik (DNA/ribosom) mandiri:',
            options: [
              'Mitokondria',
              'Kloroplas (Plastida)',
              'Badan Golgi',
              'Retikulum Endoplasma',
            ],
            correctAnswer: ['Mitokondria', 'Kloroplas (Plastida)'],
            explanation: 'Mitokondria dan kloroplas merupakan organel semiotonom bermembran ganda sesuai teori endosimbiosis.',
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-4`,
            category: 'isian',
            prompt:
              'Tuliskan nama proses difusi molekul pelarut (khususnya air) melintasi membran semipermeabel dari larutan hipotonik menuju larutan hipertonik!',
            correctAnswer: 'osmosis',
            explanation: 'Osmosis adalah perpindahan molekul air melintasi membran selektif permeabel.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-5`,
            category: 'jodohkan',
            prompt:
              'Jodohkan proses biologi di sebelah kiri dengan lokasi spesifik terjadinya proses di sebelah kanan:',
            matchingPairs: [
              { id: 'p-1', premise: 'Reaksi Terang Fotosintesis', match: 'Membran Tilakoid (Grana) Kloroplas' },
              { id: 'p-2', premise: 'Siklus Calvin (Reaksi Gelap)', match: 'Stroma Kloroplas' },
              { id: 'p-3', premise: 'Siklus Krebs', match: 'Matriks Mitokondria' },
            ],
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-6`,
            category: 'mengurutkan',
            prompt:
              'Urutkan tahapan aliran energi respirasi seluler aerob dari substrat awal hingga produksi ATP maksimal:',
            sequenceItems: [
              '1. Glikolisis glukosa menjadi 2 asam piruvat di sitoplasma',
              '2. Dekarboksilasi oksidatif piruvat menjadi Asetil Koenzim A',
              '3. Siklus Krebs (Siklus Asam Sitrat) di matriks mitokondria',
              '4. Fosforilasi oksidatif melalui rantai transpor elektron di krista mitokondria',
            ],
            points: 15,
          },
        ];
      } else if (isInformatika) {
        generated = [
          {
            id: `q-ai-asm-${ts}-1`,
            category: 'pilihan_ganda',
            prompt:
              `Dalam perancangan algoritma materi ${topic}, sebuah fungsi pencarian biner (binary search) diterapkan pada array data terurut berisi 1024 elemen. Kompleksitas waktu dan jumlah perbandingan maksimum elemen adalah...`,
            options: [
              'Kompleksitas O(log n) dengan perbandingan maksimal 10 kali.',
              'Kompleksitas O(n) dengan perbandingan maksimal 1024 kali.',
              'Kompleksitas O(n log n) dengan perbandingan maksimal 100 kali.',
              'Kompleksitas O(1) dengan perbandingan instan langsung pada indeks.',
            ],
            correctAnswer:
              'Kompleksitas O(log n) dengan perbandingan maksimal 10 kali.',
            explanation:
              'Binary search membagi ruang pencarian menjadi dua pada tiap iterasi: log₂(1024) = 10, sehingga kompleksitasnya O(log n).',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-2`,
            category: 'benar_salah',
            prompt:
              'Pernyataan: Struktur data antrean (Queue) beroperasi dengan prinsip LIFO (Last In First Out) di mana elemen yang terakhir dimasukkan akan menjadi elemen yang pertama dikeluarkan.',
            correctAnswer: false,
            explanation: 'Salah. Queue beroperasi dengan prinsip FIFO (First In First Out), sedangkan LIFO adalah prinsip Stack.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-3`,
            category: 'mcma',
            prompt:
              'Pilihlah DUA karakteristik utama dari arsitektur layanan berbasis Cloud Computing (Komputasi Awan):',
            options: [
              'Elastisitas sumber daya yang dapat diskalakan sesuai kebutuhan beban kerja',
              'Aksesibilitas jaringan luas melalui protokol internet standar',
              'Ketergantungan wajib pada perangkat server fisik milik pengguna lokal',
              'Penetapan kapasitas penyimpanan data yang kaku dan tidak dapat diubah',
            ],
            correctAnswer: [
              'Elastisitas sumber daya yang dapat diskalakan sesuai kebutuhan beban kerja',
              'Aksesibilitas jaringan luas melalui protokol internet standar',
            ],
            explanation:
              'Komputasi awan menawarkan rapid elasticity dan broad network access sesuai definisi standar NIST.',
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-4`,
            category: 'isian',
            prompt:
              'Tuliskan istilah keamanan siber untuk metode enkripsi yang menggunakan sepasang kunci berbeda, yaitu kunci publik (public key) dan kunci privat (private key)!',
            correctAnswer: 'asimetris',
            explanation: 'Kriptografi asimetris (public-key cryptography) menggunakan pasangan kunci publik dan privat.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-5`,
            category: 'jodohkan',
            prompt:
              'Jodohkan struktur data di sebelah kiri dengan karakteristik operasi utamanya di sebelah kanan:',
            matchingPairs: [
              { id: 'p-1', premise: 'Stack (Tumpukan)', match: 'Prinsip operasi LIFO (Last In First Out)' },
              { id: 'p-2', premise: 'Queue (Antrean)', match: 'Prinsip operasi FIFO (First In First Out)' },
              { id: 'p-3', premise: 'Binary Search Tree', match: 'Pohon berakar terurut dengan anak kiri lebih kecil dari induk' },
            ],
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-6`,
            category: 'mengurutkan',
            prompt:
              'Urutkan tahapan siklus pengembangan perangkat lunak (SDLC) tradisional model Waterfall dari fase awal:',
            sequenceItems: [
              '1. Analisis Kebutuhan Sistem (Requirement Analysis)',
              '2. Perancangan Arsitektur dan Antarmuka (System Design)',
              '3. Penulisan Kode Program dan Integrasi Modul (Implementation)',
              '4. Pengujian Sistem dan Verifikasi Kelayakan (Testing & QA)',
            ],
            points: 15,
          },
        ];
      } else {
        // Default / Fisika / Sains Terapan
        generated = [
          {
            id: `q-ai-asm-${ts}-1`,
            category: 'pilihan_ganda',
            prompt:
              `Dalam analisis data regresi bivariat materi ${subjectName} topik ${topic}, hubungan antara variabel bebas (X) terhadap variabel terikat (Y) menghasilkan koefisien determinasi R² bernilai 0,92. Interpretasi saintifik yang tepat adalah...`,
            options: [
              '92% variasi variabel terikat dapat dijelaskan oleh variasi variabel bebas dalam model regresi.',
              'Korelasi antara variabel bebas dan terikat bernilai negatif kuat.',
              'Terdapat 8% kemungkinan hasil eksperimen mengalami galat sistematis total.',
              'Hubungan kedua variabel adalah non-linear kuadratik sempurna.',
            ],
            correctAnswer:
              '92% variasi variabel terikat dapat dijelaskan oleh variasi variabel bebas dalam model regresi.',
            explanation:
              'R² = 0,92 menyatakan bahwa 92% variabilitas variabel dependen dapat diterangkan oleh model regresi.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-2`,
            category: 'benar_salah',
            prompt:
              `Pernyataan: Pada sistem kalorimeter adiabatik ideal yang tertutup rapat, pertukaran energi kalor antara sistem fluida dengan lingkungan luar bernilai nol (Q_lingkungan = 0).`,
            correctAnswer: true,
            explanation:
              'Benar. Sistem adiabatik ideal mencegah aliran kalor keluar maupun masuk dari lingkungan luar.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-3`,
            category: 'mcma',
            prompt:
              `Pilihlah DUA faktor fisik yang terbukti secara empiris mempercepat laju perpindahan energi kalor dan evaporasi cairan pada materi ${topic}:`,
            options: [
              'Peningkatan intensitas radiasi termal pemanasan',
              'Peningkatan kecepatan aliran fluida udara di atas permukaan',
              'Peningkatan kelembaban relatif udara di lingkungan sekitar',
              'Penambahan ketebalan wadah penampung isolator',
            ],
            correctAnswer: [
              'Peningkatan intensitas radiasi termal pemanasan',
              'Peningkatan kecepatan aliran fluida udara di atas permukaan',
            ],
            explanation:
              'Radiasi termal menaikkan energi kinetik partikel dan aliran konveksi fluida mempercepat perpindahan kalor.',
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-4`,
            category: 'isian',
            prompt:
              'Tuliskan istilah hukum kesetimbangan termal yang menyatakan bahwa kalor yang dilepas oleh benda bersuhu tinggi sama dengan kalor yang diserap oleh benda bersuhu rendah!',
            correctAnswer: 'azas black',
            explanation: 'Azas Black menyatakan bahwa dalam sistem tertutup: Q_lepas = Q_terima.',
            points: 15,
          },
          {
            id: `q-ai-asm-${ts}-5`,
            category: 'jodohkan',
            prompt:
              `Jodohkan konsep hukum perpindahan energi kalor pada materi ${topic} di sebelah kiri dengan deskripsi saintifik yang sesuai di sebelah kanan:`,
            matchingPairs: [
              { id: 'p-1', premise: 'Hukum Fourier', match: 'Laju konduksi kalor pada zat padat' },
              { id: 'p-2', premise: 'Hukum Stefan-Boltzmann', match: 'Radiasi kalor benda hitam' },
              { id: 'p-3', premise: 'Garis Regresi Linear', match: 'Garis tren prediksi data eksperimen bivariat' },
            ],
            points: 20,
          },
          {
            id: `q-ai-asm-${ts}-6`,
            category: 'mengurutkan',
            prompt:
              `Urutkan tahapan metode ilmiah dalam perancangan eksperimen materi ${topic} berikut dari langkah paling awal:`,
            sequenceItems: [
              '1. Merumuskan hipotesis penyelidikan & menentukan variabel bebas/terikat',
              '2. Mengkalibrasi sensor suhu probe virtual lab',
              '3. Mengumpulkan data pengamatan pada tabel spreadsheet eksperimen',
              '4. Menganalisis diagram pencar regresi dan menarik simpulan ilmiah',
            ],
            points: 15,
          },
        ];
      }

      onChange(generated);
    }
  };

  const handleAddQuestion = (category: QuestionCategoryType) => {
    const newId = `q-${Date.now()}`;
    let newQ: QuestionItem;

    switch (category) {
      case 'pilihan_ganda':
        newQ = {
          id: newId,
          category,
          prompt: 'Tuliskan pertanyaan pilihan ganda di sini...',
          options: ['Pilihan A', 'Pilihan B', 'Pilihan C', 'Pilihan D'],
          correctAnswer: 'Pilihan A',
          explanation: 'Pembahasan konsep materi...',
          points: 10,
        };
        break;
      case 'benar_salah':
        newQ = {
          id: newId,
          category,
          prompt: 'Pernyataan konsep: Laju konduksi kalor berbanding lurus dengan konduktivitas termal bahan.',
          correctAnswer: true,
          explanation: 'Pernyataan benar sesuai hukum Fourier kalor.',
          points: 10,
        };
        break;
      case 'mcma':
        newQ = {
          id: newId,
          category,
          prompt: 'Pilih semua pernyataan yang BENAR terkait eksperimen kalorimeter sensor radiasi:',
          options: [
            'Suhu akhir fluida bergantung pada waktu radiasi pemanasan',
            'Kalorimeter isolator mengurangi kebocoran panas ke lingkungan',
            'Laju perpindahan kalor berbanding terbalik dengan luas permukaan radiasi',
            'Sensor termokopel probe membaca kenaikan suhu fluida secara akurat',
          ],
          correctAnswer: [
            'Suhu akhir fluida bergantung pada waktu radiasi pemanasan',
            'Kalorimeter isolator mengurangi kebocoran panas ke lingkungan',
            'Sensor termokopel probe membaca kenaikan suhu fluida secara akurat',
          ],
          points: 15,
        };
        break;
      case 'isian':
        newQ = {
          id: newId,
          category,
          prompt: 'Berapakah nilai kapasitas kalor jenis air murni dalam satuan J/(kg·K)?',
          correctAnswer: '4200',
          points: 10,
        };
        break;
      case 'jodohkan':
        newQ = {
          id: newId,
          category,
          prompt: 'Jodohkan istilah saintifik di sebelah kiri dengan konsep/persamaan yang sesuai di sebelah kanan:',
          matchingPairs: [
            { id: 'p-1', premise: 'Hukum Fourier', match: 'Perpindahan kalor konduksi' },
            { id: 'p-2', premise: 'Hukum Stefan-Boltzmann', match: 'Radiasi kalor benda hitam' },
            { id: 'p-3', premise: 'Regresi Linear', match: 'Garis tren data bivariat' },
          ],
          points: 15,
        };
        break;
      case 'mengurutkan':
        newQ = {
          id: newId,
          category,
          prompt: 'Urutkan langkah metode ilmiah dalam perancangan eksperimen fisika terapan berikut dari tahap awal:',
          sequenceItems: [
            '1. Merumuskan hipotesis penyelidikan',
            '2. Mengkalibrasi sensor suhu probe virtual lab',
            '3. Mencatat tabel data pengamatan spreadsheet',
            '4. Menganalisis kurva gradien suhu dan menarik kesimpulan',
          ],
          points: 15,
        };
        break;
      default:
        newQ = {
          id: newId,
          category: 'pilihan_ganda',
          prompt: 'Pertanyaan baru',
          options: ['A', 'B', 'C', 'D'],
          correctAnswer: 'A',
          points: 10,
        };
    }

    onChange([...questions, newQ]);
  };

  const handleUpdateQuestion = (id: string, updates: Partial<QuestionItem>) => {
    onChange(
      questions.map((q) => (q.id === id ? { ...q, ...updates } : q))
    );
  };

  const handleDeleteQuestion = (id: string) => {
    onChange(questions.filter((q) => q.id !== id));
  };

  return (
    <div className="space-y-4 rounded-2xl bg-slate-50 border border-slate-200 p-3.5 sm:p-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200 pb-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1 rounded-lg bg-indigo-600 text-white">
              <Sparkles className="w-3.5 h-3.5" />
            </span>
            <h4 className="font-display font-bold text-slate-900 text-sm">
              {mode === 'asesmen' ? 'Pembuat Soal Asesmen (6 Kategori Lengkap)' : 'Pembuat Soal Latihan (PG, PGK, Isian)'}
            </h4>
          </div>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Buat butir soal langsung di dalam aplikasi TI SENANG untuk dikerjakan murid di Misi {mode === 'asesmen' ? '6 (Asesmen Akhir)' : '5 (Latihan & Refleksi)'}.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={handleGenerateAiQuestions}
            className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-bold shadow-xs flex items-center gap-1.5 transition-all cursor-pointer active:scale-95"
            title="Buat paket soal otomatis menggunakan AI"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>
              {mode === 'latihan'
                ? '✨ Buat Otomatis AI (2 PG, 2 PGK, 2 Isian)'
                : '✨ Buat Otomatis AI (6 Kategori Soal Lengkap)'}
            </span>
          </button>
          <span className="text-xs font-bold text-indigo-700 bg-indigo-100/80 px-2.5 py-1 rounded-full border border-indigo-200">
            {questions.length} Butir Soal Terbuat
          </span>
        </div>
      </div>

      {/* Selector Kategori Soal */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {allowedCategories.map((cat) => {
          const Icon = cat.icon;
          return (
            <button
              key={cat.type}
              type="button"
              onClick={() => handleAddQuestion(cat.type)}
              className="p-2 sm:p-2.5 rounded-xl border border-indigo-200/90 bg-white hover:bg-indigo-50/70 hover:border-indigo-400 text-left transition-all shadow-2xs group cursor-pointer"
              title={cat.desc}
            >
              <div className="flex items-center gap-1.5 text-indigo-600 mb-1 group-hover:scale-105 transition-transform">
                <Plus className="w-3.5 h-3.5" />
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className="font-bold text-slate-800 text-[11px] leading-tight">
                {cat.label}
              </div>
              <div className="text-[9px] text-slate-500 line-clamp-1 mt-0.5">
                {cat.desc}
              </div>
            </button>
          );
        })}
      </div>

      {/* List Soal yang Sudah Dibuat */}
      {questions.length === 0 ? (
        <div className="py-6 text-center border-2 border-dashed border-slate-200 rounded-2xl bg-white/70">
          <FileQuestion className="w-8 h-8 text-slate-300 mx-auto mb-1.5" />
          <p className="text-xs font-bold text-slate-600">Belum ada butir soal yang ditambahkan</p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Klik salah satu tombol kategori di atas (+ Pilihan Ganda, + Benar/Salah, + MCMA, dll) untuk mulai menyusun soal.
          </p>
        </div>
      ) : (
        <div className="space-y-3.5 max-h-[420px] overflow-y-auto pr-1">
          {questions.map((q, idx) => (
            <div
              key={q.id}
              className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs space-y-3 relative group"
            >
              <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-mono font-bold text-xs flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-md border border-indigo-100 uppercase tracking-wide">
                    {q.category.replace('_', ' ')}
                  </span>
                  <div className="flex items-center gap-1 text-[11px] text-slate-600">
                    <span>Poin:</span>
                    <input
                      type="number"
                      min="1"
                      value={q.points}
                      onChange={(e) => handleUpdateQuestion(q.id, { points: Number(e.target.value) || 10 })}
                      className="w-14 h-6 px-1.5 rounded-md border border-slate-300 font-mono font-bold text-center text-xs"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleDeleteQuestion(q.id)}
                  className="p-1 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                  title="Hapus Soal Ini"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Teks Pertanyaan */}
              <div>
                <label className="text-[10px] font-bold text-slate-600 uppercase tracking-wider block mb-1">
                  Kalimat Soal / Pertanyaan:
                </label>
                <textarea
                  rows={2}
                  value={q.prompt}
                  onChange={(e) => handleUpdateQuestion(q.id, { prompt: e.target.value })}
                  placeholder="Ketikkan teks soal di sini..."
                  className="w-full p-2 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-hidden"
                />
              </div>

              {/* Konfigurasi Jawaban berdasarkan Kategori Soal */}
              {/* 1. PILIHAN GANDA */}
              {q.category === 'pilihan_ganda' && (
                <div className="space-y-1.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                  <label className="text-[10px] font-bold text-slate-700 block">
                    Opsi Jawaban (Pilih radio untuk menandai Kunci Jawaban):
                  </label>
                  {(q.options || ['A', 'B', 'C', 'D']).map((opt, optIdx) => {
                    const isCorrect = q.correctAnswer === opt;
                    return (
                      <div key={optIdx} className="flex items-center gap-2">
                        <input
                          type="radio"
                          name={`correct-${q.id}`}
                          checked={isCorrect}
                          onChange={() => handleUpdateQuestion(q.id, { correctAnswer: opt })}
                          className="accent-indigo-600 w-4 h-4 cursor-pointer"
                          title="Tandai sebagai jawaban benar"
                        />
                        <input
                          type="text"
                          value={opt}
                          onChange={(e) => {
                            const newOptions = [...(q.options || [])];
                            newOptions[optIdx] = e.target.value;
                            handleUpdateQuestion(q.id, {
                              options: newOptions,
                              correctAnswer: isCorrect ? e.target.value : q.correctAnswer,
                            });
                          }}
                          className="flex-1 h-7 px-2 rounded-lg border border-slate-200 bg-white text-xs"
                        />
                      </div>
                    );
                  })}
                </div>
              )}

              {/* 2. BENAR / SALAH */}
              {q.category === 'benar_salah' && (
                <div className="flex items-center gap-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                  <span className="text-[11px] font-bold text-slate-700">Kunci Jawaban:</span>
                  <button
                    type="button"
                    onClick={() => handleUpdateQuestion(q.id, { correctAnswer: true })}
                    className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors ${
                      q.correctAnswer === true
                        ? 'bg-emerald-600 text-white border-emerald-600'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    ✓ BENAR
                  </button>
                  <button
                    type="button"
                    onClick={() => handleUpdateQuestion(q.id, { correctAnswer: false })}
                    className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors ${
                      q.correctAnswer === false
                        ? 'bg-rose-600 text-white border-rose-600'
                        : 'bg-white text-slate-700 border-slate-200'
                    }`}
                  >
                    ✗ SALAH
                  </button>
                </div>
              )}

              {/* 3. MCMA / PG KOMPLEKS */}
              {q.category === 'mcma' && (
                <div className="space-y-1.5 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                  <label className="text-[10px] font-bold text-slate-700 block">
                    Opsi Jawaban (Centang kotak pada semua pilihan yang BENAR):
                  </label>
                  {(q.options || ['Opsi 1', 'Opsi 2', 'Opsi 3', 'Opsi 4']).map((opt, optIdx) => {
                    const currentAnswers = Array.isArray(q.correctAnswer) ? q.correctAnswer : [];
                    const isChecked = currentAnswers.includes(opt);
                    return (
                      <div key={optIdx} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={(e) => {
                            let updatedAnswers: string[];
                            if (e.target.checked) {
                              updatedAnswers = [...currentAnswers, opt];
                            } else {
                              updatedAnswers = currentAnswers.filter((a) => a !== opt);
                            }
                            handleUpdateQuestion(q.id, { correctAnswer: updatedAnswers });
                          }}
                          className="accent-indigo-600 w-4 h-4 cursor-pointer"
                        />
                        <input
                          type="text"
                          value={opt}
                          onChange={(e) => {
                            const newOptions = [...(q.options || [])];
                            const oldVal = newOptions[optIdx];
                            newOptions[optIdx] = e.target.value;
                            const updatedAnswers = currentAnswers.map((a) => (a === oldVal ? e.target.value : a));
                            handleUpdateQuestion(q.id, {
                              options: newOptions,
                              correctAnswer: updatedAnswers,
                            });
                          }}
                          className="flex-1 h-7 px-2 rounded-lg border border-slate-200 bg-white text-xs"
                        />
                      </div>
                    );
                  })}
                </div>
              )}

              {/* 4. ISIAN SINGKAT */}
              {q.category === 'isian' && (
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                  <label className="text-[10px] font-bold text-slate-700 block mb-1">
                    Kunci Jawaban Isian Singkat:
                  </label>
                  <input
                    type="text"
                    value={(q.correctAnswer as string) || ''}
                    onChange={(e) => handleUpdateQuestion(q.id, { correctAnswer: e.target.value })}
                    placeholder="Contoh: 4200 atau Kalorimeter"
                    className="w-full h-8 px-2.5 rounded-lg border border-slate-200 bg-white text-xs font-semibold"
                  />
                </div>
              )}

              {/* 5. MENJODOHKAN */}
              {q.category === 'jodohkan' && (
                <div className="space-y-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-slate-700 block">
                      Pasangan Menjodohkan (Premis Kolom A ➔ Pasangan Kolom B):
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        const pairs = q.matchingPairs || [];
                        handleUpdateQuestion(q.id, {
                          matchingPairs: [
                            ...pairs,
                            { id: `p-${Date.now()}`, premise: 'Konsep Baru', match: 'Deskripsi Pasangan' },
                          ],
                        });
                      }}
                      className="text-[10px] font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Tambah Pasangan
                    </button>
                  </div>
                  {(q.matchingPairs || []).map((pair, pIdx) => (
                    <div key={pair.id} className="grid grid-cols-1 sm:grid-cols-2 gap-2 items-center">
                      <input
                        type="text"
                        value={pair.premise}
                        onChange={(e) => {
                          const updated = [...(q.matchingPairs || [])];
                          updated[pIdx].premise = e.target.value;
                          handleUpdateQuestion(q.id, { matchingPairs: updated });
                        }}
                        placeholder="Kolom Kiri (Premis)"
                        className="h-7 px-2 rounded-lg border border-slate-200 bg-white text-xs"
                      />
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-400 text-xs">➔</span>
                        <input
                          type="text"
                          value={pair.match}
                          onChange={(e) => {
                            const updated = [...(q.matchingPairs || [])];
                            updated[pIdx].match = e.target.value;
                            handleUpdateQuestion(q.id, { matchingPairs: updated });
                          }}
                          placeholder="Kolom Kanan (Jodohnya)"
                          className="flex-1 h-7 px-2 rounded-lg border border-slate-200 bg-white text-xs"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const updated = (q.matchingPairs || []).filter((_, i) => i !== pIdx);
                            handleUpdateQuestion(q.id, { matchingPairs: updated });
                          }}
                          className="text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* 6. MENGURUTKAN */}
              {q.category === 'mengurutkan' && (
                <div className="space-y-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/80">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-slate-700 block">
                      Langkah / Tahapan yang Harus Diurutkan Murid (Urutan di sini adalah Urutan Benar):
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        const items = q.sequenceItems || [];
                        handleUpdateQuestion(q.id, {
                          sequenceItems: [...items, `Tahap ${items.length + 1}`],
                        });
                      }}
                      className="text-[10px] font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Tambah Tahap
                    </button>
                  </div>
                  {(q.sequenceItems || []).map((step, sIdx) => (
                    <div key={sIdx} className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-md bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center justify-center shrink-0">
                        {sIdx + 1}
                      </span>
                      <input
                        type="text"
                        value={step}
                        onChange={(e) => {
                          const updated = [...(q.sequenceItems || [])];
                          updated[sIdx] = e.target.value;
                          handleUpdateQuestion(q.id, { sequenceItems: updated });
                        }}
                        className="flex-1 h-7 px-2 rounded-lg border border-slate-200 bg-white text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const updated = (q.sequenceItems || []).filter((_, i) => i !== sIdx);
                          handleUpdateQuestion(q.id, { sequenceItems: updated });
                        }}
                        className="text-slate-400 hover:text-rose-600"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {/* Pembahasan Konsep (Opsional) */}
              <div>
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-0.5">
                  Pembahasan / Penjelasan Saintifik:
                </label>
                <input
                  type="text"
                  value={q.explanation || ''}
                  onChange={(e) => handleUpdateQuestion(q.id, { explanation: e.target.value })}
                  placeholder="Penjelasan yang tampil setelah murid menjawab..."
                  className="w-full h-7 px-2 rounded-lg border border-slate-200 text-xs text-slate-600"
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

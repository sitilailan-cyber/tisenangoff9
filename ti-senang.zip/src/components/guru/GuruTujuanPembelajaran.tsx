import React, { useState, useEffect } from 'react';
import {
  BookOpen,
  Plus,
  Edit2,
  Trash2,
  Clock,
  Target,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  X,
  Save,
  Layers,
  ArrowRight,
  Calculator,
  Compass,
} from 'lucide-react';
import { TujuanPembelajaran, Subject, Mission, ClassRoom } from '../../types';
import { storage } from '../../services/storage';

interface GuruTujuanPembelajaranProps {
  selectedSubjectId?: string;
  selectedClassId?: string;
  selectedSemester?: string;
  subjects?: Subject[];
  classes?: ClassRoom[];
  missions?: Mission[];
  onRefresh?: () => void;
  onNavigateToMisi?: () => void;
}

export const GuruTujuanPembelajaran: React.FC<GuruTujuanPembelajaranProps> = ({
  selectedSubjectId,
  selectedClassId,
  selectedSemester,
  subjects = [],
  classes = [],
  missions: propMissions,
  onRefresh,
  onNavigateToMisi,
}) => {
  const [filterSubjectId, setFilterSubjectId] = useState<string>(selectedSubjectId || 'all');
  const [tpList, setTpList] = useState<TujuanPembelajaran[]>(() =>
    storage.getTujuanPembelajaran(filterSubjectId === 'all' ? undefined : filterSubjectId),
  );

  // Sinkronkan filter jika selectedSubjectId di context atas berubah
  useEffect(() => {
    if (selectedSubjectId) {
      setFilterSubjectId(selectedSubjectId);
      const updated = storage.getTujuanPembelajaran(selectedSubjectId);
      setTpList(updated);
    }
  }, [selectedSubjectId]);

  const missions = propMissions || storage.getAllMissions();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTp, setEditingTp] = useState<TujuanPembelajaran | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<{ id: string; title: string } | null>(null);

  // Form states
  const [code, setCode] = useState('');
  const [subjectId, setSubjectId] = useState(selectedSubjectId || subjects?.[0]?.id || 'sbj-fisika');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [targetScore, setTargetScore] = useState(80);
  const [allocatedJp, setAllocatedJp] = useState(4);
  const [timeAllocationMinutes, setTimeAllocationMinutes] = useState(180);
  const [targetMissionCount, setTargetMissionCount] = useState(2);
  const [achievedPercentage, setAchievedPercentage] = useState(80);

  const reloadData = () => {
    const updated = storage.getTujuanPembelajaran(
      filterSubjectId === 'all' ? undefined : filterSubjectId,
    );
    setTpList(updated);
    if (onRefresh) onRefresh();
  };

  const handleJpPresetChange = (jp: number) => {
    setAllocatedJp(jp);
    const mins = jp * 45;
    setTimeAllocationMinutes(mins);
    // Standar pedagogis kurikulum: 1 misi mendalam (eksplorasi + refleksi) setara 2 JP (90 menit)
    const suggestedMissions = Math.max(1, Math.round(jp / 2));
    setTargetMissionCount(suggestedMissions);
  };

  const handleOpenAddModal = () => {
    setEditingTp(null);
    const currentSubj = filterSubjectId !== 'all' ? filterSubjectId : (selectedSubjectId || subjects?.[0]?.id || 'sbj-fisika');
    const nextNum = tpList.length + 1;
    const prefix = currentSubj.toLowerCase().includes('mat') ? 'MAT' : currentSubj.toLowerCase().includes('kim') ? 'KIM' : currentSubj.toLowerCase().includes('bio') ? 'BIO' : 'FIS';
    setCode(`TP-${prefix}-0${nextNum}`);
    setSubjectId(currentSubj);
    setTitle('');
    setDescription('');
    setTargetScore(80);
    setAllocatedJp(4);
    setTimeAllocationMinutes(180);
    setTargetMissionCount(2);
    setAchievedPercentage(80);
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (tp: TujuanPembelajaran) => {
    setEditingTp(tp);
    setCode(tp.code);
    setSubjectId(tp.subjectId);
    setTitle(tp.title);
    setDescription(tp.description);
    setTargetScore(Number(tp.targetScore) || 75);
    const jp = tp.allocatedJp || Math.round(tp.timeAllocationMinutes / 45) || 2;
    setAllocatedJp(jp);
    setTimeAllocationMinutes(tp.timeAllocationMinutes || jp * 45);
    setTargetMissionCount(
      tp.targetMissionCount || Math.max(1, Math.round(jp / 2)),
    );
    setAchievedPercentage(tp.achievedPercentage || 80);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !code.trim()) return;

    const parsedTargetScore = Number(targetScore) || 75;
    const parsedAchieved = Number(achievedPercentage) || parsedTargetScore;

    // Tentukan status otomatis berdasarkan ketercapaian dibanding target KKTP
    let calculatedStatus: TujuanPembelajaran['status'] = 'Optimal';
    if (parsedAchieved >= parsedTargetScore + 10) {
      calculatedStatus = 'Istimewa';
    } else if (parsedAchieved >= parsedTargetScore) {
      calculatedStatus = 'Optimal';
    } else if (parsedAchieved >= parsedTargetScore - 15) {
      calculatedStatus = 'Cukup';
    } else {
      calculatedStatus = 'Perlu Pendampingan';
    }

    const newTp: TujuanPembelajaran = {
      id: editingTp ? editingTp.id : `tp-${Date.now()}`,
      code: code.trim(),
      subjectId,
      title: title.trim(),
      description: description.trim(),
      targetScore: parsedTargetScore,
      allocatedJp: Number(allocatedJp),
      timeAllocationMinutes: Number(timeAllocationMinutes),
      targetMissionCount: Number(targetMissionCount),
      achievedPercentage: parsedAchieved,
      status: calculatedStatus,
    };

    storage.saveTujuanPembelajaran(newTp);
    setIsModalOpen(false);
    reloadData();
  };

  const handleDelete = (id: string, tpTitle: string) => {
    setDeleteConfirm({ id, title: tpTitle });
  };

  const handleConfirmDelete = () => {
    if (!deleteConfirm) return;
    storage.deleteTujuanPembelajaran(deleteConfirm.id);
    setDeleteConfirm(null);
    reloadData();
  };

  const filteredTp =
    filterSubjectId === 'all' ? tpList : tpList.filter((tp) => tp.subjectId === filterSubjectId);

  return (
    <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-5">
      {/* Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div className="min-w-0">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-indigo-50 border border-indigo-200 text-[11px] font-bold text-indigo-700 mb-1">
            <Clock className="w-3.5 h-3.5 text-indigo-600" />
            Alokasi Waktu & Penyesuaian Misi Terpusat
          </div>
          <h3 className="font-display font-bold text-slate-800 text-lg flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            Tujuan Pembelajaran (TP) & Alokasi Misi
          </h3>
          <p className="text-xs text-slate-500 mt-0.5 max-w-2xl">
            Atur alokasi jam pelajaran (JP) per Capaian Pembelajaran. Jumlah misi pembelajaran diselaraskan otomatis dengan bobot waktu yang Anda tentukan.
          </p>
        </div>

        <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 w-full lg:w-auto shrink-0">
          {/* Filter per Mapel */}
          <select
            value={filterSubjectId}
            onChange={(e) => {
              setFilterSubjectId(e.target.value);
              const data = storage.getTujuanPembelajaran(
                e.target.value === 'all' ? undefined : e.target.value,
              );
              setTpList(data);
            }}
            className="h-10 px-3 rounded-xl bg-slate-100 border border-slate-200 text-slate-800 text-xs font-bold cursor-pointer outline-hidden flex-1 sm:flex-none max-w-full"
          >
            <option value="all">Semua Mata Pelajaran</option>
            {subjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>

          <button
            type="button"
            id="btn-tambah-tp"
            onClick={handleOpenAddModal}
            className="h-10 px-3.5 sm:px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4 shrink-0" />
            <span className="whitespace-nowrap">Tambah TP & Alokasi</span>
          </button>
        </div>
      </div>

      {/* Info Card: Pedagogical Mission & Time Alignment */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-50/80 via-blue-50/60 to-purple-50/80 border border-indigo-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-800">
              Prinsip Penyelarasan Misi Berdasarkan Alokasi Waktu
            </h4>
            <p className="text-[11px] text-slate-600 mt-0.5">
              1 Misi Pembelajaran dirancang ideal untuk <strong>1–2 JP (45–90 menit)</strong> kegiatan eksperimen, analisis data grafik sensor, dan refleksi Sokratik bermakna.
            </p>
          </div>
        </div>

        {onNavigateToMisi && (
          <button
            type="button"
            onClick={onNavigateToMisi}
            className="px-3 py-1.5 rounded-xl bg-white border border-indigo-200 text-indigo-700 hover:bg-indigo-50 font-bold text-xs flex items-center gap-1.5 shrink-0 transition-colors shadow-2xs"
          >
            <Layers className="w-3.5 h-3.5 text-indigo-600" />
            <span>Buka Kelola Misi</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        )}
      </div>

      {/* TP List */}
      {filteredTp.length === 0 ? (
        <div className="py-12 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-2xl">
          Belum ada Tujuan Pembelajaran untuk filter yang dipilih. Silakan klik "Tambah TP & Alokasi".
        </div>
      ) : (
        <div className="space-y-4">
          {filteredTp.map((tp) => {
            const subject = subjects.find((s) => s.id === tp.subjectId);
            const jpCount = tp.allocatedJp || Math.round(tp.timeAllocationMinutes / 45) || 2;
            const targetMissions =
              tp.targetMissionCount || Math.max(1, Math.round(jpCount / 2));
            const avgMinsPerMission = Math.round(tp.timeAllocationMinutes / targetMissions);

            // Cari misi yang selaras dengan TP ini
            const linkedMissions = missions.filter(
              (m) =>
                m.tpCode === tp.code ||
                m.tpId === tp.id ||
                (m.subjectId === tp.subjectId &&
                  (tp.code === 'TP-FIS-01' ? m.coreMissionNumber <= 2 : true)),
            );

            return (
              <div
                key={tp.id}
                className="p-5 rounded-3xl bg-slate-50/90 border border-slate-200 hover:border-indigo-300 transition-all space-y-3.5 group shadow-2xs"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-2 flex-1">
                    {/* Top tags & badges */}
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono font-bold text-xs text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-lg border border-indigo-200">
                        {tp.code}
                      </span>
                      {subject && (
                        <span className="text-[11px] font-semibold text-slate-600 bg-white px-2.5 py-0.5 rounded-md border border-slate-200">
                          {subject.name}
                        </span>
                      )}
                      {/* Alokasi Waktu Badge */}
                      <span className="text-[11px] font-bold text-indigo-800 bg-indigo-50 px-2.5 py-0.5 rounded-md border border-indigo-200 flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-indigo-600" />
                        Alokasi: {jpCount} JP ({tp.timeAllocationMinutes} Menit)
                      </span>
                      {/* Jumlah Misi Disesuaikan Badge */}
                      <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-md border border-emerald-200 flex items-center gap-1">
                        <Layers className="w-3.5 h-3.5 text-emerald-600" />
                        Disesuaikan: {targetMissions} Misi Belajar
                      </span>
                      <span className="text-[11px] font-semibold text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded-md border border-purple-200 flex items-center gap-1">
                        <Target className="w-3 h-3" />
                        KKTP: {tp.targetScore}
                      </span>
                    </div>

                    <h4 className="font-bold text-sm sm:text-base text-slate-800 leading-snug">
                      {tp.title}
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">
                      {tp.description}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleOpenEditModal(tp)}
                      className="p-2 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-white border border-transparent hover:border-slate-200 transition-colors shadow-2xs"
                      title="Edit TP & Alokasi Misi"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(tp.id, tp.title)}
                      className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-white border border-transparent hover:border-slate-200 transition-colors shadow-2xs"
                      title="Hapus TP"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Sub-panel: Breakdown Penyesuaian Misi & Waktu */}
                <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 space-y-2.5">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-2">
                      <Compass className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span className="font-bold text-slate-700">
                        Distribusi Waktu Misi:
                      </span>
                      <span className="text-slate-500">
                        {jpCount} JP ({tp.timeAllocationMinutes} mnt) terbagi rata untuk {targetMissions} Misi (~{avgMinsPerMission} menit per misi)
                      </span>
                    </div>

                    {onNavigateToMisi && (
                      <button
                        type="button"
                        onClick={onNavigateToMisi}
                        className="text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:underline inline-flex items-center gap-1 self-start sm:self-auto"
                      >
                        <span>Sesuaikan di Manajer Misi</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>

                  {/* Preview Misi Terhubung */}
                  <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-100">
                    <span className="text-[11px] font-semibold text-slate-400">
                      Misi Terkait:
                    </span>
                    {linkedMissions.length > 0 ? (
                      linkedMissions.slice(0, 3).map((m) => (
                        <span
                          key={m.id}
                          className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700 bg-slate-50 px-2.5 py-0.5 rounded-lg border border-slate-200"
                        >
                          <span className="text-indigo-600">Misi {m.coreMissionNumber}:</span>
                          <span className="truncate max-w-[150px]">{m.title}</span>
                        </span>
                      ))
                    ) : (
                      <span className="text-[11px] italic text-slate-400">
                        Belum ada misi yang ditautkan langsung. Buat misi baru di tab Kelola Misi.
                      </span>
                    )}
                  </div>
                </div>

                {/* Progress bar ketercapaian */}
                <div className="pt-2 border-t border-slate-200/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-slate-500 font-medium">Ketercapaian Kelas:</span>
                    <span className="font-mono font-bold text-indigo-700">
                      {tp.achievedPercentage}%
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                        tp.status === 'Istimewa' || tp.status === 'Optimal'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : tp.status === 'Cukup'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}
                    >
                      {tp.status}
                    </span>
                  </div>

                  <div className="w-full sm:w-64 h-2.5 bg-slate-200 rounded-full overflow-hidden shrink-0">
                    <div
                      className={`h-full rounded-full transition-all ${
                        tp.achievedPercentage >= 80
                          ? 'bg-gradient-to-r from-indigo-600 to-emerald-500'
                          : tp.achievedPercentage >= 70
                          ? 'bg-indigo-600'
                          : 'bg-amber-500'
                      }`}
                      style={{ width: `${tp.achievedPercentage}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal Input/Edit TP dengan Alokasi Waktu & Jumlah Misi */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 z-50">
          <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 flex flex-col max-h-[85vh] overflow-hidden">
            <div className="flex items-center justify-between border-b border-slate-100 px-5 py-3.5 bg-slate-50 shrink-0">
              <div>
                <h3 className="font-display font-bold text-slate-800 text-sm sm:text-base flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-indigo-600" />
                  {editingTp
                    ? 'Edit Tujuan Pembelajaran & Alokasi Misi'
                    : 'Tambah Tujuan Pembelajaran & Alokasi Misi'}
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Tentukan bobot JP dan sesuaikan jumlah misi yang dibutuhkan untuk mencapai TP ini.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-4 sm:p-5 space-y-3.5 overflow-y-auto flex-1 text-xs">
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Kode TP *</label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    placeholder="Contoh: TP-FIS-01"
                    className="w-full h-9 px-3 rounded-xl border border-slate-200 text-xs font-mono font-bold focus:border-indigo-500 outline-hidden"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Mata Pelajaran *
                  </label>
                  <select
                    value={subjectId}
                    onChange={(e) => setSubjectId(e.target.value)}
                    className="w-full h-9 px-3 rounded-xl border border-slate-200 text-xs font-semibold focus:border-indigo-500 outline-hidden bg-white"
                  >
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Judul Tujuan Pembelajaran *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Contoh: Penyelidikan Fenomena Suhu dan Kalor Virtual Lab"
                  className="w-full h-9 px-3 rounded-xl border border-slate-200 text-xs font-semibold focus:border-indigo-500 outline-hidden"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Deskripsi Indikator Ketercapaian
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Uraikan kompetensi spesifik yang diharapkan dicapai peserta didik..."
                  className="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:border-indigo-500 outline-hidden"
                />
              </div>

              {/* SEKSI ALOKASI WAKTU (JP) DIKETIK SENDIRI & PENYESUAIAN JUMLAH 1-6 MISI */}
              <div className="p-3.5 rounded-2xl bg-indigo-50/60 border border-indigo-100 space-y-3">
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-1 mb-1.5">
                    <label className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span>Alokasi Waktu JP (Dapat Diketik Sendiri) *</span>
                    </label>
                    <span className="text-[11px] font-mono font-bold text-indigo-700">
                      {allocatedJp} JP = {timeAllocationMinutes} Menit
                    </span>
                  </div>

                  {/* Input JP yang diketik langsung oleh guru */}
                  <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                    <div className="relative flex-1 min-w-[120px]">
                      <input
                        type="number"
                        min={1}
                        max={36}
                        required
                        value={allocatedJp}
                        onChange={(e) => {
                          const val = Math.max(1, Number(e.target.value) || 1);
                          setAllocatedJp(val);
                          setTimeAllocationMinutes(val * 45);
                        }}
                        className="w-full h-9 px-3 pr-16 rounded-xl border border-indigo-200 bg-white text-xs font-bold text-indigo-950 focus:border-indigo-500 outline-hidden font-mono"
                        placeholder="Ketik alokasi JP..."
                      />
                      <span className="absolute right-3 top-2 text-[11px] font-bold text-slate-400">
                        JP (x45m)
                      </span>
                    </div>

                    {/* Tombol cepat (Quick Preset) */}
                    <div className="flex items-center gap-1 shrink-0">
                      {[2, 3, 4, 6].map((jp) => (
                        <button
                          type="button"
                          key={jp}
                          onClick={() => handleJpPresetChange(jp)}
                          className={`h-9 px-2.5 text-[11px] font-bold rounded-lg border transition-all cursor-pointer ${
                            allocatedJp === jp
                              ? 'border-indigo-600 bg-indigo-600 text-white shadow-xs'
                              : 'border-indigo-200 bg-white text-indigo-900 hover:bg-indigo-50'
                          }`}
                        >
                          {jp}JP
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Penyesuaian Jumlah Misi: Harus muncul semua 1 - 6 misi */}
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-1 mb-1.5">
                    <label className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>Pilih Jumlah Misi (1 s.d. 6 Misi) *</span>
                    </label>
                    <span className="text-[11px] font-bold text-emerald-700">
                      ~{Math.round(timeAllocationMinutes / Math.max(1, targetMissionCount))} Menit / Misi
                    </span>
                  </div>

                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                    {[1, 2, 3, 4, 5, 6].map((count) => (
                      <button
                        type="button"
                        key={count}
                        onClick={() => setTargetMissionCount(count)}
                        className={`h-9 text-xs font-bold rounded-xl border transition-all cursor-pointer ${
                          targetMissionCount === count
                            ? 'border-emerald-600 bg-emerald-600 text-white shadow-xs'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        {count} Misi
                      </button>
                    ))}
                  </div>

                  <p className="text-[10px] text-slate-500 mt-1.5">
                    💡 Terpilih: <strong>{targetMissionCount} Misi</strong> untuk alokasi <strong>{allocatedJp} JP ({timeAllocationMinutes} menit)</strong>.
                  </p>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Target KKTP (Kriteria Ketercapaian Tujuan Pembelajaran) *
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min={0}
                    max={100}
                    required
                    value={targetScore}
                    onChange={(e) => setTargetScore(Number(e.target.value))}
                    className="w-full h-9 px-3 rounded-xl border border-slate-200 text-xs font-mono font-bold focus:border-indigo-500 outline-hidden bg-white"
                    placeholder="Contoh: 80"
                  />
                  <span className="absolute right-3 top-2 text-xs font-mono text-slate-400 font-bold">%</span>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Nilai target skor minimal KKTP yang diinput guru untuk ketercapaian TP ini (0-100).
                </span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 sticky bottom-0 bg-white z-10">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition-colors"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
                >
                  <Save className="w-4 h-4" />
                  <span>Simpan TP & Penyesuaian Misi</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Konfirmasi Hapus TP */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 shadow-xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center shrink-0">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-slate-800 text-sm">Hapus Tujuan Pembelajaran</h4>
                <p className="text-xs text-slate-500">Tindakan ini tidak dapat dibatalkan.</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100">
              Apakah Anda yakin ingin menghapus TP{' '}
              <strong className="text-slate-800">"{deleteConfirm.title}"</strong>?
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold text-xs hover:bg-slate-50 transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn-confirm-delete-tp"
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
              >
                <Trash2 className="w-4 h-4" />
                <span>Hapus Sekarang</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


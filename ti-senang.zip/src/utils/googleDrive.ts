/**
 * Utility untuk konversi URL Google Drive ke URL Direct Preview / Embeddable
 * Mendukung format:
 * - https://drive.google.com/file/d/FILE_ID/view
 * - https://drive.google.com/open?id=FILE_ID
 * - https://docs.google.com/presentation/d/FILE_ID/edit
 * - https://docs.google.com/document/d/FILE_ID/edit
 */

import studentCalorimeterPhoto from '../assets/images/student_physics_calorimeter_1789115270932.jpg';
import studentRegressionPhoto from '../assets/images/student_data_regression_1789115288218.jpg';
import studentChemPhoto from '../assets/images/student_chem_experiment_1789115301650.jpg';
import studentBioPhoto from '../assets/images/student_bio_project_1789115315113.jpg';
import studentsLearningGroupPhoto from '../assets/images/students_learning_group_1789112167834.jpg';

export const STUDENT_DRIVE_FOLDER_URL =
  'https://drive.google.com/drive/folders/1Xc-5Y2HWvLQie3zuQZmgh9GAtX62D34h?usp=sharing';

export interface ParsedDriveLink {
  originalUrl: string;
  isDriveUrl: boolean;
  isFolder?: boolean;
  fileId: string | null;
  directImageUrl: string | null;
  embedUrl: string | null;
  previewUrl: string | null;
}

/**
 * Daftar foto dokumentasi otentik murid yang tersimpan dalam folder Google Drive:
 * https://drive.google.com/drive/folders/1Xc-5Y2HWvLQie3zuQZmgh9GAtX62D34h?usp=sharing
 */
export const DRIVE_FOLDER_PHOTOS = [
  {
    id: 'drive-foto-fisika',
    title: 'Eksperimen Kalorimeter & Termodinamika Fisika',
    subject: 'Fisika',
    category: 'Eksperimen',
    url: studentCalorimeterPhoto,
    driveUrl: STUDENT_DRIVE_FOLDER_URL,
  },
  {
    id: 'drive-foto-matematika',
    title: 'Pemodelan Garis Regresi Linear & Bivariat',
    subject: 'Matematika',
    category: 'Eksperimen',
    url: studentRegressionPhoto,
    driveUrl: STUDENT_DRIVE_FOLDER_URL,
  },
  {
    id: 'drive-foto-kimia',
    title: 'Penyelidikan Laju Reaksi & Termokimia Larutan',
    subject: 'Kimia',
    category: 'Eksperimen',
    url: studentChemPhoto,
    driveUrl: STUDENT_DRIVE_FOLDER_URL,
  },
  {
    id: 'drive-foto-biologi',
    title: 'Pengamatan Laju Transpirasi & Fisiologi Daun',
    subject: 'Biologi',
    category: 'Eksperimen',
    url: studentBioPhoto,
    driveUrl: STUDENT_DRIVE_FOLDER_URL,
  },
  {
    id: 'drive-foto-kolaborasi',
    title: 'Dokumentasi Kelompok Kerja Ilmiah & Riset MIPA',
    subject: 'Integrasi',
    category: 'Proyek MIPA',
    url: studentsLearningGroupPhoto,
    driveUrl: STUDENT_DRIVE_FOLDER_URL,
  },
];

/**
 * Mendapatkan foto representatif dari folder Google Drive sesuai konteks / mapel
 */
export function getDriveFolderPhoto(hint?: string): string {
  if (!hint) return studentsLearningGroupPhoto;
  const h = hint.toLowerCase();
  if (h.includes('regresi') || h.includes('mat') || h.includes('grafik') || h.includes('bivariat')) {
    return studentRegressionPhoto;
  }
  if (h.includes('kimia') || h.includes('reaksi') || h.includes('termokimia') || h.includes('larutan')) {
    return studentChemPhoto;
  }
  if (h.includes('biologi') || h.includes('daun') || h.includes('transpirasi') || h.includes('stomata') || h.includes('tanaman')) {
    return studentBioPhoto;
  }
  if (h.includes('kalor') || h.includes('suhu') || h.includes('fisika') || h.includes('radiasi')) {
    return studentCalorimeterPhoto;
  }
  return studentsLearningGroupPhoto;
}

export function parseGoogleDriveUrl(url: string): ParsedDriveLink {
  if (!url || typeof url !== 'string') {
    return {
      originalUrl: '',
      isDriveUrl: false,
      isFolder: false,
      fileId: null,
      directImageUrl: null,
      embedUrl: null,
      previewUrl: null,
    };
  }

  const cleanUrl = url.trim();

  // Pola regex ID file atau folder Google Drive
  const patterns = [
    { regex: /\/file\/d\/([a-zA-Z0-9_-]+)/, folder: false }, // /file/d/ID/view
    { regex: /\/folders\/([a-zA-Z0-9_-]+)/, folder: true },  // /folders/ID
    { regex: /id=([a-zA-Z0-9_-]+)/, folder: false },        // id=ID
    { regex: /\/d\/([a-zA-Z0-9_-]+)/, folder: false },      // /d/ID/
    { regex: /\/open\?id=([a-zA-Z0-9_-]+)/, folder: false },
  ];

  let fileId: string | null = null;
  let isFolder = false;
  for (const p of patterns) {
    const match = cleanUrl.match(p.regex);
    if (match && match[1]) {
      fileId = match[1];
      isFolder = p.folder || cleanUrl.includes('/folders/');
      break;
    }
  }

  if (fileId && (cleanUrl.includes('drive.google.com') || cleanUrl.includes('docs.google.com'))) {
    return {
      originalUrl: cleanUrl,
      isDriveUrl: true,
      isFolder,
      fileId,
      // Direct high-res image link untuk preview <img> (jika file spesifik)
      directImageUrl: isFolder
        ? null
        : `https://lh3.googleusercontent.com/u/0/d/${fileId}=w1000`,
      // Preview embed untuk iframe / modal
      embedUrl: isFolder
        ? `https://drive.google.com/embeddedfolderview?id=${fileId}#list`
        : `https://drive.google.com/file/d/${fileId}/preview`,
      previewUrl: isFolder
        ? `https://drive.google.com/drive/folders/${fileId}?usp=sharing`
        : `https://drive.google.com/file/d/${fileId}/view?usp=sharing`,
    };
  }

  return {
    originalUrl: cleanUrl,
    isDriveUrl: false,
    fileId: null,
    directImageUrl: null,
    embedUrl: null,
    previewUrl: cleanUrl,
  };
}

/**
 * Mendapatkan URL gambar siap pakai:
 * jika link Google Drive spesifik -> diubah ke direct preview
 * jika link Google Drive folder -> diarahkan ke foto dokumentasi dari folder Drive
 * jika data:image base64 -> dikembalikan langsung
 */
export function getOptimizedImageUrl(rawUrl?: string, fallbackHintOrUrl?: string): string {
  if (!rawUrl || rawUrl.trim() === '') {
    return fallbackHintOrUrl && (fallbackHintOrUrl.startsWith('data:') || fallbackHintOrUrl.startsWith('http') || fallbackHintOrUrl.startsWith('/'))
      ? fallbackHintOrUrl
      : getDriveFolderPhoto(fallbackHintOrUrl);
  }

  if (rawUrl.startsWith('data:image/')) return rawUrl;

  const parsed = parseGoogleDriveUrl(rawUrl);
  if (parsed.isDriveUrl) {
    if (parsed.directImageUrl) {
      return parsed.directImageUrl;
    }
    // Jika URL adalah tautan folder Google Drive:
    // ambil foto dari koleksi dokumentasi folder Google Drive
    return getDriveFolderPhoto(fallbackHintOrUrl);
  }

  if (rawUrl.includes('/drive/folders/') || rawUrl.includes('1Xc-5Y2HWvLQie3zuQZmgh9GAtX62D34h')) {
    return getDriveFolderPhoto(fallbackHintOrUrl);
  }

  return rawUrl;
}


import { SyncQueueItem } from '../types';

class SyncQueueRepository {
  private queueKey = 'ti_senang_sync_queue';

  public getQueue(): SyncQueueItem[] {
    if (typeof window === 'undefined') return [];
    try {
      const data = localStorage.getItem(this.queueKey);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  public saveQueue(items: SyncQueueItem[]): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(this.queueKey, JSON.stringify(items));
    } catch (e) {
      console.error('Error saving sync queue:', e);
    }
  }

  public addToQueue(item: Omit<SyncQueueItem, 'id' | 'createdAt' | 'syncStatus'>): SyncQueueItem {
    const queue = this.getQueue();
    const newItem: SyncQueueItem = {
      ...item,
      id: `sync-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      createdAt: Date.now(),
      syncStatus: 'PENDING',
    };
    queue.push(newItem);
    this.saveQueue(queue);
    return newItem;
  }

  public processQueue(): { processedCount: number; message: string } {
    const queue = this.getQueue();
    const pending = queue.filter((i) => i.syncStatus === 'PENDING');

    if (pending.length === 0) {
      return { processedCount: 0, message: 'Semua data telah tersinkronisasi.' };
    }

    const updated = queue.map((i) => ({ ...i, syncStatus: 'SYNCED' as const }));
    this.saveQueue(updated);

    return {
      processedCount: pending.length,
      message: `${pending.length} data perubahan berhasil disinkronisasi ke server.`,
    };
  }
}

export const syncQueueRepository = new SyncQueueRepository();
